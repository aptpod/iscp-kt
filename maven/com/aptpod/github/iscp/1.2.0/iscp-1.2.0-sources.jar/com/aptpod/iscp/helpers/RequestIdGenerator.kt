package com.aptpod.iscp.helpers

import java.util.concurrent.locks.ReentrantLock
import kotlin.concurrent.withLock

internal class RequestIdGenerator {

    companion object {
        const val DEFAULT_REQUEST_ID_FOR_CLIENT: Long = 0
        const val MAX_REQUEST_ID = UInt.MAX_VALUE

        @JvmStatic
        fun newGeneratorForClient(): RequestIdGenerator {
            return RequestIdGenerator(DEFAULT_REQUEST_ID_FOR_CLIENT.toULong())
        }

        @JvmStatic
        fun newInstance(initialValue: Long) : RequestIdGenerator {
            return RequestIdGenerator(initialValue.toULong())
        }

        @JvmStatic
        fun newInstance(initialValue: Long, current: Long) : RequestIdGenerator {
            return RequestIdGenerator(initialValue.toULong(), current.toULong())
        }
    }

    private var initialValue: ULong
    private var currentValue: ULong
    private var requestIdLock: ReentrantLock = ReentrantLock()

    constructor(initialValue: ULong) {
        this.initialValue = initialValue
        this.currentValue = initialValue
    }

    constructor(initialValue: ULong, current: ULong) {
        this.initialValue = initialValue
        this.currentValue = current
    }

    fun generate(): UInt {
        this.requestIdLock.withLock {
            var id = this.currentValue
            this.currentValue += 2u
            if (this.currentValue > MAX_REQUEST_ID) {
                this.currentValue = this.initialValue
            }
            return id.toUInt()
        }
    }

    fun generateLong(): Long {
        this.requestIdLock.withLock {
            var id = this.currentValue
            this.currentValue += 2u
            if (this.currentValue > MAX_REQUEST_ID) {
                this.currentValue = this.initialValue
            }
            return id.toLong()
        }
    }

    fun reset() {
        this.requestIdLock.withLock {
            this.currentValue = this.initialValue
        }
    }
}