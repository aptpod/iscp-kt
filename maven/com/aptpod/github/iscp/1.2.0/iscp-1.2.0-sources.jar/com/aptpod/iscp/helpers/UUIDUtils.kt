package com.aptpod.iscp.helpers

import com.google.protobuf.ByteString
import java.nio.ByteBuffer
import java.util.UUID


internal class UUIDUtils {

    companion object {
        fun empty() : UUID {
            return UUID.fromString("00000000-0000-0000-0000-000000000000")
        }
    }
}

internal fun ByteString.toUuid() : UUID {
    val bytes = this.toByteArray()
    val buf = ByteBuffer.wrap(bytes)
    val high = buf.long
    val low = buf.long
    return UUID(high, low)
}

internal fun UUID.toByteArray(): ByteArray {
    val buf = ByteBuffer.wrap(ByteArray(16))
    buf.putLong(this.mostSignificantBits)
    buf.putLong(this.leastSignificantBits)
    return buf.array()
}

internal fun UUID.toByteString() : ByteString {
    return ByteString.copyFrom(this.toByteArray())
}