package com.aptpod.iscp.transport

import com.aptpod.iscp.model.IscpException
import com.aptpod.iscp.logger.IscpLog
import java.util.Timer
import java.util.TimerTask
import java.util.concurrent.locks.ReentrantLock
import kotlin.concurrent.withLock


internal class Receivers {

    private var receivers: MutableList<Receiver> = mutableListOf()
    private var receiverLock = ReentrantLock()

    fun register(receiver: Receiver) {
        this.receiverLock.withLock {
            this.receivers.add(receiver)
        }
    }

    fun unregister(receiver: Receiver) {
        this.receiverLock.withLock {
            receiver.unsubscribe()
            var index = this.receivers.indexOf(receiver)
            if (index >= 0) {
                this.receivers.removeAt(index)
            }
        }
    }

    fun unregisterAll() {
        this.receiverLock.withLock {
            for (r in this.receivers) { r.unsubscribe() }
            this.receivers.clear()
        }
    }

    fun getReceivers(): List<Receiver> {
        this.receiverLock.withLock {
            return this.receivers.toList()
        }
    }

    fun setReceivedMessage(message: Any) {
        for (r in this.getReceivers()) {
            r.receivedMessage(message)
        }
    }

}

internal class Receiver : TimerTask {

    companion object {
        /**
         * デフォルトのタイムアウト時間
         *
         * 単位はミリ秒。
         */
        const val DEFAULT_TIMEOUT: Long = 10 * 1000
    }

    /**
     * レシーバーの名前。
     */
    var name: String = ""

    private var handler: ((Any?, Exception?) -> Unit)? = null
    private var subscribed: String = ""
    private var timeoutTimer: Timer? = null
    private var timeout: Long

    /**
     * @param timeout タイムアウト時間（ミリ秒）。 `0` 以下の場合はタイムアウトしません。
     */
    constructor(timeout: Long = DEFAULT_TIMEOUT) {
        this.timeout = timeout
        if (timeout <= 0) { return }
        this.timeoutTimer = Timer()
        this.timeoutTimer?.schedule(this, timeout, timeout)
    }

    /**
     * @param name レシーバーの名前。
     * @param timeout タイムアウト時間（ミリ秒）。 `0` 以下の場合はタイムアウトしません。
     */
    constructor(name: String, timeout: Long = DEFAULT_TIMEOUT) {
        this.name = name
        this.timeout = timeout
        if (timeout <= 0) { return }
        this.timeoutTimer = Timer()
        this.timeoutTimer?.schedule(this, timeout, timeout)
    }

    inline fun <reified T> subscribe(crossinline handler: (T?, Exception?) -> Unit) {
        this.subscribed = T::class.java.name
        this.handler = { message, exception ->
            if (exception != null) {
                handler.invoke(null, exception)
            } else if(message is T) {
                handler(message, null)
            }
            // 対象のメッセージではなかった
        }
    }

    fun unsubscribe() {
        this.timeoutTimer?.let { timer ->
            timer.cancel()
        }
        this.timeoutTimer = null
        this.handler = null
    }

    override fun run() {
        IscpLog.d("timeoutTimerDidFire(timeout: $timeout) - Receiver<$subscribed$name>")
        Thread {
            this.handler?.invoke(null, IscpException.Timeout)
        }.start()
    }

    fun receivedMessage(message: Any) {
        this.handler?.invoke(message, null)
    }
}