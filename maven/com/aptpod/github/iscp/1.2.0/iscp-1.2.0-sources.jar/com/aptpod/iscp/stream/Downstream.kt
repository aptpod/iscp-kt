package com.aptpod.iscp.stream

import com.aptpod.iscp.helpers.AckIdGenerator
import com.aptpod.iscp.helpers.AliasGenerator
import com.aptpod.iscp.model.IscpException
import com.aptpod.iscp.connection.Connection
import com.aptpod.iscp.connection.closeDownstream
import com.aptpod.iscp.connection.sendDownstreamChunkAck
import com.aptpod.iscp.connection.sendDownstreamMetadataAck
import com.aptpod.iscp.model.DataId
import com.aptpod.iscp.model.DataPoint
import com.aptpod.iscp.model.DataPointGroup
import com.aptpod.iscp.model.DownstreamChunk
import com.aptpod.iscp.model.DownstreamFilter
import com.aptpod.iscp.model.DownstreamFilterReference
import com.aptpod.iscp.model.DownstreamFilterReferences
import com.aptpod.iscp.model.DownstreamMetadata
import com.aptpod.iscp.model.QoS
import com.aptpod.iscp.model.UpstreamInfo
import com.aptpod.iscp.logger.IscpLog
import com.aptpod.iscp.message.DownstreamChunkAckComplete
import com.aptpod.iscp.message.DownstreamChunkResult
import com.aptpod.iscp.message.DownstreamOpenResponse
import com.aptpod.iscp.message.ResultCode
import com.aptpod.iscp.transport.Receiver
import java.util.Timer
import java.util.TimerTask
import java.util.UUID
import java.util.concurrent.locks.ReentrantLock
import kotlin.concurrent.withLock

/**
 * ダウンストリームで発生するイベントのコールバックです。
 */
interface DownstreamCallbacks {
    /**
     * ダウンストリームチャンクを受信した際にコールされます。
     * @param downstream ダウンストリーム。
     * @param message ダウンストリームチャンク。
     */
    fun onReceiveChunk(downstream: Downstream, message: DownstreamChunk)
    /**
     * メタデータを受信した際にコールされます。
     * @param downstream ダウンストリーム。
     * @param message ダウンストリームメタデータ。
     */
    fun onReceiveMetadata(downstream: Downstream, message: DownstreamMetadata)
    /**
     * エラーが発生した際にコールされます。
     * @param downstream ダウンストリーム。
     * @param error エラー情報。
     */
    fun onFailWithError(downstream: Downstream, error: Exception)
    /**
     * このストリームがエラーによりクローズされた際にコールされます。
     * @param downstream ダウンストリーム。
     * @param error エラー情報。
     */
    fun onCloseWithError(downstream: Downstream, error: Exception)
    /**
     * このストリームの再開処理が成功した際にコールされます。
     * @param downstream ダウンストリーム。
     */
    fun onResume(downstream: Downstream)
}

/**
 * ダウンストリームを表すクラスです。
 */
class Downstream {

    companion object {
        /**
         * QoSのデフォルト値。
         */
        @JvmField val DEFAULT_QOS = QoS.UNRELIABLE
        /**
         * 空チャンク省略フラグのデフォルト値。
         */
        const val DEFAULT_OMIT_EMPTY_CHUNK: Boolean = false
        /**
         * オープンのタイムアウトのデフォルト値（ミリ秒）。
         */
        const val DEFAULT_OPEN_TIMEOUT: Long = 10 * 1000
        /**
         * クローズのタイムアウトのデフォルト値（ミリ秒）。
         */
        const val DEFAULT_CLOSE_TIMEOUT: Long = 10 * 1000
        /**
         * 受信したメッセージに対するAckの返却間隔のデフォルト値（ミリ秒）。
         */
        const val DEFAULT_ACK_INTERVAL: Long = 2 * 1000
        /**
         * ストリームが異常切断された時点からの有効期間のデフォルト値（秒）（UShort）。
         */
        const val DEFAULT_EXPIRY_INTERVAL: Short = 60
    }

    /**
     * ダウンストリームで発生するイベントのコールバックです。
     */
    var callbacks: DownstreamCallbacks? = null

    /**
     * コネクション。
     */
    val connection: Connection
    /**
     * エイリアス。
     */
    internal var streamIdAlias: UInt = 0u
    /**
     * ストリームID。
     */
    val id: UUID
    /**
     * サーバー時刻（ナノ秒）。
     *
     * ダウンストリームを開いた時点におけるサーバーの現在時刻です。
     */
    val serverTime: Long
    /**
     * ダウンストリームフィルタのリスト。
     */
    val filters: List<DownstreamFilter>
    /**
     * ストリーム再開用トークン。
     */
    var resumeToken: String = ""
    /**
     * 有効期限（秒）（UShort）。
     */
    val expiryInterval: Short
    /**
     * QoS。
     */
    val qos: QoS
    /**
     * 空チャンク省略フラグ。
     */
    val omitEmptyChunk: Boolean
    /**
     * Ack返却間隔（ミリ秒）。
     */
    val ackInterval: Long
    /**
     * オープンのタイムアウト（ミリ秒）
     */
    val openTimeout: Long
    /**
     * クローズのタイムアウト（ミリ秒）
     */
    val closeTimeout: Long
    /**
     * データIDとエイリアスのマップ
     */
    internal var dataIdAliasMap: MutableMap<UInt, com.aptpod.iscp.message.DataId> = mutableMapOf()
    internal var dataIdAliasGenerator: AliasGenerator
    /**
     * アップストリームエイリアスとアップストリーム情報のマップ
     */
    internal var upstreamInfoMap: MutableMap<UInt, com.aptpod.iscp.message.UpstreamInfo> = mutableMapOf()
    internal var upstreamInfoGenerator: AliasGenerator = AliasGenerator(1u)
    /**
     * AckIDのジェネレーター
     */
    internal var ackIdGenerator: AckIdGenerator = AckIdGenerator()
    // Ackバッファ系
    internal var ackBufferLock = ReentrantLock()
    internal var chunksResultsAckBuffer: MutableList<DownstreamChunkResult> = mutableListOf()
    /**
     * 受信したアップストリーム情報のAck用バッファ
     */
    internal var upstreamInfoMapAckBuffer: MutableMap<UInt, com.aptpod.iscp.message.UpstreamInfo> = mutableMapOf()
    // 新たにエイリアスとして登録するデータIDのリスト
    internal var dataIdMapAckBuffer: MutableMap<UInt, com.aptpod.iscp.message.DataId> = mutableMapOf()
    private var ackIntervalTimer: Timer? = null
    private var downstreamChunkReceiver: Receiver? = null
    private var downstreamChunkAckCompleteReceiver: Receiver? = null
    private var downstreamMetadataReceiver: Receiver? = null
    // 接続が解除された際に管理する
    internal var isOpen: Boolean = false
        set(value) {
            if (value == field) return
            field = value
            if (value) {
                IscpLog.d("stream opened. - Downstream[$id]")
                // Subscribe Responses
                this.subscribeDownstreamChunk()
                this.subscribeDownstreamChunkAckComplete()
                this.subscribeDownstreamMetadata()
                // Ack Interval Timer
                if (this.ackInterval > 0) {
                    this.startAckIntervalTimer()
                }
            }
            else {
                IscpLog.d("stream closed. - Downstream[$id]");
                // Unsubscribe Responses
                this.unsubscribeDownstreamChunk()
                this.unsubscribeDownstreamChunkAckComplete()
                this.unsubscribeDownstreamMetadata()
                // Ack Interval Timer
                this.stopAckIntervalTimer()
            }
        }
    // コネクションの配下かどうか
    internal var isRegister: Boolean = true

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        var self = other as? Downstream ?: return false
        if (this.id != self.id) return false
        return true
    }

    internal constructor(
        downstreamFilters: List<DownstreamFilter>,
        expiryInterval: Short,
        qos: QoS,
        omitEmptyChunk: Boolean,
        ackInterval: Long,
        openTimeout: Long,
        closeTimeout: Long,
        connection: Connection,
        alias: UInt,
        dataIdAliasMap: Map<UInt, DataId>,
        dataIdAliasGenerator: AliasGenerator,
        openResponse: DownstreamOpenResponse) {
        this.connection = connection
        this.streamIdAlias = alias
        this.id = openResponse.assignedStreamId
        this.serverTime = openResponse.serverTime
        this.filters = downstreamFilters
        this.expiryInterval = expiryInterval
        this.qos = qos
        this.omitEmptyChunk = omitEmptyChunk
        this.ackInterval = ackInterval
        this.openTimeout = openTimeout
        this.closeTimeout = closeTimeout
        this.dataIdAliasMap = toDataIdAliasesWire(dataIdAliasMap)
        this.dataIdAliasGenerator = dataIdAliasGenerator
        this.resumeToken = openResponse.resumeToken
    }

    internal constructor(downstream: Downstream, connection: Connection, alias: UInt, openResponse: DownstreamOpenResponse) {
        this.connection = connection
        this.streamIdAlias = alias
        this.id = openResponse.assignedStreamId
        this.serverTime = downstream.serverTime
        this.filters = downstream.filters
        this.expiryInterval = downstream.expiryInterval
        this.qos = downstream.qos
        this.omitEmptyChunk = downstream.omitEmptyChunk
        this.ackInterval = downstream.ackInterval
        this.openTimeout = downstream.openTimeout
        this.closeTimeout = downstream.closeTimeout
        this.dataIdAliasMap = downstream.dataIdAliasMap
        this.dataIdAliasGenerator = downstream.dataIdAliasGenerator
        this.resumeToken = openResponse.resumeToken
    }

    /**
     * ダウンストリームを開く際のオプションです。
     * @param downstreamFilters ダウンストリームフィルタのリスト。
     */
    class Option(internal var downstreamFilters: List<DownstreamFilter>) {
        internal var dataIds: List<DataId>? = null
        /**
         * @param dataIds エイリアスを設定するデータIDのリスト。
         */
        fun setDataIds(dataIds: List<DataId>) : Option {
            this.dataIds = dataIds
            return this
        }
        internal var qos: QoS = DEFAULT_QOS
        /**
         * @param qos QoS。現在は `unreliable` のみサポート。
         */
        fun setQos(qos: QoS) : Option {
            this.qos = qos
            return this
        }
        internal var omitEmptyChunk: Boolean = DEFAULT_OMIT_EMPTY_CHUNK
        /**
         * @param omitEmptyChunk 空チャンク省略フラグ。trueの場合、DownstreamChunk内のDataPointGroupsが空の時、DownstreamChunkの送信を省略します。
         */
        fun setOmitEmptyChunk(omitEmptyChunk: Boolean) : Option {
            this.omitEmptyChunk = omitEmptyChunk
            return this
        }
        internal var expiryInterval: Short = DEFAULT_EXPIRY_INTERVAL
        /**
         * @param expiryInterval 有効期限（秒）（UShort）。このストリームが異常切断された時点からの有効期限を表します。最小値の `0` は、異常切断されたと同時に有効期限切れとなることを表します。
         */
        fun setExpiryInterval(expiryInterval: Short) : Option {
            this.expiryInterval = expiryInterval
            return this
        }
        internal var ackInterval: Long = DEFAULT_ACK_INTERVAL
        /**
         * @param ackInterval Ack返却間隔（ミリ秒）。受信したメッセージに対するAckの返却間隔です。
         */
        fun setAckInterval(ackInterval: Long) : Option {
            this.ackInterval = ackInterval
            return this
        }
        internal var openTimeout: Long = DEFAULT_OPEN_TIMEOUT
        /**
         * @param openTimeout オープンのタイムアウト（ミリ秒）。 `0` 以下の場合はタイムアウトしません。
         */
        fun setOpenTimeout(openTimeout: Long) : Option {
            this.openTimeout = openTimeout
            return this
        }
        internal var closeTimeout: Long = DEFAULT_CLOSE_TIMEOUT
        /**
         * @param closeTimeout クローズのタイムアウト（ミリ秒）。 `0` 以下の場合はタイムアウトしません。
         */
        fun setCloseTimeout(closeTimeout: Long) : Option {
            this.closeTimeout = closeTimeout
            return this
        }
    }

    /**
     * ダウンストリームを閉じます。
     */
    fun close() : Exception? {
        val threadLock = ReentrantLock()
        val condition = threadLock.newCondition()
        var resultEx: Exception? = null
        Thread {
            closeAsync { exception ->
                resultEx = exception
                threadLock.withLock {
                    condition.signal()
                }
            }
        }.start()
        threadLock.withLock {
            condition.await()
        }
        return resultEx
    }

    /**
     * ダウンストリームを閉じます。
     * @param completion 処理完了時のコールバック。
     */
    fun closeAsync(completion: ((Exception?) -> Unit)? = null) {
        this.connection.closeDownstream(this, completion)
    }

    /**
     * ダウンストリームの状態を取得します。
     */
    fun getState() : State {
        this.ackBufferLock.withLock {
            var dataIdAlias = toDataIdAliasesStream(this.dataIdAliasMap).toMap()
            var lastIssuedDataIDAlias = this.dataIdAliasGenerator.lastIssued()
            var upstreamInfos = toUpstreamInfosStream(this.upstreamInfoMap).toMap()
            var lastIssuedUpstreamInfoAlias = this.upstreamInfoGenerator.lastIssued()
            var lastIssuedAckId = this.ackIdGenerator.lastIssued()
            return State(
                dataIdAliases = dataIdAlias,
                lastIssuedDataIdAlias = lastIssuedDataIDAlias.toInt(),
                upstreamInfos = upstreamInfos,
                lastIssuedUpstreamInfoAlias = lastIssuedUpstreamInfoAlias.toInt(),
                lastIssuedAckId = lastIssuedAckId.toInt()
            )
        }
    }

    private fun startAckIntervalTimer() {
        this.ackIntervalTimer = Timer()
        this.ackIntervalTimer?.schedule(object : TimerTask() {
            override fun run() {
                // FlushAck
                // Send DownstreamChunkAck
                var ex = connection.sendDownstreamChunkAck(this@Downstream)
                if (ex != null) {
                    IscpLog.e("failed to send downstreamChunkAck. ${ex.message} - Downstream[${id}]")
                }
            }
        }, this.ackInterval, this.ackInterval)
    }

    private fun stopAckIntervalTimer() {
        this.ackIntervalTimer?.let { timer ->
            this.ackIntervalTimer = null
            timer.cancel()
        }
    }

    private fun pushResultAckBuffers(downstreamChunk: com.aptpod.iscp.message.DownstreamChunk) {
        this.ackBufferLock.withLock {
            // chunksResultAckBuffer
            var result = DownstreamChunkResult()
            // upstreamInfoを取得しつつ、upstreamInfoMapAckBufferにデータを追加する
            var upstreamOrAliasCase = downstreamChunk.upstreamOrAliasCase
            if (upstreamOrAliasCase == null) {
                IscpLog.e("upstreamOrAliasCase is null. - Downstream[$id]")
                return@withLock
            }
            var (info, err) = getUpstreamInfoWithPushUpstreamInfoMapAckBuffer(upstreamOrAliasCase, downstreamChunk.upstreamOrAlias!!)
            if (err != null) {
                IscpLog.e("push buffer error. ${err.message} - Downstream[$id]")
                return@withLock
            }
            result.streamIdOfUpstream = info!!.streamId
            result.sequenceNumberInUpstream = downstreamChunk.streamChunk.sequenceNumber
            result.resultCode = ResultCode.SUCCEEDED
            result.resultString = "OK"
            this.chunksResultsAckBuffer.add(result)

            // dataIdMapForAckBuffer
            for (g in downstreamChunk.streamChunk.dataPointGroups) {
                var dataIdOrAliasCase = g.dataIdOrAliasCase
                if (dataIdOrAliasCase == null) {
                    IscpLog.e("dataIdOrAliasCase is null. - Downstream[$id]")
                    continue
                }
                var err2 = this.pushDataIdMapBuffer(dataIdOrAliasCase, g.dataIdOrAlias!!)
                if (err2 != null) {
                    IscpLog.e("push buffer error. ${err2.message} - Downstream[$id]")
                    return@withLock
                }
            }
        }
    }

    private fun pushDataIdMapBuffer(dataIdOrAliasCase: com.aptpod.iscp.message.DataPointGroup.DataIdOrAliasCase, dataIdOrAlias: Any) : Exception? {
        when (dataIdOrAliasCase) {
            com.aptpod.iscp.message.DataPointGroup.DataIdOrAliasCase.DATA_ID_ALIAS -> {
                var alias = dataIdOrAlias as UInt
                if (!this.dataIdAliasMap.keys.contains(alias)) {
                    return IscpException.Unexpected("dataId alias not found.")
                }
            }
            com.aptpod.iscp.message.DataPointGroup.DataIdOrAliasCase.DATA_ID -> {
                var inDataId = dataIdOrAlias as com.aptpod.iscp.message.DataId
                if (!this.dataIdAliasMap.values.contains(inDataId)) {
                    var alias = this.dataIdAliasGenerator.getAndAdd()
                    this.dataIdAliasMap[alias] = inDataId
                    // dataIdMapForAckBuffer
                    this.dataIdMapAckBuffer[alias] = inDataId
                }
            }
        }
        return null
    }

    private fun getUpstreamInfoWithPushUpstreamInfoMapAckBuffer(upstreamOrAliasCase: com.aptpod.iscp.message.DownstreamChunk.UpstreamOrAliasCase, upstreamOrAlias: Any) : Pair<com.aptpod.iscp.message.UpstreamInfo?, Exception?> {
        var outInfo: com.aptpod.iscp.message.UpstreamInfo
        when (upstreamOrAliasCase) {
            com.aptpod.iscp.message.DownstreamChunk.UpstreamOrAliasCase.UPSTREAM_ALIAS -> {
                var alias = upstreamOrAlias as UInt
                if (!this.upstreamInfoMap.keys.contains(alias)) {
                    return Pair(null, IscpException.Unexpected("upstreamInfo alias not found."))
                }
                var inInfo = this.upstreamInfoMap[alias]!!
                outInfo = inInfo
            }
            com.aptpod.iscp.message.DownstreamChunk.UpstreamOrAliasCase.UPSTREAM_INFO -> {
                var inInfo = upstreamOrAlias as com.aptpod.iscp.message.UpstreamInfo
                if (!this.upstreamInfoMap.values.contains(inInfo)) {
                    var alias = this.upstreamInfoGenerator.getAndAdd()
                    this.upstreamInfoMap[alias] = inInfo
                    // upstreamInfoMapAckBuffer
                    this.upstreamInfoMapAckBuffer[alias] = inInfo
                }
                outInfo = inInfo
            }
        }
        return Pair(outInfo, null)
    }

    internal fun dispose() {
        this.stopAckIntervalTimer()
    }

    private fun subscribeDownstreamChunk() {
        // 現在はQoS.Unreliableのみサポート
        when (this.qos) {
            QoS.UNRELIABLE -> {
                this.subscribeDownstreamChunkUnreliable()
            }
            QoS.RELIABLE -> {}
            QoS.PARTIAL -> {}
        }
    }

    private fun unsubscribeDownstreamChunk() {
        this.downstreamChunkReceiver?.let { r ->
            this.downstreamChunkReceiver = null
            this.connection.receivers.unregister(r)
        }
    }

    private fun subscribeDownstreamChunkUnreliable() {
        this.downstreamChunkReceiver?.let { r ->
            this.connection.receivers.unregister(r)
        }
        var receiver = Receiver(0)
        this.downstreamChunkReceiver = receiver
        receiver.subscribe<com.aptpod.iscp.message.DownstreamChunk> { msg, exception ->
            // Receiverは解除しない
            if (msg == null || exception != null) {
                IscpLog.e("failed to receive downstreamChunk. ${exception?.javaClass?.name ?: ""}, streamIdAlias: ${msg?.streamIdAlias?.toString() ?: "null"} - Downstream[$id]")
                return@subscribe
            }
            if (msg.streamIdAlias != this.streamIdAlias) { return@subscribe }
            IscpLog.d("didReceived downstreamChunk(streamIdAlias: ${msg.streamIdAlias}, streamChunk.sequenceNumber: ${msg.streamChunk.sequenceNumber}, streamChunk.dataPointGroups.count: ${msg.streamChunk.dataPointGroups.count()}) - Downstream[$id]")
            // Check: 既に処理済みのsequenceNumberInUpstreamの場合は返却させない？
            var (dmsg, err) = this.messageForDownstream(msg)
            if (err != null) {
                this.callbacks?.onFailWithError(this, err)
                return@subscribe
            }
            // データポイントの取得に成功した
            this.callbacks?.onReceiveChunk(this, dmsg!!)
            // AckBufferへデータ追加
            this.pushResultAckBuffers(msg)
            // AckIntervalが0以下であれば即時返却する
            if (this.ackInterval <= 0) {
                // Send DownstreamChunkAck
                var err2 = this.connection.sendDownstreamChunkAck(this)
                if (err2 != null) {
                    IscpLog.e("failed to send downstreamChunkAck. ${err2.message} - Downstream[$id]")
                }
            }
        }
        // Receiverを登録
        this.connection.receivers.register(receiver)
    }

    private fun messageForDownstream(msg: com.aptpod.iscp.message.DownstreamChunk) : Pair<DownstreamChunk?, Exception?> {
        var res = DownstreamChunk()
        res.sequenceNumber = msg.streamChunk.sequenceNumber.toInt()
        // dataPointGroups
        var outDataPointGroups = mutableListOf<DataPointGroup>()
        for (inGroup in msg.streamChunk.dataPointGroups) {
            var outGroup = DataPointGroup()
            var outDataId = DataId()

            // dataId
            var inDataId: com.aptpod.iscp.message.DataId
            when (inGroup.dataIdOrAliasCase) {
                com.aptpod.iscp.message.DataPointGroup.DataIdOrAliasCase.DATA_ID -> {
                    var dataId = inGroup.dataId!!
                    inDataId = dataId
                }
                com.aptpod.iscp.message.DataPointGroup.DataIdOrAliasCase.DATA_ID_ALIAS -> {
                    var inDataIdAlias = inGroup.dataIdAlias!!
                    if (!this.dataIdAliasMap.keys.contains(inDataIdAlias)) {
                        return Pair(null, IscpException.Unexpected("dataId alias not found."))
                    }
                    inDataId = this.dataIdAliasMap[inDataIdAlias]!!
                }
                else -> {
                    return Pair(null, IscpException.Unexpected())
                }
            }
            outDataId.name = inDataId.name
            outDataId.type = inDataId.type
            outGroup.dataId = outDataId

            // dataPointGroup
            var outDataPoints = mutableListOf<DataPoint>()
            for (inDataPoint in inGroup.dataPoints) {
                var outDataPoint = DataPoint()
                outDataPoint.elapsedTime = inDataPoint.elapsedTime
                outDataPoint.payload = inDataPoint.payload
                outDataPoints.add(outDataPoint)
            }
            outGroup.dataPoints = outDataPoints
            outDataPointGroups.add(outGroup)
        }
        res.dataPointGroups = outDataPointGroups.toList()

        // upstreamInfo
        var upstreamInfo: com.aptpod.iscp.message.UpstreamInfo
        when (msg.upstreamOrAliasCase) {
            com.aptpod.iscp.message.DownstreamChunk.UpstreamOrAliasCase.UPSTREAM_INFO -> {
                var inUpstreamInfo = msg.upstreamInfo!!
                upstreamInfo = inUpstreamInfo
            }
            com.aptpod.iscp.message.DownstreamChunk.UpstreamOrAliasCase.UPSTREAM_ALIAS -> {
                var inUpstreamAlias = msg.upstreamAlias!!
                if (!this.upstreamInfoMap.keys.contains(inUpstreamAlias)) {
                    return Pair(null, IscpException.Unexpected("upstreamInfo alias not found."))
                }
                var inUpstreamInfo = this.upstreamInfoMap[inUpstreamAlias]!!
                upstreamInfo = inUpstreamInfo
            }
            else -> {
                return Pair(null, IscpException.Unexpected())
            }
        }
        res.upstreamInfo.sessionId = upstreamInfo.sessionId
        res.upstreamInfo.streamId = upstreamInfo.streamId
        res.upstreamInfo.sourceNodeId = upstreamInfo.sourceNodeId

        // downstreamFilterReferences
        res.downstreamFilterReferences = msg.downstreamFilterReferences.map { refs ->
            DownstreamFilterReferences(
                references = refs.references.map { r ->
                    DownstreamFilterReference(
                        downstreamFilterIndex = r.downstreamFilterIndex.toInt(),
                        dataFilterIndex = r.dataFilterIndex.toInt()
                    )
                }
            )
        }

        return Pair(res, null)
    }

    private fun subscribeDownstreamChunkAckComplete() {
        this.downstreamChunkAckCompleteReceiver?.let { r ->
            this.connection.receivers.unregister(r)
        }
        var receiver = Receiver(0)
        this.downstreamChunkAckCompleteReceiver = receiver
        receiver.subscribe<DownstreamChunkAckComplete> { msg, exception ->
            // Receiverは解除しない
            if (msg == null || exception != null) {
                IscpLog.e("failed to receive downstreamChunkAckComplete. ${exception?.javaClass?.name ?: ""}, streamIdAlias: ${msg?.streamIdAlias?.toString() ?: "null"}, ackId: ${msg?.ackId?.toString() ?: "null"} - Downstream[$id]")
                return@subscribe
            }
            if (msg.streamIdAlias != this.streamIdAlias) { return@subscribe }
            IscpLog.d("didReceived downstreamChunkAckComplete(streamIdAlias: ${msg.streamIdAlias}, ackId: ${msg.ackId}) - Downstream[$id]")
        }
        // Receiverを登録
        this.connection.receivers.register(receiver)
    }

    private fun unsubscribeDownstreamChunkAckComplete() {
        this.downstreamChunkAckCompleteReceiver?.let { r ->
            this.downstreamChunkAckCompleteReceiver = null
            this.connection.receivers.unregister(r)
        }
    }

    private fun subscribeDownstreamMetadata() {
        this.downstreamMetadataReceiver?.let { r ->
            this.connection.receivers.unregister(r)
        }
        var receiver = Receiver(0)
        this.downstreamMetadataReceiver = receiver
        receiver.subscribe<com.aptpod.iscp.message.DownstreamMetadata> { msg, exception ->
            // Receiverは解除しない
            if (msg == null || exception != null) {
                IscpLog.e("failed to receive downstreamMetadata. ${exception?.javaClass?.name ?: ""}, requestId: ${msg?.requestId?.toString() ?: "null"} - Downstream[$id]")
                return@subscribe
            }
            if (msg.streamIdAlias != this.streamIdAlias) { return@subscribe }
            IscpLog.d("didReceived downstreamMetadata(requestId: ${msg.requestId}) - Downstream[$id]")
            var (dmsg, err) = toDownstreamMetadataStream(msg)
            if (err != null) {
                this.callbacks?.onFailWithError(this, err)
                return@subscribe
            }
            this.callbacks?.onReceiveMetadata(this, dmsg!!)
            // Send DownstreamMetadataAck
            var err2 = this.connection.sendDownstreamMetadataAck(msg.requestId, ResultCode.SUCCEEDED, "OK")
            if (err2 != null) {
                IscpLog.e("failed to send downstreamMetadataAck. ${err2.message} - Downstream[$id]")
            }
        }
        // Receiverを登録
        this.connection.receivers.register(receiver)
    }

    private fun unsubscribeDownstreamMetadata() {
        this.downstreamMetadataReceiver?.let { r ->
            this.downstreamMetadataReceiver = null
            this.connection.receivers.unregister(r)
        }
    }

    /**
     * ダウンストリームの状態を表します。
     * @param dataIdAliases データIDエイリアスとデータIDのマップ（Map(UInt, DataId)）。
     * @param lastIssuedDataIdAlias 最後に払い出されたデータIDエイリアス（UInt）。
     * @param upstreamInfos アップストリームエイリアスとアップストリーム情報のマップ（Map(UInt, UpstreamInfo)）。
     * @param lastIssuedUpstreamInfoAlias 最後に払い出されたアップストリーム情報のエイリアス（UInt）。
     * @param lastIssuedAckId 最後に払い出されたAckID（UInt）。
     */
    data class State internal constructor(
        var dataIdAliases: Map<Int, DataId>,
        var lastIssuedDataIdAlias: Int,
        var upstreamInfos: Map<Int, UpstreamInfo>,
        var lastIssuedUpstreamInfoAlias: Int,
        var lastIssuedAckId: Int
    ) {
        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            var self = other as? State ?: return false
            if (!this.dataIdAliases.equals(self.dataIdAliases)) return false
            if (this.lastIssuedDataIdAlias != self.lastIssuedDataIdAlias) return false
            if (!this.upstreamInfos.equals(self.upstreamInfos)) return false
            if (this.lastIssuedUpstreamInfoAlias != self.lastIssuedUpstreamInfoAlias) return false
            if (this.lastIssuedAckId != self.lastIssuedAckId) return false
            return true
        }
    }
}