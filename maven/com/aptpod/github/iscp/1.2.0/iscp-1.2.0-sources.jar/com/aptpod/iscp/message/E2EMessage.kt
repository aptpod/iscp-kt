package com.aptpod.iscp.message

/**
 * @param callId コールID
 * @param requestCallId リクエストコールID
 * @param sourceNodeId 送信元ノードID
 * @param name 名称
 * @param type 型
 * @param payload ペイロード
 * @param extensionFields 拡張フィールド
 */
internal class DownstreamCall(
    var callId: String = "",
    var requestCallId: String = "",
    var sourceNodeId: String = "",
    var name: String = "",
    var type: String = "",
    var payload: ByteArray = ByteArray(0),
    var extensionFields: ExtensionFields = ExtensionFields()
) : IMessage {

    class ExtensionFields {

        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            var self = other as? ExtensionFields ?: return false
            return true
        }
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        var self = other as? DownstreamCall ?: return false
        if (this.callId != self.callId) return false
        if (this.requestCallId != self.requestCallId) return false
        if (this.sourceNodeId != self.sourceNodeId) return false
        if (this.name != self.name) return false
        if (this.type != self.type) return false
        if (!this.payload.contentEquals(self.payload)) return false
        if (!this.extensionFields.equals(self.extensionFields)) return false
        return true
    }
}

/**
 * @param callId コールID
 * @param requestCallId リクエストコールID
 * @param destinationNodeId 宛先ノードID
 * @param name 名称
 * @param type 型
 * @param payload ペイロード
 * @param extensionFields 拡張フィールド
 */
internal class UpstreamCall(
    var callId: String = "",
    var requestCallId: String = "",
    var destinationNodeId: String = "",
    var name: String = "",
    var type: String = "",
    var payload: ByteArray = ByteArray(0),
    var extensionFields: DownstreamCall.ExtensionFields = DownstreamCall.ExtensionFields()
) : IMessage {

    class ExtensionFields {

        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            var self = other as? ExtensionFields ?: return false
            return true
        }
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        var self = other as? UpstreamCall ?: return false
        if (this.callId != self.callId) return false
        if (this.requestCallId != self.requestCallId) return false
        if (this.destinationNodeId != self.destinationNodeId) return false
        if (this.name != self.name) return false
        if (this.type != self.type) return false
        if (!this.payload.contentEquals(self.payload)) return false
        if (!this.extensionFields.equals(self.extensionFields)) return false
        return true
    }
}

/**
 * @param callId コールID
 * @param resultCode 結果コード
 * @param resultString 結果文字列
 * @param extensionFields 拡張フィールド
 *
 */
internal class UpstreamCallAck(
    var callId: String = "",
    var resultCode: ResultCode = ResultCode.SUCCEEDED,
    var resultString: String = "",
    var extensionFields: ExtensionFields = ExtensionFields()
) : IMessage {

    class ExtensionFields {

        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            var self = other as? ExtensionFields ?: return false
            return true
        }
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        var self = other as? UpstreamCallAck ?: return false
        if (this.callId != self.callId) return false
        if (this.resultCode != self.resultCode) return false
        if (this.resultString != self.resultString) return false
        if (!this.extensionFields.equals(self.extensionFields)) return false
        return true
    }
}