package com.aptpod.iscp.extensions

internal fun String.toMaskString(head: Int = 8, tail: Int = 0, maskChar: String = "*") : String {
    if (this.isEmpty()) return this
    if (this.length <= head + tail) return this
    val maskLength = this.length - (head + tail)
    val headStr = this.take(head)
    val tailStr = this.takeLast(tail)
    val mask = maskChar.repeat(maskLength)
    return headStr + mask + tailStr
}