package com.aptpod.iscp.helpers

import java.util.concurrent.locks.ReentrantLock
import kotlin.concurrent.withLock

/**
 * シーケンス番号を生成するクラスです。
 */
class SequenceNumberGenerator {

    companion object {
        /**
         * 最大値。
         */
        const val MAX_VALUE: UInt = UInt.MAX_VALUE
        /**
         * 初期値。
         */
        const val INITIAL_VALUE: ULong = 0u
    }

    private var currentValue: ULong = 0u
    private var requestIdLock: ReentrantLock = ReentrantLock()

    /**
     * @param current 初期値。
     */
    constructor(current: ULong = INITIAL_VALUE) {
        this.currentValue = current
    }

    /**
     * 次のシーケンス番号を取得します。
     *
     * 数値が最大に到達している場合は `null` を返却します。
     */
    fun next(): UInt? {
        this.requestIdLock.withLock {
            if (this.currentValue + 1u > MAX_VALUE) {
                return null
            }
            this.currentValue += 1u
            return this.currentValue.toUInt()
        }
    }

    /**
     * 現在のシーケンス番号を返します。
     */
    fun current() : UInt {
        this.requestIdLock.withLock {
            return this.currentValue.toUInt()
        }
    }
}