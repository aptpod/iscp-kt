package com.aptpod.iscp.connection

import com.aptpod.iscp.logger.IscpLog
import com.aptpod.iscp.message.Pong
import com.aptpod.iscp.transport.Receiver
import java.util.Timer
import java.util.TimerTask

internal class DisconnectChecker {

    internal var connection: Connection? = null
    internal val pingTimeout: Long?
        get() {
            if (connection == null) return null
            return connection!!.pingTimeout.toLong() * 1000
        }
    internal val pingInterval: Long?
        get() {
            if (connection == null) return null
            return connection!!.pingInterval.toLong() * 1000
        }

    internal var timeoutHandler: (() -> Unit)? = null

    private var timeoutTimer: Timer? = null
    private var sendPingTimer: Timer? = null
    private var receiver: Receiver? = null
    private var currentRequestId: UInt? = null

    internal fun register(connection: Connection, timeoutHandler: () -> Unit) {
        this.connection = connection
        this.timeoutHandler = timeoutHandler
        var receiver = Receiver(0)
        receiver.subscribe<Pong> { msg, exception ->
            // Receiverは解除しない
            if (msg == null || exception != null) {
                IscpLog.e("failed to receive pong. ${exception?.message ?: ""} - DisconnectChecker")
                return@subscribe
            }
            IscpLog.d("onReceived pong(requestId: ${msg.requestId}) - DisconnectChecker")
            if (msg.requestId == this.currentRequestId) {
                // 正常にPongを受信した
                this.stopTimeoutTimer()
            }
        }
        // Receiverを登録
        this.connection?.receivers?.register(receiver)
        this.receiver = receiver
    }

    internal fun unregister() {
        this.timeoutHandler = null
        this.receiver?.let { r ->
            this.receiver = null
            // Receiverを解除
            this.connection?.receivers?.unregister(r)
        }
        this.stopTimerAll()
        this.connection = null
    }

    fun startSendPingTimer() {
        var interval = this.pingInterval ?: return
        if (interval <= 0) return
        this.sendPingTimer?.let { t -> t.cancel() }
        this.sendPingTimer = Timer()
        this.sendPingTimer?.schedule(object : TimerTask() {
            override fun run() {
                if (connection?.isOpen == false) return
                IscpLog.d("sendPingTimerOnFire - DisconnectChecker")
                sendPingMessage()
            }
        }, interval, interval)
    }

    fun stopTimerAll() {
        this.sendPingTimer?.let { timer ->
            timer.cancel()
        }
        this.sendPingTimer = null
        this.stopTimeoutTimer()
    }

    fun startTimeoutTimer() {
        var timeout = this.pingTimeout ?: return
        if (timeout <= 0) return
        this.timeoutTimer?.let { t -> t.cancel() }
        this.timeoutTimer = Timer()
        this.timeoutTimer?.schedule(object : TimerTask() {
            override fun run() {
                IscpLog.d("timeoutTimerOnFire - DisconnectChecker")
                timeoutHandler?.invoke()
            }
        }, timeout)
    }


    fun stopTimeoutTimer() {
        this.timeoutTimer?.let { t ->
            t.cancel()
        }
        this.timeoutTimer = null
    }

    fun sendPingMessage() {
        var requestId: UInt = this.connection?.requestIdGenerator?.generate() ?: return
        this.currentRequestId = requestId
        this.startTimeoutTimer()
        var exception = this.connection?.sendPing(requestId)
        if (exception != null) {
            IscpLog.e("failed to send ping. ${exception.message} - DisconnectChecker")
        }
    }

    fun dispose() {
        try {
            unregister()
        }
        catch (e: Exception) {
            IscpLog.e("dispose error. ${e.message} - DisconnectChecker")
        }
    }
}