package com.aptpod.iscp.transport

import com.aptpod.iscp.encoding.EncodingName

/**
 * ネゴシエーションパラメータです。
 */
class NegotiationParams {

    var encodingName: EncodingName = EncodingName.PROTOBUF

    /**
     * コンストラクタ。
     */
    constructor() {}

    /**
     * コンストラクタ。
     * @param encodingName エンコーディング名。
     */
    constructor(encodingName: EncodingName) {
        this.encodingName = encodingName
    }

    fun toQueryString() : String {
        val values = mutableListOf<String>()
        values.add("enc=${encodingName.value}")
        return values.joinToString("&")
    }

    fun toQueryParameters() : Map<String, String> {
        val map = mutableMapOf<String, String>()
        map["enc"] = encodingName.value
        return map
    }
}