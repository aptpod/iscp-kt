package com.aptpod.iscp.encoding.convert

import com.aptpod.iscp.encoding.autogen.iscp2.v1.Message as ProtoMessage
import com.aptpod.iscp.encoding.autogen.iscp2.v1.ResultCode as ProtoResultCode
import com.aptpod.iscp.encoding.autogen.iscp2.v1.DataID
import com.aptpod.iscp.encoding.autogen.iscp2.v1.QoS as ProtoQoS
import com.aptpod.iscp.encoding.autogen.iscp2.v1.DownstreamFilter as ProtoDownstreamFilter
import com.aptpod.iscp.encoding.autogen.iscp2.v1.DataFilter as ProtoDataFilter
import com.aptpod.iscp.encoding.autogen.iscp2.v1.StreamChunk as ProtoStreamChunk
import com.aptpod.iscp.encoding.autogen.iscp2.v1.DataPointGroup as ProtoDataPointGroup
import com.aptpod.iscp.encoding.autogen.iscp2.v1.DataPoint as ProtoDataPoint
import com.aptpod.iscp.encoding.autogen.iscp2.v1.DownstreamChunk as ProtoDownstreamChunk
import com.aptpod.iscp.encoding.autogen.iscp2.v1.DownstreamMetadata as ProtoDownstreamMetadata
import com.aptpod.iscp.encoding.autogen.iscp2.v1.UpstreamChunkResult as ProtoUpstreamChunkResult
import com.google.protobuf.ByteString
import com.aptpod.iscp.model.IscpException
import com.aptpod.iscp.helpers.toUuid
import com.aptpod.iscp.message.*
import java.util.UUID

internal fun protoToWire(inMsg: ProtoMessage) : Pair<IMessage?, Exception?> {
    when (inMsg.messageCase) {
        ProtoMessage.MessageCase.CONNECT_REQUEST -> {
            // WireToProto only
        }
        ProtoMessage.MessageCase.CONNECT_RESPONSE -> {
            var inDat = inMsg.connectResponse
            var (rc, err) = toResultCode(inDat.resultCode)
            if (err != null) {
                return Pair(null, err)
            }
            var outDat = ConnectResponse()
            outDat.requestId = inDat.requestId.toUInt()
            outDat.protocolVersion = inDat.protocolVersion
            outDat.resultCode = rc!!
            outDat.resultString = inDat.resultString
            return Pair(outDat, null)
        }
        ProtoMessage.MessageCase.DISCONNECT -> {
            var inDat = inMsg.disconnect
            var (rc, err) = toResultCode(inDat.resultCode)
            if (err != null) {
                return Pair(null, err)
            }
            var outDat = Disconnect()
            outDat.resultCode = rc!!
            outDat.resultString = inDat.resultString
            return Pair(outDat, null)
        }
        ProtoMessage.MessageCase.UPSTREAM_OPEN_REQUEST -> {
            // WireToProto only
        }
        ProtoMessage.MessageCase.UPSTREAM_OPEN_RESPONSE -> {
            var inDat = inMsg.upstreamOpenResponse
            var (rc, err) = toResultCode(inDat.resultCode)
            if (err != null) {
                return Pair(null, err)
            }
            var (sid, err2) = toUuid(inDat.assignedStreamId)
            if (err2 != null) {
                return Pair(null, err2)
            }
            var outDat = UpstreamOpenResponse()
            outDat.requestId = inDat.requestId.toUInt()
            outDat.assignedStreamId = sid!!
            outDat.assignedStreamIdAlias = inDat.assignedStreamIdAlias.toUInt()
            outDat.resultCode = rc!!
            outDat.resultString = inDat.resultString
            outDat.serverTime = inDat.serverTime
            outDat.dataIdAliases = toDataIdAliases(inDat.dataIdAliasesMap)
            outDat.resumeToken = inDat.resumeToken
            return Pair(outDat, null)
        }
        ProtoMessage.MessageCase.UPSTREAM_RESUME_REQUEST -> {
            // WireToProto only
        }
        ProtoMessage.MessageCase.UPSTREAM_RESUME_RESPONSE -> {
            var inDat = inMsg.upstreamResumeResponse
            var (rc, err) = toResultCode(inDat.resultCode)
            if (err != null) {
                return Pair(null, err)
            }
            var outDat = UpstreamResumeResponse()
            outDat.requestId = inDat.requestId.toUInt()
            outDat.assignedStreamIdAlias = inDat.assignedStreamIdAlias.toUInt()
            outDat.resultCode = rc!!
            outDat.resultString = inDat.resultString
            outDat.resumeToken = inDat.resumeToken
            return Pair(outDat, null)
        }
        ProtoMessage.MessageCase.UPSTREAM_CLOSE_REQUEST -> {
            // WireToProto only
        }
        ProtoMessage.MessageCase.UPSTREAM_CLOSE_RESPONSE -> {
            var inDat = inMsg.upstreamCloseResponse
            var (rc, err) = toResultCode(inDat.resultCode)
            if (err != null) {
                return Pair(null, err)
            }
            var outDat = UpstreamCloseResponse()
            outDat.requestId = inDat.requestId.toUInt()
            outDat.resultCode = rc!!
            outDat.resultString = inDat.resultString
            return Pair(outDat, null)
        }
        ProtoMessage.MessageCase.UPSTREAM_CHUNK -> {
            // WireToProto only
        }
        ProtoMessage.MessageCase.UPSTREAM_CHUNK_ACK -> {
            var inDat = inMsg.upstreamChunkAck
            var (res, err) = toUpstreamChunkResults(inDat.resultsList)
            if (err != null) {
                return Pair(null, err)
            }
            var outDat = UpstreamChunkAck()
            outDat.streamIdAlias = inDat.streamIdAlias.toUInt()
            outDat.results = res!!
            outDat.dataIdAliases = toDataIdAliases(inDat.dataIdAliasesMap)
            return Pair(outDat, null)
        }
        ProtoMessage.MessageCase.UPSTREAM_METADATA -> {
            // WireToProto only
        }
        ProtoMessage.MessageCase.UPSTREAM_METADATA_ACK -> {
            var inDat = inMsg.upstreamMetadataAck
            var (rc, err) = toResultCode(inDat.resultCode)
            if (err != null) {
                return Pair(null, err)
            }
            var outDat = UpstreamMetadataAck()
            outDat.requestId = inDat.requestId.toUInt()
            outDat.resultCode = rc!!
            outDat.resultString = inDat.resultString
            return Pair(outDat, null)
        }
        ProtoMessage.MessageCase.DOWNSTREAM_OPEN_REQUEST -> {
            // WireToProto only
        }
        ProtoMessage.MessageCase.DOWNSTREAM_OPEN_RESPONSE -> {
            var inDat = inMsg.downstreamOpenResponse
            var (rc, err) = toResultCode(inDat.resultCode)
            if (err != null) {
                return Pair(null, err)
            }
            var (sid, err2) = toUuid(inDat.assignedStreamId)
            if (err2 != null) {
                return Pair(null, err2)
            }
            var outDat = DownstreamOpenResponse()
            outDat.requestId = inDat.requestId.toUInt()
            outDat.assignedStreamId = sid!!
            outDat.resultCode = rc!!
            outDat.resultString = inDat.resultString
            outDat.serverTime = inDat.serverTime
            outDat.resumeToken = inDat.resumeToken
            return Pair(outDat, null)
        }
        ProtoMessage.MessageCase.DOWNSTREAM_RESUME_REQUEST -> {
            // WireToProto only
        }
        ProtoMessage.MessageCase.DOWNSTREAM_RESUME_RESPONSE -> {
            var inDat = inMsg.downstreamResumeResponse
            var (rc, err) = toResultCode(inDat.resultCode)
            if (err != null) {
                return Pair(null, err)
            }
            var outDat = DownstreamResumeResponse()
            outDat.requestId = inDat.requestId.toUInt()
            outDat.resultCode = rc!!
            outDat.resultString = inDat.resultString
            outDat.resumeToken = inDat.resumeToken
            return Pair(outDat, null)
        }
        ProtoMessage.MessageCase.DOWNSTREAM_CLOSE_REQUEST -> {
            // WireToProto only
        }
        ProtoMessage.MessageCase.DOWNSTREAM_CLOSE_RESPONSE -> {
            var inDat = inMsg.downstreamCloseResponse
            var (rc, err) = toResultCode(inDat.resultCode)
            if (err != null) {
                return Pair(null, err)
            }
            var outDat = DownstreamCloseResponse()
            outDat.requestId = inDat.requestId.toUInt()
            outDat.resultCode = rc!!
            outDat.resultString = inDat.resultString
            return Pair(outDat, null)
        }
        ProtoMessage.MessageCase.DOWNSTREAM_CHUNK -> {
            var inDat = inMsg.downstreamChunk
            var (upstreamOrAliasCase, upstreamOrAlias, err) = toUpstreamOrAlias(inDat)
            if (err != null) {
                return Pair(null, err)
            }
            var outDat = DownstreamChunk()
            outDat.streamIdAlias = inDat.streamIdAlias.toUInt()
            outDat.upstreamOrAliasCase = upstreamOrAliasCase
            outDat.upstreamOrAlias = upstreamOrAlias
            outDat.streamChunk = toStreamChunk(inDat.streamChunk)
            outDat.downstreamFilterReferences = toDownstreamFilterReferencesList(inDat.downstreamFilterReferencesList)
            return Pair(outDat, null)
        }
        ProtoMessage.MessageCase.DOWNSTREAM_CHUNK_ACK -> {
            // WireToProto only
        }
        ProtoMessage.MessageCase.DOWNSTREAM_CHUNK_ACK_COMPLETE -> {
            var inDat = inMsg.downstreamChunkAckComplete
            var (rc, err) = toResultCode(inDat.resultCode)
            if (err != null) {
                return Pair(null, err)
            }
            var outDat = DownstreamChunkAckComplete()
            outDat.streamIdAlias = inDat.streamIdAlias.toUInt()
            outDat.ackId = inDat.ackId.toUInt()
            outDat.resultCode = rc!!
            outDat.resultString = inDat.resultString
            return Pair(outDat, null)
        }
        ProtoMessage.MessageCase.DOWNSTREAM_METADATA -> {
            var inDat = inMsg.downstreamMetadata
            var (metadataCase, metadata, err) = toDownstreamMetadata(inDat)
            if (err != null) {
                return Pair(null, err)
            }
            var outDat = DownstreamMetadata()
            outDat.requestId = inDat.requestId.toUInt()
            outDat.streamIdAlias = inDat.streamIdAlias.toUInt()
            outDat.sourceNodeId = inDat.sourceNodeId
            outDat.metadataCase = metadataCase
            outDat.metadata = metadata
            return Pair(outDat, null)
        }
        ProtoMessage.MessageCase.DOWNSTREAM_METADATA_ACK -> {
            // WireToProto only
        }
        ProtoMessage.MessageCase.PING -> {
            var inDat = inMsg.ping
            var outDat = Ping()
            outDat.requestId = inDat.requestId.toUInt()
            return Pair(outDat, null)
        }
        ProtoMessage.MessageCase.PONG -> {
            var inDat = inMsg.pong
            var outDat = Pong()
            outDat.requestId = inDat.requestId.toUInt()
            return Pair(outDat, null)
        }
        ProtoMessage.MessageCase.UPSTREAM_CALL -> {
            // WireToProto only
        }
        ProtoMessage.MessageCase.UPSTREAM_CALL_ACK -> {
            var inDat = inMsg.upstreamCallAck
            var (rc, err) = toResultCode(inDat.resultCode)
            if (err != null) {
                return Pair(null, err)
            }
            var outDat = UpstreamCallAck()
            outDat.callId = inDat.callId
            outDat.resultCode = rc!!
            outDat.resultString = inDat.resultString
            return Pair(outDat, null)
        }
        ProtoMessage.MessageCase.DOWNSTREAM_CALL -> {
            var inDat = inMsg.downstreamCall
            var outDat = DownstreamCall()
            outDat.callId = inDat.callId
            outDat.requestCallId = inDat.requestCallId
            outDat.sourceNodeId = inDat.sourceNodeId
            outDat.name = inDat.name
            outDat.type = inDat.type
            outDat.payload = inDat.payload.toByteArray()
            return Pair(outDat, null)
        }
        else -> {}
    }
    return Pair(null, IscpException.MalformedMessage())
}

internal fun toResultCode(code: ProtoResultCode) : Pair<ResultCode?, Exception?> {
    when (code) {
        ProtoResultCode.SUCCEEDED -> return Pair(ResultCode.SUCCEEDED, null)
        ProtoResultCode.INCOMPATIBLE_VERSION -> return Pair(ResultCode.INCOMPATIBLE_VERSION, null)
        ProtoResultCode.MAXIMUM_DATA_ID_ALIAS -> return Pair(ResultCode.MAXIMUM_DATA_ID_ALIAS, null)
        ProtoResultCode.MAXIMUM_UPSTREAM_ALIAS -> return Pair(ResultCode.MAXIMUM_UPSTREAM_ALIAS, null)
        ProtoResultCode.UNSPECIFIED_ERROR -> return Pair(ResultCode.UNSPECIFIED_ERROR, null)
        ProtoResultCode.NO_NODE_ID -> return Pair(ResultCode.NO_NODE_ID, null)
        ProtoResultCode.AUTH_FAILED -> return Pair(ResultCode.AUTH_FAILED, null)
        ProtoResultCode.CONNECT_TIMEOUT -> return Pair(ResultCode.CONNECT_TIMEOUT, null)
        ProtoResultCode.MALFORMED_MESSAGE -> return Pair(ResultCode.MALFORMED_MESSAGE, null)
        ProtoResultCode.PROTOCOL_ERROR -> return Pair(ResultCode.PROTOCOL_ERROR, null)
        ProtoResultCode.ACK_TIMEOUT -> return Pair(ResultCode.ACK_TIMEOUT, null)
        ProtoResultCode.INVALID_PAYLOAD -> return Pair(ResultCode.INVALID_PAYLOAD, null)
        ProtoResultCode.INVALID_DATA_ID -> return Pair(ResultCode.INVALID_DATA_ID, null)
        ProtoResultCode.INVALID_DATA_ID_ALIAS -> return Pair(ResultCode.INVALID_DATA_ID_ALIAS, null)
        ProtoResultCode.INVALID_DATA_FILTER -> return Pair(ResultCode.INVALID_DATA_FILTER, null)
        ProtoResultCode.STREAM_NOT_FOUND -> return Pair(ResultCode.STREAM_NOT_FOUND, null)
        ProtoResultCode.RESUME_REQUEST_CONFLICT -> return Pair(ResultCode.RESUME_REQUEST_CONFLICT, null)
        ProtoResultCode.PROCESS_FAILED -> return Pair(ResultCode.PROCESS_FAILED, null)
        ProtoResultCode.DESIRED_QOS_NOT_SUPPORTED -> return Pair(ResultCode.DESIRED_QOS_NOT_SUPPORTED, null)
        ProtoResultCode.PING_TIMEOUT -> return Pair(ResultCode.PING_TIMEOUT, null)
        ProtoResultCode.TOO_LARGE_MESSAGE_SIZE -> return Pair(ResultCode.TOO_LARGE_MESSAGE_SIZE, null)
        ProtoResultCode.TOO_MANY_DATA_ID_ALIASES -> return Pair(ResultCode.TOO_MANY_DATA_ID_ALIASES, null)
        ProtoResultCode.TOO_MANY_STREAMS -> return Pair(ResultCode.TOO_MANY_STREAMS, null)
        ProtoResultCode.TOO_LONG_ACK_INTERVAL -> return Pair(ResultCode.TOO_LONG_ACK_INTERVAL, null)
        ProtoResultCode.TOO_MANY_DOWNSTREAM_FILTERS -> return Pair(ResultCode.TOO_MANY_DOWNSTREAM_FILTERS, null)
        ProtoResultCode.TOO_MANY_DATA_FILTERS -> return Pair(ResultCode.TOO_MANY_DATA_FILTERS, null)
        ProtoResultCode.TOO_LONG_EXPIRY_INTERVAL -> return Pair(ResultCode.TOO_LONG_EXPIRY_INTERVAL, null)
        ProtoResultCode.TOO_LONG_PING_TIMEOUT -> return Pair(ResultCode.TOO_LONG_PING_TIMEOUT, null)
        ProtoResultCode.TOO_SHORT_PING_INTERVAL -> return Pair(ResultCode.TOO_SHORT_PING_INTERVAL, null)
        ProtoResultCode.TOO_SHORT_PING_TIMEOUT -> return Pair(ResultCode.TOO_SHORT_PING_TIMEOUT, null)
        ProtoResultCode.RATE_LIMIT_REACHED -> return Pair(ResultCode.RATE_LIMIT_REACHED, null)
        ProtoResultCode.TOO_LARGE_FEED_ID -> return Pair(ResultCode.TOO_LARGE_FEED_ID, null)
        ProtoResultCode.TOO_MANY_TARGET_NODES -> return Pair(ResultCode.TOO_MANY_TARGET_NODES, null)
        ProtoResultCode.FEED_NOT_FOUND -> return Pair(ResultCode.FEED_NOT_FOUND, null)
        ProtoResultCode.INVALID_RESUME_TOKEN -> return Pair(ResultCode.INVALID_RESUME_TOKEN, null)
        ProtoResultCode.NODE_ID_MISMATCH -> return Pair(ResultCode.NODE_ID_MISMATCH, null)
        ProtoResultCode.SESSION_NOT_FOUND -> return Pair(ResultCode.SESSION_NOT_FOUND, null)
        ProtoResultCode.SESSION_ALREADY_CLOSED -> return Pair(ResultCode.SESSION_ALREADY_CLOSED, null)
        ProtoResultCode.SESSION_CANNOT_CLOSED -> return Pair(ResultCode.SESSION_CANNOT_CLOSED, null)
        ProtoResultCode.UNRECOGNIZED -> {}
    }
    return Pair(null, IscpException.MalformedMessage())
}

internal fun toUpstreamOrAlias(chunk: ProtoDownstreamChunk) : Triple<DownstreamChunk.UpstreamOrAliasCase?, Any?, Exception?> {
    when (chunk.upstreamOrAliasCase) {
        ProtoDownstreamChunk.UpstreamOrAliasCase.UPSTREAM_INFO -> {
            var inDat = chunk.upstreamInfo
            var (sid, err) = toUuid(inDat.streamId)
            if (err != null) {
                return Triple(null, null, err)
            }
            var outDat = UpstreamInfo()
            outDat.sourceNodeId = inDat.sourceNodeId
            outDat.sessionId = inDat.sessionId
            outDat.streamId = sid!!
            return Triple(DownstreamChunk.UpstreamOrAliasCase.UPSTREAM_INFO, outDat,null)
        }
        ProtoDownstreamChunk.UpstreamOrAliasCase.UPSTREAM_ALIAS -> {
            var inDat = chunk.upstreamAlias
            return Triple(DownstreamChunk.UpstreamOrAliasCase.UPSTREAM_ALIAS, inDat.toUInt(),null)
        }
        else -> {}
    }
    return Triple(null, null, IscpException.MalformedMessage())
}

internal fun toUuid(data: ByteString) : Pair<UUID?, Exception?> {
    return Pair(data.toUuid(), null)
}

internal fun toDownstreamMetadata(metadata: ProtoDownstreamMetadata) : Triple<DownstreamMetadata.MetadataCase?, Any?, Exception?> {
    when (metadata.metadataCase) {
        ProtoDownstreamMetadata.MetadataCase.BASE_TIME -> {
            var inDat = metadata.baseTime
            var outDat = BaseTime()
            outDat.sessionId = inDat.sessionId
            outDat.name = inDat.name
            outDat.priority = inDat.priority.toUByte()
            outDat.elapsedTime = inDat.elapsedTime
            outDat.baseTime = inDat.baseTime
            return Triple(DownstreamMetadata.MetadataCase.BASE_TIME, outDat, null)
        }
        ProtoDownstreamMetadata.MetadataCase.UPSTREAM_OPEN -> {
            var inDat = metadata.upstreamOpen
            var (qos, err) = toQos(inDat.qos)
            if (err != null) {
                return Triple(null, null, err)
            }
            var (sid, err2) = toUuid(inDat.streamId)
            if (err2 != null) {
                return Triple(null, null, err2)
            }
            var outDat = UpstreamOpen()
            outDat.streamId = sid!!
            outDat.sessionId = inDat.sessionId
            outDat.qos = qos!!
            return Triple(DownstreamMetadata.MetadataCase.UPSTREAM_OPEN, outDat, null)
        }
        ProtoDownstreamMetadata.MetadataCase.UPSTREAM_ABNORMAL_CLOSE -> {
            var inDat = metadata.upstreamAbnormalClose
            var (sid, err) = toUuid(inDat.streamId)
            if (err != null) {
                return Triple(null, null, err)
            }
            var outDat = UpstreamAbnormalClose()
            outDat.streamId = sid!!
            outDat.sessionId = inDat.sessionId
            return Triple(DownstreamMetadata.MetadataCase.UPSTREAM_ABNORMAL_CLOSE, outDat, null)
        }
        ProtoDownstreamMetadata.MetadataCase.UPSTREAM_NORMAL_CLOSE -> {
            var inDat = metadata.upstreamNormalClose
            var (sid, err) = toUuid(inDat.streamId)
            if (err != null) {
                return Triple(null, null, err)
            }
            var outDat = UpstreamNormalClose()
            outDat.streamId = sid!!
            outDat.sessionId = inDat.sessionId
            outDat.totalDataPoints = inDat.totalDataPoints.toULong()
            outDat.finalSequenceNumber = inDat.finalSequenceNumber.toUInt()
            return Triple(DownstreamMetadata.MetadataCase.UPSTREAM_NORMAL_CLOSE, outDat, null)
        }
        ProtoDownstreamMetadata.MetadataCase.DOWNSTREAM_OPEN -> {
            var inDat = metadata.downstreamOpen
            var (qos, err) = toQos(inDat.qos)
            if (err != null) {
                return Triple(null, null, err)
            }
            var (sid, err2) = toUuid(inDat.streamId)
            if (err2 != null) {
                return Triple(null, null, err2)
            }
            var outDat = DownstreamOpen()
            outDat.streamId = sid!!
            outDat.downstreamFilters = toDownstreamFilters(inDat.downstreamFiltersList)
            outDat.qos = qos!!
            return Triple(DownstreamMetadata.MetadataCase.DOWNSTREAM_OPEN, outDat, null)
        }
        ProtoDownstreamMetadata.MetadataCase.DOWNSTREAM_ABNORMAL_CLOSE -> {
            var inDat = metadata.downstreamAbnormalClose
            var (sid, err) = toUuid(inDat.streamId)
            if (err != null) {
                return Triple(null, null, err)
            }
            var outDat = DownstreamAbnormalClose()
            outDat.streamId = sid!!
            return Triple(DownstreamMetadata.MetadataCase.DOWNSTREAM_ABNORMAL_CLOSE, outDat, null)
        }
        ProtoDownstreamMetadata.MetadataCase.DOWNSTREAM_RESUME -> {
            var inDat = metadata.downstreamResume
            var (qos, err) = toQos(inDat.qos)
            if (err != null) {
                return Triple(null, null, err)
            }
            var (sid, err2) = toUuid(inDat.streamId)
            if (err2 != null) {
                return Triple(null, null, err2)
            }
            var outDat = DownstreamResume()
            outDat.streamId = sid!!
            outDat.downstreamFilters = toDownstreamFilters(inDat.downstreamFiltersList)
            outDat.qos = qos!!
            return Triple(DownstreamMetadata.MetadataCase.DOWNSTREAM_RESUME, outDat, null)
        }
        ProtoDownstreamMetadata.MetadataCase.DOWNSTREAM_NORMAL_CLOSE -> {
            var inDat = metadata.downstreamNormalClose
            var (sid, err) = toUuid(inDat.streamId)
            if (err != null) {
                return Triple(null, null, err)
            }
            var outDat = DownstreamNormalClose()
            outDat.streamId = sid!!
            return Triple(DownstreamMetadata.MetadataCase.DOWNSTREAM_NORMAL_CLOSE, outDat, null)
        }
        ProtoDownstreamMetadata.MetadataCase.UPSTREAM_RESUME -> {
            var inDat = metadata.upstreamResume
            var (sid, err) = toUuid(inDat.streamId)
            if (err != null) {
                return Triple(null, null, err)
            }
            var outDat = UpstreamResume()
            outDat.streamId = sid!!
            outDat.sessionId = inDat.sessionId
            return Triple(DownstreamMetadata.MetadataCase.UPSTREAM_RESUME, outDat, null)
        }
        else -> {}
    }
    return Triple(null, null, IscpException.MalformedMessage())
}

internal fun toStreamChunk(streamChunk: ProtoStreamChunk) : StreamChunk {
    var nv = StreamChunk()
    nv.sequenceNumber = streamChunk.sequenceNumber.toUInt()
    nv.dataPointGroups = toDataPointGroups(streamChunk.dataPointGroupsList)
    return nv
}

internal fun toDataPointGroups(groups: List<ProtoDataPointGroup>) : List<DataPointGroup> {
    var res = mutableListOf<DataPointGroup>()
    for (g in groups) {
        res.add(toDataPointGroup(g))
    }
    return res.toList()
}

internal fun toDataPointGroup(group: ProtoDataPointGroup) : DataPointGroup {
    var res = DataPointGroup()
    res.dataPoints = toDataPoints(group.dataPointsList)
    when (group.dataIdOrAliasCase) {
        ProtoDataPointGroup.DataIdOrAliasCase.DATA_ID -> {
            var (dataIdAliasCase, dataIdAlias) = toDataIdOrAlias(group.dataIdOrAliasCase, group.dataId)
            res.dataIdOrAliasCase = dataIdAliasCase
            res.dataIdOrAlias = dataIdAlias
        }
        ProtoDataPointGroup.DataIdOrAliasCase.DATA_ID_ALIAS -> {
            var (dataIdAliasCase, dataIdAlias) = toDataIdOrAlias(group.dataIdOrAliasCase, group.dataIdAlias)
            res.dataIdOrAliasCase = dataIdAliasCase
            res.dataIdOrAlias = dataIdAlias
        }
        else -> {}
    }
    return res
}

internal fun toDataIdOrAlias(idOrAliasCase: ProtoDataPointGroup.DataIdOrAliasCase, idOrAlias: Any?) : Pair<DataPointGroup.DataIdOrAliasCase?, Any?> {
    when (idOrAliasCase) {
        ProtoDataPointGroup.DataIdOrAliasCase.DATA_ID -> {
            var dataId = idOrAlias as DataID
            var nv = DataId()
            nv.name = dataId.name
            nv.type = dataId.type
            return Pair(DataPointGroup.DataIdOrAliasCase.DATA_ID, nv)
        }
        ProtoDataPointGroup.DataIdOrAliasCase.DATA_ID_ALIAS -> {
            var alias = idOrAlias as? Int
            return Pair(DataPointGroup.DataIdOrAliasCase.DATA_ID_ALIAS, alias?.toUInt())
        }
        else -> {}
    }
    return Pair(null, null)
}

internal fun toDataPoints(dataPoints: List<ProtoDataPoint>) : MutableList<DataPoint> {
    var res = mutableListOf<DataPoint>()
    for (p in dataPoints) {
        var v = DataPoint()
        v.elapsedTime = p.elapsedTime
        v.payload = p.payload.toByteArray()
        res.add(v)
    }
    return res
}

internal fun toDataIdAliases(dic: Map<Int, DataID>) : MutableMap<UInt, DataId> {
    var res: MutableMap<UInt, DataId> = mutableMapOf()
    for (kv in dic) {
        var nv = DataId()
        nv.name = kv.value.name
        nv.type = kv.value.type
        res[kv.key.toUInt()] = nv
    }
    return res
}

internal fun toQos(qos: ProtoQoS) : Pair<QoS?, Exception?> {
    when (qos) {
        ProtoQoS.RELIABLE -> return Pair(QoS.RELIABLE, null)
        ProtoQoS.UNRELIABLE -> return Pair(QoS.UNRELIABLE, null)
        ProtoQoS.PARTIAL -> return Pair(QoS.PARTIAL, null)
        else -> {}
    }
    return Pair(null, IscpException.MalformedMessage())
}

internal fun toDownstreamFilterReferencesList(refs: List<com.aptpod.iscp.encoding.autogen.iscp2.v1.DownstreamFilterReferences>) : List<DownstreamFilterReferences> {
    var res = mutableListOf<DownstreamFilterReferences>()
    for (v in refs) {
        var nv = DownstreamFilterReferences()
        nv.references = toDownstreamFilterReferenceList(v.referencesList)
        res.add(nv)
    }
    return res.toList()
}

internal fun toDownstreamFilterReferenceList(refs: List<com.aptpod.iscp.encoding.autogen.iscp2.v1.DownstreamFilterReference>) : List<DownstreamFilterReference> {
    var res = mutableListOf<DownstreamFilterReference>()
    for (v in refs) {
        var nv = DownstreamFilterReference()
        nv.downstreamFilterIndex = v.downstreamFilterIndex.toUInt()
        nv.dataFilterIndex = v.dataFilterIndex.toUInt()
        res.add(nv)
    }
    return res.toList()
}

internal fun toDownstreamFilters(filters: List<ProtoDownstreamFilter>) : List<DownstreamFilter> {
    var res = mutableListOf<DownstreamFilter>()
    for (v in filters) {
        var nv = DownstreamFilter()
        nv.sourceNodeId = v.sourceNodeId
        nv.dataFilters = toDataFilters(v.dataFiltersList)
        res.add(nv)
    }
    return res.toList()
}

internal fun toDataFilters(filters: List<ProtoDataFilter>) : List<DataFilter> {
    var res = mutableListOf<DataFilter>()
    for (v in filters) {
        var nv = DataFilter()
        nv.name = v.name
        nv.type = v.type
        res.add(nv)
    }
    return res.toList()
}

internal fun toUpstreamChunkResults(results: List<ProtoUpstreamChunkResult>) : Pair<List<UpstreamChunkResult>?, Exception?> {
    var res = mutableListOf<UpstreamChunkResult>()
    for (r in results) {
        var (rc, err) = toResultCode(r.resultCode)
        if (err != null) {
            return Pair(null, err)
        }
        var nv = UpstreamChunkResult()
        nv.sequenceNumber = r.sequenceNumber.toUInt()
        nv.resultCode = rc!!
        nv.resultString = r.resultString
        res.add(nv)
    }
    return Pair(res.toList(), null)
}
