package com.aptpod.iscp.message

import com.aptpod.iscp.helpers.UUIDUtils
import java.util.UUID

//region Message

/**
 * @param requestId リクエストID
 * @param metadataCase メタデータ
 * @param extensionFields 拡張フィールド
 */
internal class UpstreamMetadata(
    var requestId: UInt = 0u,
    var metadataCase: MetadataCase? = null,
    var metadata: Any? = null,
    var extensionFields: ExtensionFields = ExtensionFields(),
) : IMessage {
    /**
     * @param persist 永続化フラグ
     */
    class ExtensionFields(
        var persist: Boolean = false
    ) {
        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            var self = other as? ExtensionFields ?: return false
            if (this.persist != self.persist) return false
            return true
        }
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        var self = other as? UpstreamMetadata ?: return false
        if (this.requestId != self.requestId) return false
        // メタデータ
        if (!this.extensionFields.equals(self.extensionFields)) return false
        return true
    }

    enum class MetadataCase {
        BASE_TIME
    }

    var baseTime: BaseTime?
        get() = if (metadataCase == MetadataCase.BASE_TIME) metadata as? BaseTime else null
        set(value) {
            metadata = value
            metadataCase = if (value == null) null else MetadataCase.BASE_TIME
        }
}

/**
 * @param requestId リクエストID
 * @param resultCode 結果コード
 * @param resultString 結果文字列
 * @param extensionFields 拡張フィールド
 */
internal class UpstreamMetadataAck(
    var requestId: UInt = 0u,
    var resultCode: ResultCode = ResultCode.SUCCEEDED,
    var resultString: String = "",
    var extensionFields: ExtensionFields = ExtensionFields()
) : IMessage {

    class ExtensionFields {

        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            var self = other as? ExtensionFields ?: return false
            return true
        }
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        var self = other as? UpstreamMetadataAck ?: return false
        if (this.requestId != self.requestId) return false
        if (this.resultCode != self.resultCode) return false
        if (this.resultString != self.resultString) return false
        if (!this.extensionFields.equals(self.extensionFields)) return false
        return true
    }
}

/**
 * @param requestId リクエストID
 * @param streamIdAlias ストリームIDエイリアス
 * @param sourceNodeId 生成元ノードID
 * @param metadataCase メタデータ
 * @param extensionFields 拡張フィールド
 */
internal class DownstreamMetadata(
    var requestId: UInt = 0u,
    var streamIdAlias: UInt = 0u,
    var sourceNodeId: String = "",
    metadataCase: MetadataCase? = null,
    var extensionFields: ExtensionFields = ExtensionFields()
) : IMessage {
    /**
     * メタデータ
     */
    var metadataCase: MetadataCase? = metadataCase
        internal set

    class ExtensionFields {

        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            var self = other as? ExtensionFields ?: return false
            return true
        }
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        var self = other as? DownstreamMetadata ?: return false
        if (this.requestId != self.requestId) return false
        if (this.streamIdAlias != self.streamIdAlias) return false
        if (this.metadataCase != self.metadataCase) return false
        if (this.metadata != self.metadata) return false
        if (!this.extensionFields.equals(self.extensionFields)) return false
        return true
    }

    enum class MetadataCase {
        BASE_TIME,
        UPSTREAM_OPEN,
        UPSTREAM_ABNORMAL_CLOSE,
        UPSTREAM_RESUME,
        UPSTREAM_NORMAL_CLOSE,
        DOWNSTREAM_OPEN,
        DOWNSTREAM_ABNORMAL_CLOSE,
        DOWNSTREAM_RESUME,
        DOWNSTREAM_NORMAL_CLOSE
    }
    internal var metadata: Any? = null

    var baseTime: BaseTime?
        get() = if (metadataCase == MetadataCase.BASE_TIME) metadata as? BaseTime else null
        set(value) {
            metadata = value
            metadataCase = if (value == null) null else MetadataCase.BASE_TIME
        }

    var upstreamOpen: UpstreamOpen?
        get() = if (metadataCase == MetadataCase.UPSTREAM_OPEN) metadata as? UpstreamOpen else null
        set(value) {
            metadata = value
            metadataCase = if (value == null) null else MetadataCase.UPSTREAM_OPEN
        }

    var upstreamAbnormalClose: UpstreamAbnormalClose?
        get() = if (metadataCase == MetadataCase.UPSTREAM_ABNORMAL_CLOSE) metadata as? UpstreamAbnormalClose else null
        set(value) {
            metadata = value
            metadataCase = if (value == null) null else MetadataCase.UPSTREAM_ABNORMAL_CLOSE
        }

    var upstreamResume: UpstreamResume?
        get() = if (metadataCase == MetadataCase.UPSTREAM_RESUME) metadata as? UpstreamResume else null
        set(value) {
            metadata = value
            metadataCase = if (value == null) null else MetadataCase.UPSTREAM_RESUME
        }

    var upstreamNormalClose: UpstreamNormalClose?
        get() = if (metadataCase == MetadataCase.UPSTREAM_NORMAL_CLOSE) metadata as? UpstreamNormalClose else null
        set(value) {
            metadata = value
            metadataCase = if (value == null) null else MetadataCase.UPSTREAM_NORMAL_CLOSE
        }

    var downstreamOpen: DownstreamOpen?
        get() = if (metadataCase == MetadataCase.DOWNSTREAM_OPEN) metadata as? DownstreamOpen else null
        set(value) {
            metadata = value
            metadataCase = if (value == null) null else MetadataCase.DOWNSTREAM_OPEN
        }

    var downstreamAbnormalClose: DownstreamAbnormalClose?
        get() = if (metadataCase == MetadataCase.DOWNSTREAM_ABNORMAL_CLOSE) metadata as? DownstreamAbnormalClose else null
        set(value) {
            metadata = value
            metadataCase = if (value == null) null else MetadataCase.DOWNSTREAM_ABNORMAL_CLOSE
        }

    var downstreamResume: DownstreamResume?
        get() = if (metadataCase == MetadataCase.DOWNSTREAM_RESUME) metadata as? DownstreamResume else null
        set(value) {
            metadata = value
            metadataCase = if (value == null) null else MetadataCase.DOWNSTREAM_RESUME
        }

    var downstreamNormalClose: DownstreamNormalClose?
        get() = if (metadataCase == MetadataCase.DOWNSTREAM_NORMAL_CLOSE) metadata as? DownstreamNormalClose else null
        set(value) {
            metadata = value
            metadataCase = if (value == null) null else MetadataCase.DOWNSTREAM_NORMAL_CLOSE
        }
}

/**
 * @param requestId リクエストID
 * @param resultCode 結果コード
 * @param resultString 結果文字列
 * @param extensionFields 拡張フィールド
 */
internal class DownstreamMetadataAck(
    var requestId: UInt = 0u,
    var resultCode: ResultCode = ResultCode.SUCCEEDED,
    var resultString: String = "",
    var extensionFields: ExtensionFields = ExtensionFields()
) : IMessage {

    class ExtensionFields {

        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            var self = other as? ExtensionFields ?: return false
            return true
        }
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        var self = other as? DownstreamMetadataAck ?: return false
        if (this.requestId != self.requestId) return false
        if (this.resultCode != self.resultCode) return false
        if (this.resultString != self.resultString) return false
        if (!this.extensionFields.equals(self.extensionFields)) return false
        return true
    }
}

//endregion

//region Metadata

/**
 * @param sessionId セッションID
 * @param name 基準時刻の名称
 * @param priority 優先度
 * @param elapsedTime 経過時間
 *
 * 単位はナノ秒
 * @param baseTime 基準時刻
 *
 * 単位はナノ秒
 */
internal class BaseTime(
    var sessionId: String = "",
    var name: String = "",
    var priority: UByte = 0u,
    var elapsedTime: Long = 0,
    var baseTime: Long = 0
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        var self = other as? BaseTime ?: return false
        if (this.sessionId != self.sessionId) return false
        if (this.name != self.name) return false
        if (this.priority != self.priority) return false
        if (this.elapsedTime != self.elapsedTime) return false
        if (this.baseTime != self.baseTime) return false
        return true
    }
}

/**
 * @param streamId ストリームID
 */
internal class DownstreamAbnormalClose(
    var streamId: UUID = UUIDUtils.empty()
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        var self = other as? DownstreamAbnormalClose ?: return false
        if (this.streamId != self.streamId) return false
        return true
    }
}

/**
 * @param streamId ストリームID
 */
internal class DownstreamNormalClose(
    var streamId: UUID = UUIDUtils.empty()
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        var self = other as? DownstreamNormalClose ?: return false
        if (this.streamId != self.streamId) return false
        return true
    }
}

/**
 * @param streamId ストリームID
 * @param downstreamFilters ダウンストリームフィルタのリスト
 * @param qos QoS
 */
internal class DownstreamOpen(
    var streamId: UUID = UUIDUtils.empty(),
    var downstreamFilters: List<DownstreamFilter> = listOf(),
    var qos: QoS = QoS.UNRELIABLE
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        var self = other as? DownstreamOpen ?: return false
        if (this.streamId != self.streamId) return false
        if (!this.downstreamFilters.equals(self.downstreamFilters)) return false
        if (this.qos != self.qos) return false
        return true
    }
}

/**
 * @param streamId ストリームID
 * @param downstreamFilters ダウンストリームフィルタのリスト
 * @param qos QoS
 */
internal class DownstreamResume(
    var streamId: UUID = UUIDUtils.empty(),
    var downstreamFilters: List<DownstreamFilter> = listOf(),
    var qos: QoS = QoS.UNRELIABLE
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        var self = other as? DownstreamResume ?: return false
        if (this.streamId != self.streamId) return false
        if (!this.downstreamFilters.equals(self.downstreamFilters)) return false
        if (this.qos != self.qos) return false
        return true
    }
}

/**
 * @param streamId ストリームID
 * @param sessionId セッションID
 */
internal class UpstreamAbnormalClose(
    var streamId: UUID = UUIDUtils.empty(),
    var sessionId: String = "",

) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        var self = other as? UpstreamAbnormalClose ?: return false
        if (this.streamId != self.streamId) return false
        if (this.sessionId != self.sessionId) return false
        return true
    }
}

/**
 * @param streamId ストリームID
 * @param sessionId セッションID
 * @param totalDataPoints 総データポイント数
 * @param finalSequenceNumber 最終シーケンス番号
 */
internal class UpstreamNormalClose(
    var streamId: UUID = UUIDUtils.empty(),
    var sessionId: String = "",
    var totalDataPoints: ULong = 0u,
    var finalSequenceNumber: UInt = 0u
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        var self = other as? UpstreamNormalClose ?: return false
        if (this.streamId != self.streamId) return false
        if (this.sessionId != self.sessionId) return false
        if (this.totalDataPoints != self.totalDataPoints) return false
        if (this.finalSequenceNumber != self.finalSequenceNumber) return false
        return true
    }
}

/**
 * @param streamId ストリームID
 * @param sessionId セッションID
 * @param qos QoS
 */
internal class UpstreamOpen(
    var streamId: UUID = UUIDUtils.empty(),
    var sessionId: String = "",
    var qos: QoS = QoS.UNRELIABLE
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        var self = other as? UpstreamOpen ?: return false
        if (this.streamId != self.streamId) return false
        if (this.sessionId != self.sessionId) return false
        if (this.qos != self.qos) return false
        return true
    }
}

/**
 * @param streamId ストリームID
 * @param sessionId セッションID
 */
internal class UpstreamResume(
    var streamId: UUID = UUIDUtils.empty(),
    var sessionId: String = ""
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        var self = other as? UpstreamResume ?: return false
        if (this.streamId != self.streamId) return false
        if (this.sessionId != self.sessionId) return false
        return true
    }
}

//endregion