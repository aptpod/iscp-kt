package com.aptpod.iscp.transport

@Deprecated(
    message = "ITransportConfig has been renamed to IConnector.",
    replaceWith = ReplaceWith("IConnector"),
    level = DeprecationLevel.WARNING
)
interface ITransportConfig: IConnector {}

/**
 * トランスポートの処理イベントです。
 */
interface TransportCallbacks {
    /**
     * サーバーとの接続に成功した際にコールしてください。
     */
    fun onConnect(transport: ITransport)

    /**
     * サーバーと切断された際にコールしてください。
     */
    fun onDisconnect(transport: ITransport)

    /**
     * サーバーとの接続でエラーが発生した際にコールしてください。
     */
    fun onFailWithError(transport: ITransport, exception: Exception)

    /**
     * サーバーからメッセージを受信した際にコールしてください。
     */
    fun onReceiveMessage(transport: ITransport, data: ByteArray)
}

/**
 * トランスポートを管理する基底インタフェースです。
 */
interface ITransport {
    /**
     * トランスポートの名前。
     */
    val name: String
    /**
     * アドレス。
     */
    var address: String?
    /**
     * ネゴシエーションパラメータ。
     */
    var negotiationParams: NegotiationParams?
    /**
     * トランスポートで利用するメソッドです。
     */
    var callbacks: TransportCallbacks?
    /**
     * 接続中かどうか。
     */
    val isConnecting: Boolean

    /**
     * サーバーとの接続を切断する際にコールされるメソッドです。
     * @param completion 処理完了時のコールバック。
     */
    fun close(completion: ((exception: Exception?) -> Unit)? = null)

    /**
     * サーバーへのデータ書き込み要求です。
     * @param data サーバーへ書き込むデータ。
     * @return 書き込み処理中に発生したエラー。エラーが発生しなかった場合は `null` を返します。
     */
    fun write(data: ByteArray) : Exception?
}

/**
 * iSCPコネクターのインターフェースです。
 */
interface IConnector {
    /**
     * サーバーへ接続する際にコールされるメソッドです。
     * @param address 接続先のアドレス。 `127.0.0.1:8080` 形式。
     * @param negotiationParams ネゴシエーションパラメータ。
     * @param completion 処理完了時のコールバック。
     */
    fun connect(address: String, negotiationParams: NegotiationParams, completion: (transport: ITransport?, exception: Exception?) -> Unit)
}