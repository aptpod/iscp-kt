package com.aptpod.iscp.stream

import com.aptpod.iscp.model.IscpException
import com.aptpod.iscp.model.BaseTime
import com.aptpod.iscp.model.DataFilter
import com.aptpod.iscp.model.DataId
import com.aptpod.iscp.model.DownstreamAbnormalClose
import com.aptpod.iscp.model.DownstreamCall
import com.aptpod.iscp.model.DownstreamFilter
import com.aptpod.iscp.model.DownstreamMetadata
import com.aptpod.iscp.model.DownstreamNormalClose
import com.aptpod.iscp.model.DownstreamOpen
import com.aptpod.iscp.model.DownstreamReplyCall
import com.aptpod.iscp.model.DownstreamResume
import com.aptpod.iscp.model.QoS
import com.aptpod.iscp.model.UpstreamAbnormalClose
import com.aptpod.iscp.model.UpstreamInfo
import com.aptpod.iscp.model.UpstreamNormalClose
import com.aptpod.iscp.model.UpstreamOpen
import com.aptpod.iscp.model.UpstreamResume

internal fun toQosStream(qos: com.aptpod.iscp.message.QoS) : Pair<QoS?, Exception?> {
    return when (qos) {
        com.aptpod.iscp.message.QoS.UNRELIABLE -> Pair(QoS.UNRELIABLE, null)
        com.aptpod.iscp.message.QoS.RELIABLE -> Pair(QoS.RELIABLE, null)
        com.aptpod.iscp.message.QoS.PARTIAL -> Pair(QoS.PARTIAL, null)
    }
}

internal fun toDownstreamFiltersStream(filters: List<com.aptpod.iscp.message.DownstreamFilter>) : List<DownstreamFilter> {
    var res = mutableListOf<DownstreamFilter>()
    for (f in filters) {
        var v = toDownstreamFilterStream(f)
        res.add(v)
    }
    return res.toList()
}

internal fun toDownstreamFilterStream(filter: com.aptpod.iscp.message.DownstreamFilter) : DownstreamFilter {
    var v = DownstreamFilter()
    v.sourceNodeId = filter.sourceNodeId
    v.dataFilters = toDataFiltersStream(filter.dataFilters)
    return v
}

internal fun toDataFiltersStream(filters: List<com.aptpod.iscp.message.DataFilter>) : List<DataFilter> {
    var res = mutableListOf<DataFilter>()
    for (f in filters) {
        var v = toDataFilterStream(f)
        res.add(v)
    }
    return res
}

internal fun toDataFilterStream(filter: com.aptpod.iscp.message.DataFilter) : DataFilter {
    var res = DataFilter()
    res.name = filter.name
    res.type = filter.type
    return res
}

internal fun toDownstreamMetadataStream(msg: com.aptpod.iscp.message.DownstreamMetadata) : Pair<DownstreamMetadata?, Exception?> {
    var res = DownstreamMetadata()
    res.sourceNodeId = msg.sourceNodeId
    // metadata
    when (msg.metadataCase) {
        com.aptpod.iscp.message.DownstreamMetadata.MetadataCase.BASE_TIME -> {
            var inDat = msg.baseTime!!
            var outDat = BaseTime()
            outDat.sessionId = inDat.sessionId
            outDat.name = inDat.name
            outDat.priority = inDat.priority.toByte()
            outDat.elapsedTime = inDat.elapsedTime
            outDat.baseTime = inDat.baseTime
            res.baseTime = outDat
        }
        com.aptpod.iscp.message.DownstreamMetadata.MetadataCase.UPSTREAM_OPEN -> {
            var inDat = msg.upstreamOpen!!
            var (qos, err) = toQosStream(inDat.qos)
            if (err != null) {
                return Pair(null, err)
            }
            var outDat = UpstreamOpen()
            outDat.streamId = inDat.streamId
            outDat.sessionId = inDat.sessionId
            outDat.qos = qos!!
            res.upstreamOpen = outDat
        }
        com.aptpod.iscp.message.DownstreamMetadata.MetadataCase.UPSTREAM_ABNORMAL_CLOSE -> {
            var inDat = msg.upstreamAbnormalClose!!
            var outDat = UpstreamAbnormalClose()
            outDat.streamId = inDat.streamId
            outDat.sessionId = inDat.sessionId
            res.upstreamAbnormalClose = outDat
        }
        com.aptpod.iscp.message.DownstreamMetadata.MetadataCase.UPSTREAM_RESUME -> {
            var inDat = msg.upstreamResume!!
            var outDat = UpstreamResume()
            outDat.streamId = inDat.streamId
            outDat.sessionId = inDat.sessionId
            res.upstreamResume = outDat
        }
        com.aptpod.iscp.message.DownstreamMetadata.MetadataCase.UPSTREAM_NORMAL_CLOSE -> {
            var inDat = msg.upstreamNormalClose!!
            var outDat = UpstreamNormalClose()
            outDat.streamId = inDat.streamId
            outDat.sessionId = inDat.sessionId
            outDat.totalDataPoints = inDat.totalDataPoints.toLong()
            outDat.finalSequenceNumber = inDat.finalSequenceNumber.toInt()
            res.upstreamNormalClose = outDat
        }
        com.aptpod.iscp.message.DownstreamMetadata.MetadataCase.DOWNSTREAM_OPEN -> {
            var inDat = msg.downstreamOpen!!
            var (qos, err) = toQosStream(inDat.qos)
            if (err != null) {
                return Pair(null, err)
            }
            var outDat = DownstreamOpen()
            outDat.streamId = inDat.streamId
            outDat.downstreamFilters = toDownstreamFiltersStream(inDat.downstreamFilters)
            outDat.qos = qos!!
            res.downstreamOpen = outDat
        }
        com.aptpod.iscp.message.DownstreamMetadata.MetadataCase.DOWNSTREAM_ABNORMAL_CLOSE -> {
            var inDat = msg.downstreamAbnormalClose!!
            var outDat = DownstreamAbnormalClose()
            outDat.streamId = inDat.streamId
            res.downstreamAbnormalClose = outDat
        }
        com.aptpod.iscp.message.DownstreamMetadata.MetadataCase.DOWNSTREAM_RESUME -> {
            var inDat = msg.downstreamResume!!
            var (qos, err) = toQosStream(inDat.qos)
            if (err != null) {
                return Pair(null, err)
            }
            var outDat = DownstreamResume()
            outDat.streamId = inDat.streamId
            outDat.downstreamFilters = toDownstreamFiltersStream(inDat.downstreamFilters)
            outDat.qos = qos!!
            res.downstreamResume = outDat
        }
        com.aptpod.iscp.message.DownstreamMetadata.MetadataCase.DOWNSTREAM_NORMAL_CLOSE -> {
            var inDat = msg.downstreamNormalClose!!
            var outDat = DownstreamNormalClose()
            outDat.streamId = inDat.streamId
            res.downstreamNormalClose = outDat
        }
        else -> {
            return Pair(null, IscpException.MalformedMessage())
        }
    }
    return Pair(res, null)
}

internal fun toUpstreamInfosStream(infos: Map<UInt, com.aptpod.iscp.message.UpstreamInfo>) : Map<Int, UpstreamInfo> {
    var res = mutableMapOf<Int, UpstreamInfo>()
    for (kv in infos) {
        res[kv.key.toInt()] = toUpstreamInfoStream(kv.value)
    }
    return res.toMap()
}

internal fun toUpstreamInfoStream(info: com.aptpod.iscp.message.UpstreamInfo) : UpstreamInfo {
    var res = UpstreamInfo()
    res.sessionId = info.sessionId
    res.sourceNodeId = info.sourceNodeId
    res.streamId = info.streamId
    return res
}

internal fun toDataIdAliasesStream(aliases: Map<UInt, com.aptpod.iscp.message.DataId>) : Map<Int, DataId> {
    var res = mutableMapOf<Int, DataId>()
    for (kv in aliases) {
        res[kv.key.toInt()] = toDataIdStream(kv.value)
    }
    return res.toMap()
}

internal fun toDataIdsStream(dataIds: List<com.aptpod.iscp.message.DataId>) : List<DataId> {
    var res = mutableListOf<DataId>()
    for (d in dataIds) {
        var v = toDataIdStream(d)
        res.add(v)
    }
    return res.toList()
}

internal fun toDataIdStream(dataId: com.aptpod.iscp.message.DataId) : DataId {
    var res = DataId()
    res.name = dataId.name
    res.type = dataId.type
    return res
}

internal fun toDownstreamCallStream(downstreamCall: com.aptpod.iscp.message.DownstreamCall) : DownstreamCall {
    var msg = DownstreamCall(
        callId = downstreamCall.callId,
        sourceNodeId = downstreamCall.sourceNodeId,
        name = downstreamCall.name,
        type = downstreamCall.type,
        payload = downstreamCall.payload
    )
    return msg
}

internal fun toDownstreamReplyCallStream(downstreamCall: com.aptpod.iscp.message.DownstreamCall) : DownstreamReplyCall {
    var msg = DownstreamReplyCall(
        requestCallId = downstreamCall.requestCallId,
        sourceNodeId = downstreamCall.sourceNodeId,
        name = downstreamCall.name,
        type = downstreamCall.type,
        payload = downstreamCall.payload
    )
    return msg
}

