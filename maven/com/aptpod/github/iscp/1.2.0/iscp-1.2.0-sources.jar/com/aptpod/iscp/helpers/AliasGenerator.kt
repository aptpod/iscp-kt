package com.aptpod.iscp.helpers

import java.util.concurrent.locks.ReentrantLock
import kotlin.concurrent.withLock

internal class AliasGenerator {

    companion object {
        val MAX_VALUE: ULong = UInt.MAX_VALUE.toULong()
    }

    private var initialValue: ULong
    private var currentValue: ULong
    private var lastIssuedValue: UInt = 0u
    private var requestIdLock: ReentrantLock = ReentrantLock()

    constructor(initialValue: UInt) {
        this.initialValue = initialValue.toULong()
        this.currentValue = initialValue.toULong()
    }

    constructor(initialValue: UInt, current: UInt) {
        this.initialValue = initialValue.toULong()
        this.currentValue = current.toULong()
        this.lastIssuedValue = current
    }

    fun getAndAdd(): UInt {
        this.requestIdLock.withLock {
            var id = this.currentValue
            this.currentValue += 1u
            if (this.currentValue > MAX_VALUE) {
                this.currentValue = this.initialValue
            }
            this.lastIssuedValue = id.toUInt()
            return id.toUInt()
        }
    }

    fun current() : UInt {
        this.requestIdLock.withLock {
            return this.currentValue.toUInt()
        }
    }

    fun lastIssued() : UInt {
        this.requestIdLock.withLock {
            return this.lastIssuedValue
        }
    }
}