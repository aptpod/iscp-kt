package com.aptpod.iscp.stream

import com.aptpod.iscp.helpers.SequenceNumberGenerator
import com.aptpod.iscp.model.IscpException
import com.aptpod.iscp.connection.Connection
import com.aptpod.iscp.connection.closeUpstream
import com.aptpod.iscp.connection.sendUpstreamChunk
import com.aptpod.iscp.model.DataId
import com.aptpod.iscp.model.DataPoint
import com.aptpod.iscp.model.DataPointGroup
import com.aptpod.iscp.model.FlushPolicy
import com.aptpod.iscp.model.QoS
import com.aptpod.iscp.model.UpstreamChunk
import com.aptpod.iscp.model.UpstreamChunkAck
import com.aptpod.iscp.logger.IscpLog
import com.aptpod.iscp.message.UpstreamOpenResponse
import com.aptpod.iscp.transport.Receiver
import java.util.Timer
import java.util.TimerTask
import java.util.UUID
import java.util.concurrent.locks.ReentrantLock
import kotlin.concurrent.withLock

/**
 * アップストリームで発生するイベントのコールバックです。
 */
interface UpstreamCallbacks {
    /**
     * 送信するアップストリームチャンクが作成される度にコールされます。
     * @param upstream アップストリーム。
     * @param message 送信予定のアップストリームチャンク。
     */
    fun onGenerateChunk(upstream: Upstream, message: UpstreamChunk)

    /**
     * 送信したアップストリームチャンクがサーバーへ到達しレスポンスを受信できた際にコールされます。
     * @param upstream アップストリーム。
     * @param message 送信したアップストリームチャンクの確認応答。
     */
    fun onReceiveAck(upstream: Upstream, message: UpstreamChunkAck)

    /**
     * エラーが発生した際にコールされます。
     * @param upstream アップストリーム。
     * @param error エラー情報。
     */
    fun onFailWithError(upstream: Upstream, error: Exception)

    /**
     * このストリームがエラーによりクローズされた際にコールされます。
     * @param upstream アップストリーム。
     * @param error エラー情報。
     */
    fun onCloseWithError(upstream: Upstream, error: Exception)

    /**
     * このストリームの再開処理が成功した際にコールされます。
     * @param upstream アップストリーム。
     */
    fun onResume(upstream: Upstream)
}

/**
 * アップストリームを表すクラスです。
 */
class Upstream {

    companion object {
        /**
         * QoSのデフォルト値。
         */
        @JvmField
        val DEFAULT_QOS = QoS.UNRELIABLE
        /**
         * 永続化するかどうかのデフォルト値。
         */
        const val DEFAULT_PERSIST: Boolean = false
        /**
         * オープンのタイムアウトのデフォルト値（ミリ秒）。
         */
        const val DEFAULT_OPEN_TIMEOUT: Long = 10 * 1000
        /**
         * クローズのタイムアウトのデフォルト値（ミリ秒）。
         */
        const val DEFAULT_CLOSE_TIMEOUT: Long = 10 * 1000
        /**
         * Ack返却間隔のデフォルト値（ミリ秒）（UShort）。
         */
        const val DEFAULT_ACK_INTERVAL: Short = 100
        /**
         * ストリームが異常切断された時点からの有効期間のデフォルト値（秒）（UShort）。
         */
        const val DEFAULT_EXPIRY_INTERVAL: Short = 60

        /**
         * データポイントのフラッシュポリシーのデフォルト値。
         */
        @JvmField val DEFAULT_FLUSH_POLICY: FlushPolicy = FlushPolicy(
            FlushPolicy.DEFAULT_FLUSH_TYPE,
            FlushPolicy.DEFAULT_INTERVAL,
            FlushPolicy.DEFAULT_BUFFER_SIZE
        )
    }

    /**
     * アップストリームで発生するイベントのコールバック。
     */
    var callbacks: UpstreamCallbacks? = null

    /**
     * コネクション。
     */
    val connection: Connection
    /**
     * エイリアス。
     */
    internal var streamIdAlias: UInt = 0u
    /**
     * ストリームID。
     */
    val id: UUID
    /**
     * サーバー時刻（ナノ秒）。
     *
     * アップストリームを開いた時点におけるサーバーの現在時刻です。
     */
    val serverTime: Long
    /**
     * セッションID。
     */
    val sessionId: String
    /**
     * ストリーム再開用トークン。
     */
    var resumeToken: String = ""
    /**
     * Ack返却間隔（ミリ秒）（UShort）。
     */
    val ackInterval: Short
    /**
     * 有効期限（秒）（UShort）。
     */
    val expiryInterval: Short
    /**
     * 永続化するかどうか。
     */
    val persist: Boolean
    /**
     * データIDリスト。
     */
    internal val dataIds: List<com.aptpod.iscp.message.DataId>
        get() {
            aliasLock.withLock {
                return this.dataIdAliasMap.values.toList()
            }
        }
    internal var dataIdAliasMap: MutableMap<UInt, com.aptpod.iscp.message.DataId> = mutableMapOf()

    private var aliasLock: ReentrantLock = ReentrantLock()
    /**
     * QoS。
     */
    val qos: QoS
    /**
     * データポイントのフラッシュポリシー。
     */
    val flushPolicy: FlushPolicy
    /**
     * オープンのタイムアウト（ミリ秒）。
     */
    val openTimeout: Long
    /**
     * クローズのタイムアウト（ミリ秒）。
     */
    val closeTimeout: Long
    // シーケンス番号ジェネレーター
    internal val sequenceNumberGenerator: SequenceNumberGenerator = SequenceNumberGenerator()
    // 現在のシーケンス番号
    internal var lastIssuedSequenceNumber: UInt = 0u
    // 受信したシーケンス番号
    internal var receivedAckSequenceNumber: UInt = 0u
    // 送信した総データポイント数
    internal var totalDataPoints: ULong = 0u

    internal var streamChunkLock: ReentrantLock = ReentrantLock()
    // 新たにエイリアスとして登録するデータIDのリスト
    internal var dataIdMapAckBuffer: MutableList<com.aptpod.iscp.message.DataId> = mutableListOf()
    // 送信する予定のデータポイントのマップ
    internal var dataPointsBuffer: MutableList<com.aptpod.iscp.message.DataPointGroup> = mutableListOf()
    internal var dataPointsBufferForApp: MutableList<DataPointGroup> = mutableListOf()
    internal var dataPointsCnt: ULong = 0u
    internal var dataPointsPayloadSize: ULong = 0u
    private var dataPointsFlushTimer: Timer? = null
    private var upstreamChunkAckReceiver: Receiver? = null

    // 接続が解除された際に管理する
    internal var isOpen: Boolean = false
        set(value) {
            if (value == field) return
            field = value
            if (value) {
                IscpLog.d("stream opened. - Upstream[$id]")
                // Subscribe Responses
                this.subscribeUpstreamChunkAck();
                // Setup Flush Loop
                this.setupFlushLoop();
            }
            else {
                IscpLog.d("stream closed. - Upstream[$id]");
                // Unsubscribe Responses
                this.unsubscribeUpstreamChunkAck();
                // Stop Flush Loop
                this.stopFlushLoop();
            }
        }
    // コネクションの配下かどうか
    internal var isRegister: Boolean = true
    // Upstreamクローズ前の全データ送信確認処理に利用
    private var closeHandler: ((Exception?) -> Unit)? = null
    private var closeLock: ReentrantLock = ReentrantLock()
    private var closeTimeoutTimer: Timer? = null

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        var self = other as? Upstream ?: return false
        if (this.id != self.id) return false
        return true
    }

    internal constructor(
        sessionId: String,
        ackInterval: Short,
        expiryInterval: Short,
        dataIds: List<DataId>,
        qos: QoS,
        persist: Boolean,
        flushPolicy: FlushPolicy,
        openTimeout: Long,
        closeTimeout: Long,
        connection: Connection,
        openResponse: UpstreamOpenResponse
    ) {
        this.connection = connection
        this.streamIdAlias = openResponse.assignedStreamIdAlias
        this.id = openResponse.assignedStreamId
        this.serverTime = openResponse.serverTime
        this.dataIdAliasMap = openResponse.dataIdAliases.toMutableMap()
        this.sessionId = sessionId
        this.ackInterval = ackInterval
        this.expiryInterval = expiryInterval
        // MEMO: dataIDsはdataIDAliasMapから動的に追加したものを取得する為、保持しない
        this.persist = persist
        this.qos = qos
        this.flushPolicy = flushPolicy
        this.openTimeout = openTimeout
        this.closeTimeout = closeTimeout
        this.resumeToken = openResponse.resumeToken
    }

    internal constructor(upstream: Upstream, connection: Connection, openResponse: UpstreamOpenResponse) {
        this.connection = connection
        this.streamIdAlias = openResponse.assignedStreamIdAlias
        this.id = openResponse.assignedStreamId
        this.serverTime =  openResponse.serverTime
        this.sessionId = upstream.sessionId
        this.ackInterval = upstream.ackInterval
        this.expiryInterval = upstream.expiryInterval
        this.persist = upstream.persist
        this.dataIdAliasMap = openResponse.dataIdAliases.toMutableMap()
        this.qos = upstream.qos
        this.flushPolicy = upstream.flushPolicy
        this.openTimeout = upstream.openTimeout
        this.closeTimeout = upstream.closeTimeout
        this.resumeToken = openResponse.resumeToken
    }

    /**
     * アップストリームを開く際のオプションです。
     * @param sessionId セッションID。
     */
    class Option(internal var sessionId: String) {
        internal var ackInterval: Short = DEFAULT_ACK_INTERVAL
        /**
         * @param ackInterval Ack返却間隔（ミリ秒）（UShort）。このストリームで送信されたデータに対する確認応答の間隔を表します。`0` が設定された場合、ブローカーは1つの `UpstreamChunk` メッセージごとに 1つの `UpstreamChunkAck` メッセージを返却します。
         */
        fun setAckInterval(ackInterval: Short) : Option {
            this.ackInterval = ackInterval
            return this
        }
        internal var expiryInterval: Short = DEFAULT_EXPIRY_INTERVAL
        /**
         * @param expiryInterval 有効期限（秒）（UShort）。このストリームが異常切断された時点からの有効期限を表します。最小値の `0` は、異常切断されたと同時に有効期限切れとなることを表します。
         */
        fun setExpiryInterval(expiryInterval: Short) : Option {
            this.expiryInterval = expiryInterval
            return this
        }
        internal var dataIds: List<DataId>? = null
        /**
         * @param dataIds 送信予定のデータIDのリスト。送信されるデータのデータIDが `dataIDs` に含まれていなかった場合、自動的にそのデータIDが `dataIDs` に追加されます（そのため、`dataIDs` に空のリストが設定されていても問題ありません）。
         */
        fun setDataIds(dataIds: List<DataId>?) : Option {
            this.dataIds = dataIds
            return this
        }
        internal var qos: QoS = DEFAULT_QOS
        /**
         * @param qos QoS。現在は `unreliable` のみサポート。
         */
        fun setQos(qos: QoS) : Option {
            this.qos = qos
            return this
        }
        internal var persist: Boolean = DEFAULT_PERSIST
        /**
         * @param persist 永続化するかどうか。
         */
        fun setPersist(persist: Boolean) :Option {
            this.persist = persist
            return this
        }
        internal var flushPolicy: FlushPolicy = DEFAULT_FLUSH_POLICY
        /**
         * @param flushPolicy データポイントのフラッシュポリシー。
         */
        fun setFlushPolicy(flushPolicy: FlushPolicy) : Option {
            this.flushPolicy = flushPolicy
            return this
        }
        internal var openTimeout: Long = DEFAULT_OPEN_TIMEOUT
        /**
         * @param openTimeout オープンのタイムアウト（ミリ秒）。 `0` 以下の場合はタイムアウトしません。
         */
        fun setOpenTimeout(openTimeout: Long) : Option {
            this.openTimeout = openTimeout
            return this
        }
        internal var closeTimeout: Long = DEFAULT_CLOSE_TIMEOUT
        /**
         * @param closeTimeout クローズのタイムアウト（ミリ秒）。 `0` 以下の場合はタイムアウトしません。
         */
        fun setCloseTimeout(closeTimeout: Long) : Option {
            this.closeTimeout = closeTimeout
            return this
        }
    }

    /**
     * アップストリームを閉じます。
     */
    fun close(closeSession: Boolean = false) : Exception? {
        val threadLock = ReentrantLock()
        val condition = threadLock.newCondition()
        var resultEx: Exception? = null
        Thread {
            closeAsync(closeSession) { exception ->
                resultEx = exception
                threadLock.withLock {
                    condition.signal()
                }
            }
        }.start()
        threadLock.withLock {
            condition.await()
        }
        return resultEx
    }

    /**
     * アップストリームを閉じます。
     * @param closeSession セッションを閉じるかどうか。
     * @param completion 処理完了時のコールバック。
     */
    fun closeAsync(closeSession: Boolean = false, completion: ((Exception?) -> Unit)? = null) {
        this.connection.closeUpstream(this, closeSession, completion)
    }

    /**
     * アップストリームの状態を取得します。
     */
    fun getState() : State {
        this.streamChunkLock.withLock {
            var dataIdAliases = toDataIdAliasesStream(this.dataIdAliasMap.toMap())
            var totalDataPoints = this.totalDataPoints
            var lastIssuedSequenceNumber = this.lastIssuedSequenceNumber
            var dataPointGroups = this.dataPointsBufferForApp.toList()
            return State(
                dataIdAliases = dataIdAliases,
                totalDataPoints = totalDataPoints.toLong(),
                lastIssuedSequenceNumber = lastIssuedSequenceNumber.toInt(),
                dataPointGroups = dataPointGroups
            )
        }
    }

    // 引継ぎ用
    internal fun getDataPointsBufferForOtherStream() : List<DataPointGroup> {
        this.streamChunkLock.withLock {
            return this.dataPointsBufferForApp.toList()
        }
    }

    /**
     * データポイントを送信バッファへ書き込みます。
     * @param dataId データID。
     * @param dataPoint 送信するデータポイント。
     */
    fun writeDataPoint(dataId: DataId, dataPoint: DataPoint) : Exception? {
        if (!this.isRegister) {
            return IscpException.StreamClosed
        }
        this.pushDataPointsBuffer(dataId, listOf(dataPoint))?.let { err ->
            return err
        }
        return this.checkFlush()
    }

    /**
     * 複数のデータポイントを送信バッファへ書き込みます。
     * @param dataId データID。
     * @param dataPoints 送信するデータポイントのリスト。
     */
    fun writeDataPoints(dataId: DataId, dataPoints: List<DataPoint>) : Exception? {
        if (!this.isRegister) {
            return IscpException.StreamClosed
        }
        this.pushDataPointsBuffer(dataId, dataPoints)?.let { err ->
            return err
        }
        return this.checkFlush()
    }

    /**
     * 複数のデータポイントを送信バッファへ書き込みます。
     * @param dataPointGroup データポイントをデータIDごとにまとめた集合。
     */
    fun writeDataPoints(dataPointGroup: DataPointGroup) : Exception? {
        if (!this.isRegister) {
            return IscpException.StreamClosed
        }
        this.pushDataPointsBuffer(dataPointGroup.dataId, dataPointGroup.dataPoints.toList())?.let { err ->
            return err
        }
        return this.checkFlush()
    }

    /**
     * 複数のデータポイントを送信バッファへ書き込みます。
     * @param dataPointGroups データポイントをデータIDごとにまとめた集合のリスト。
     */
    fun writeDataPoints(dataPointGroups: List<DataPointGroup>) : Exception? {
        if (!this.isRegister) {
            return IscpException.StreamClosed
        }
        for (g in dataPointGroups) {
            this.pushDataPointsBuffer(g.dataId, g.dataPoints.toList())?.let { err ->
                return err
            }
        }
        return this.checkFlush()
    }

    internal fun pushDataPointsBuffer(dataId: DataId, dataPoints: List<DataPoint>) : Exception? {
        // Validation
        if (!dataId.isNameValid) { return IscpException.Unexpected("dataId.name is incorrect.") }
        if (!dataId.isTypeValid) { return IscpException.Unexpected("dataId.type is incorrect.") }

        this.streamChunkLock.withLock {
            this.aliasLock.withLock {
                var dataPointGroup: com.aptpod.iscp.message.DataPointGroup
                // 送信予定のデータポイントグループがあれば参照する
                var g = this.dataPointsBuffer.firstOrNull { g ->
                    when (g.dataIdOrAliasCase) {
                        com.aptpod.iscp.message.DataPointGroup.DataIdOrAliasCase.DATA_ID -> {
                            var d = g.dataId
                            return@firstOrNull d?.type == dataId.type && d?.name == dataId.name
                        }
                        com.aptpod.iscp.message.DataPointGroup.DataIdOrAliasCase.DATA_ID_ALIAS -> {
                            var alias = g.dataIdAlias
                            if (alias != null) {
                                var d = this.dataIdAliasMap.get(alias)
                                return@firstOrNull d?.type == dataId.type && d?.name == dataId.name
                            }
                        }
                        else -> {}
                    }
                    return@firstOrNull false
                }
                if (g != null) {
                    dataPointGroup = g
                } else {
                    // 無ければ新規追加
                    dataPointGroup = com.aptpod.iscp.message.DataPointGroup()
                    // エイリアス化したデータIDがあれば新規作成するグループはエイリアスで設定する
                    var found = false
                    for (kv in dataIdAliasMap) {
                        var d = kv.value
                        if (d.type == dataId.type && d.name == dataId.name) {
                            found = true
                            dataPointGroup.dataIdAlias = kv.key
                            break
                        }
                    }
                    if (!found) {
                        var msg = com.aptpod.iscp.message.DataId(dataId.name, dataId.type)
                        dataPointGroup.dataId = msg
                        this.dataIdMapAckBuffer.add(msg)
                    }
                    this.dataPointsBuffer.add(dataPointGroup)
                }
                for (p in dataPoints) {
                    dataPointGroup.dataPoints.add(com.aptpod.iscp.message.DataPoint(p.elapsedTime, p.payload))
                    this.dataPointsCnt += 1u
                    this.dataPointsPayloadSize += p.payload.size.toULong()
                }
                // アプリケーションへ返却する用のデータポイント
                var index = this.dataPointsBufferForApp.indexOfFirst { d ->
                    return@indexOfFirst d.dataId.type == dataId.type && dataId.name == dataId.name
                }
                if (index >= 0) {
                    this.dataPointsBufferForApp[index].dataPoints.addAll(dataPoints)
                } else {
                    this.dataPointsBufferForApp.add(DataPointGroup(dataId, dataPoints.toMutableList()))
                }
            }
        }

        return null
    }

    private fun checkFlush() : Exception? {
        when (this.flushPolicy.type) {
            FlushPolicy.FlushType.NONE -> {
                // 何もしない
            }
            FlushPolicy.FlushType.INTERVAL_ONLY -> {
                // flushIntervalが0であれば即時送信する
                if (this.flushPolicy.interval == 0L) {
                    // バッファしていたデータ送信
                    return this.connection.sendUpstreamChunk(this)
                }
            }
            FlushPolicy.FlushType.BUFFER_SIZE_ONLY -> {
                var flush: Boolean
                this.streamChunkLock.withLock {
                    flush = this.flushPolicy.bufferSize.toUInt() <= this.dataPointsPayloadSize
                }
                if (flush) {
                    // バッファしていたデータ送信
                    return this.connection.sendUpstreamChunk(this)
                }
            }
            FlushPolicy.FlushType.INTERVAL_OR_BUFFER_SIZE -> {
                // flushIntervalが0であれば即時送信する
                if (this.flushPolicy.interval == 0L) {
                    // バッファしていたデータ送信
                    return this.connection.sendUpstreamChunk(this)
                }
                else {
                    var flush: Boolean
                    this.streamChunkLock.withLock {
                        flush = this.flushPolicy.bufferSize.toUInt() <= this.dataPointsPayloadSize
                    }
                    if (flush) {
                        // バッファしていたデータ送信
                        return this.connection.sendUpstreamChunk(this)
                    }
                }
            }
            FlushPolicy.FlushType.IMMEDIATELY -> {
                var flush: Boolean
                this.streamChunkLock.withLock {
                    flush = this.dataPointsBuffer.count() > 0
                }
                if (flush) {
                    // バッファしていたデータ送信
                    return this.connection.sendUpstreamChunk(this)
                }
            }
        }
        return null
    }

    private fun setupFlushLoop() {
        this.stopFlushLoop()
        if (this.flushPolicy.interval <= 0 ||
                !(this.flushPolicy.type == FlushPolicy.FlushType.INTERVAL_ONLY ||
                        this.flushPolicy.type == FlushPolicy.FlushType.INTERVAL_OR_BUFFER_SIZE)) {
            return
        }
        this.dataPointsFlushTimer = Timer()
        this.dataPointsFlushTimer?.schedule(object : TimerTask() {
            override fun run() {
                var err = flush()
                if (err != null) {
                    IscpLog.e("failed to send upstreamChunk. ${err.message} - Upstream[$id]")
                }
            }
        }, this.flushPolicy.interval, this.flushPolicy.interval)
    }

    private fun stopFlushLoop() {
        this.dataPointsFlushTimer?.let { timer ->
            this.dataPointsFlushTimer = null
            timer.cancel()
        }
    }

    /**
     * データポイントを手動でフラッシュします。
     */
    fun flush() : Exception? {
        if (!this.isRegister) {
            return IscpException.StreamClosed
        }
        var flush: Boolean
        this.streamChunkLock.withLock {
            flush = this.dataPointsBuffer.count() > 0
        }
        if (!flush) return null
        return this.connection.sendUpstreamChunk(this)
    }

    internal fun flushBuffer() {
        this.dataIdMapAckBuffer.clear()
        this.dataPointsBuffer.clear()
        this.dataPointsBufferForApp.clear()
        this.dataPointsCnt = 0u
        this.dataPointsPayloadSize = 0u
    }

    internal fun dispose() {
        this.flushBuffer()
        this.isOpen = false
    }

    internal fun waitToSendAllDataPointsAndReceiveAllAck(completion: ((Exception?) -> Unit)?) {
        // データポイントが残っていれば送信
        var flush: Boolean
        this.streamChunkLock.withLock {
            flush = this.dataPointsBuffer.count() > 0
        }
        if (flush) {
            this.connection.sendUpstreamChunk(this)
        }
        // ストリームがオープン状態でなければ送信していないので終了
        if (!this.isOpen) {
            completion?.invoke(null)
            return
        }

        this.closeLock.withLock {
            // 現在のシーケンス番号と一致しいれば準備完了
            if (this.lastIssuedSequenceNumber == this.receivedAckSequenceNumber) {
                completion?.invoke(null)
                return@withLock
            }
            // Ack受信まで待つ
            IscpLog.d("wait for final ack to be received. receivedAckSequenceNumber: $receivedAckSequenceNumber, currentSequenceNumber: $lastIssuedSequenceNumber - Upstream[$id]")
            this.closeHandler = { exception ->
                var exit = false
                this.closeLock.withLock {
                    if (this.closeHandler == null) {
                        exit = true
                        return@withLock
                    }
                    this.closeHandler = null
                    this.closeTimeoutTimer?.let { timer ->
                        this.closeTimeoutTimer = null
                        timer.cancel()
                    }
                }
                if (!exit) {
                    completion?.invoke(exception)
                }
            }
            this.closeTimeoutTimer = Timer()
            this.closeTimeoutTimer?.schedule(object : TimerTask() {
                override fun run() {
                    closeLock.withLock {
                        closeTimeoutTimer?.cancel()
                        closeTimeoutTimer = null
                    }
                    closeHandler?.let { handler ->
                        IscpLog.e("timeout for receiving final ack. - Upstream[$id]")
                        handler(IscpException.Timeout)
                    }
                }
            }, this.closeTimeout)
        }
    }

    private fun subscribeUpstreamChunkAck() {
        this.upstreamChunkAckReceiver?.let { r ->
            this.connection.receivers.unregister(r)
        }
        var receiver = Receiver(0)
        this.upstreamChunkAckReceiver = receiver
        receiver.subscribe<com.aptpod.iscp.message.UpstreamChunkAck> { msg, exception ->
            // Receiverは解除しない
            if (msg == null || exception != null) {
                IscpLog.e("failed to receive upstreamChunkAck. ${exception?.javaClass?.name ?: ""} - Upstream[$id]")
                return@subscribe
            }
            if (msg.streamIdAlias != this.streamIdAlias) { return@subscribe }
            IscpLog.d("didReceived upstreamChunkAck(streamIdAlias: ${msg.streamIdAlias}) - Upstream[$id]")
            this.pushDataIdAliases(msg.dataIdAliases)
            for (res in msg.results) {
                var chunkAckForApp = UpstreamChunkAck(res.sequenceNumber.toInt(), res.resultCode.code.toInt(), res.resultString)
                this.callbacks?.onReceiveAck(this, chunkAckForApp)
                if (this.receivedAckSequenceNumber < res.sequenceNumber) {
                    this.closeLock.withLock {
                        this.receivedAckSequenceNumber = res.sequenceNumber
                    }
                    if (this.lastIssuedSequenceNumber == res.sequenceNumber) {
                        this.closeHandler?.let { handler ->
                            IscpLog.d("didReceived final upstreamChunkAck. sequenceNumber: ${res.sequenceNumber} - Upstream[$id]")
                            handler.invoke(null)
                        }
                    }
                }
            }
        }
        // Receiverを登録
        this.connection.receivers.register(receiver)
    }

    private fun unsubscribeUpstreamChunkAck() {
        this.upstreamChunkAckReceiver?.let { r ->
            this.upstreamChunkAckReceiver = null
            this.connection.receivers.unregister(r)
        }
    }

    private fun pushDataIdAliases(dataIds:  Map<UInt, com.aptpod.iscp.message.DataId>) {
        this.aliasLock.withLock {
            for (kv in dataIds) {
                this.dataIdAliasMap[kv.key] = kv.value
            }
        }
    }

    /**
     * アップストリームの状態を表します。
     * @param dataIdAliases データIDエイリアスとデータIDのマップ（Map(UInt, DataId)）。
     * @param totalDataPoints 総送信データポイント数（ULong）。
     * @param lastIssuedSequenceNumber 最後に払い出されたシーケンス番号（UInt）。
     * @param dataPointGroups 送信予定のデータポイントグループのリスト。
     */
    data class State internal constructor(
        var dataIdAliases: Map<Int, DataId>,
        var totalDataPoints: Long,
        var lastIssuedSequenceNumber: Int,
        var dataPointGroups: List<DataPointGroup>
    ) {
        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            var self = other as? State ?: return false
            if (!this.dataIdAliases.equals(self.dataIdAliases)) return false
            if (this.totalDataPoints != self.totalDataPoints) return false
            if (this.lastIssuedSequenceNumber != self.lastIssuedSequenceNumber) return false
            if (!this.dataPointGroups.equals(self.dataPointGroups)) return false
            return true
        }
    }
}