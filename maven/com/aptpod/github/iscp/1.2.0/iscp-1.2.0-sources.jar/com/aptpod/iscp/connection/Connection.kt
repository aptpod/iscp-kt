package com.aptpod.iscp.connection

import com.aptpod.iscp.encoding.EncodingName
import com.aptpod.iscp.encoding.IMessageConverter
import com.aptpod.iscp.encoding.json.Json
import com.aptpod.iscp.encoding.protobuf.Protobuf
import com.aptpod.iscp.helpers.AliasGenerator
import com.aptpod.iscp.helpers.DispatchGroup
import com.aptpod.iscp.helpers.DispatchQueue
import com.aptpod.iscp.helpers.RequestIdGenerator
import com.aptpod.iscp.model.FailedMessageException
import com.aptpod.iscp.model.IscpException
import com.aptpod.iscp.model.BaseTime
import com.aptpod.iscp.model.DataId
import com.aptpod.iscp.stream.Downstream
import com.aptpod.iscp.model.DownstreamCall
import com.aptpod.iscp.model.DownstreamFilter
import com.aptpod.iscp.model.DownstreamReplyCall
import com.aptpod.iscp.model.FlushPolicy
import com.aptpod.iscp.model.QoS
import com.aptpod.iscp.stream.Upstream
import com.aptpod.iscp.model.UpstreamCall
import com.aptpod.iscp.model.UpstreamReplyCall
import com.aptpod.iscp.logger.IscpLog
import com.aptpod.iscp.message.ConnectResponse
import com.aptpod.iscp.message.Ping
import com.aptpod.iscp.message.ResultCode
import com.aptpod.iscp.transport.ITransport
import com.aptpod.iscp.transport.IConnector
import com.aptpod.iscp.transport.NegotiationParams
import com.aptpod.iscp.transport.Receiver
import com.aptpod.iscp.transport.Receivers
import java.util.UUID
import java.util.concurrent.locks.ReentrantLock
import kotlin.concurrent.withLock
import kotlin.random.Random

/**
 * コネクションで発生するイベントのコールバックです。
 */
interface ConnectionCallbacks {
    /**
     * コネクションが再オープンされた際にコールされます。
     *
     * @param connection コネクション。
     */
    fun onReconnect(connection: Connection)
    /**
     * コネクションがクローズされた際にコールされます。
     *
     * @param connection コネクション。
     */
    fun onDisconnect(connection: Connection)
    /**
     * エラーが発生した際にコールされます。
     *
     * @param connection コネクション。
     * @param exception エラー情報。
     */
    fun onFailWithError(connection: Connection, exception: Exception)
}

/**
 * コネクションで発生するE2Eコールイベントのコールバックです。
 */
interface ConnectionE2ECallCallbacks {
    /**
     * E2Eコールを受信した際にコールされます。
     * @param connection コネクション。
     * @param downstreamCall E2Eコール。
     */
    fun onReceiveCall(connection: Connection, downstreamCall: DownstreamCall)
    /**
     * E2Eリプライコールを受信した際にコールされます。
     * @param connection コネクション。
     * @param downstreamReplyCall E2Eリプライコール。
     */
    fun onReceiveReplyCall(connection: Connection, downstreamReplyCall: DownstreamReplyCall)
}

/**
 * iSCPのコネクションを表すクラスです。
 */
class Connection {

    companion object {

        //region Constants

        /**
         * コネクトのタイムアウトのデフォルト値（ミリ秒）。
         */
        const val DEFAULT_CONNECT_TIMEOUT: Long = 10 * 1000
        /**
         * クローズのタイムアウトのデフォルト値（ミリ秒）。
         */
        const val DEFAULT_CLOSE_TIMEOUT: Long = 10 * 1000
        /**
         * Pingタイムアウトのデフォルト値（秒）（UInt）。
         */
        const val DEFAULT_PING_TIMEOUT: Int = 1
        /**
         * Pingを送信する間隔のデフォルト値（秒）（UInt）。
         */
        const val DEFAULT_PING_INTERVAL: Int = 10
        /**
         * 自動で再接続するかどうかのデフォルト値。
         */
        const val DEFAULT_AUTO_RECONNECT: Boolean = true
        /**
         * 自動で再接続する際の、リトライ間隔の初期値のデフォルト値（ミリ秒）。
         */
        const val DEFAULT_RECONNECT_BASE_INTERVAL: Long = 100
        /**
         * 自動で再接続する際の、リトライ間隔の最大値のデフォルト値（ミリ秒）。
         */
        const val DEFAULT_RECONNECT_MAX_INTERVAL: Long = 5 * 1000
        /**
         * エンコーディング名のデフォルト値。
         */
        @JvmField val DEFAULT_ENCODING: EncodingName = EncodingName.PROTOBUF

        /**
         * メタデータ送信のタイムアウトのデフォルト値（ミリ秒）。
         */
        const val DEFAULT_SEND_METADATA_TIMEOUT: Long = 10 * 1000

        /**
         * E2Eコールのタイムアウトのデフォルト値（ミリ秒）。
         */
        const val DEFAULT_E2E_CALL_TIMEOUT: Long = 10 * 1000

        //endregion

        //region Methods

        /**
         * 接続を行います。
         * @param address 接続先のアドレス。 `127.0.0.1:8080` 形式。
         * @param connector トランスポートのコネクター。
         * @param tokenSource トークンソース。iSCPコネクションを開くたびに、このメソッドをコールしトークンを取得します。
         * @param nodeId ノードID。
         * @param projectUuid プロジェクトID。
         * @param pingTimeout Pingタイムアウト（秒）（UInt）。タイムアウトが発生した場合トランスポートを切断します。
         * @param pingInterval Ping間隔（秒）（UInt）。
         * @param autoReconnect 自動で再接続するかどうか。
         * @param reconnectBaseInterval 自動で再接続する際の、リトライ間隔の初期値（ミリ秒）。再接続に失敗すると、間隔を倍にしながらリトライを繰り返します
         * @param reconnectMaxInterval 自動で再接続する際の、リトライ間隔の最大値（ミリ秒）。
         * @param encoding エンコーディング名。
         * @param callbacks コネクションで発生するイベントをハンドリングするインターフェース。
         * @param e2ECallCallbacks コネクションで発生するE2Eコールイベントをハンドリングするインターフェース。
         */
        fun connect(
            address: String,
            connector: IConnector,
            tokenSource: (() -> String),
            nodeId: String = "",
            projectUuid: String = "",
            pingTimeout: Int = DEFAULT_PING_TIMEOUT,
            pingInterval: Int = DEFAULT_PING_INTERVAL,
            autoReconnect: Boolean = DEFAULT_AUTO_RECONNECT,
            reconnectBaseInterval: Long = DEFAULT_RECONNECT_BASE_INTERVAL,
            reconnectMaxInterval: Long = DEFAULT_RECONNECT_MAX_INTERVAL,
            encoding: EncodingName = DEFAULT_ENCODING,
            callbacks: ConnectionCallbacks? = null,
            e2ECallCallbacks: ConnectionE2ECallCallbacks? = null
        ) : Pair<Connection?, Exception?> {
            val threadLock = ReentrantLock()
            val condition = threadLock.newCondition()
            var resultEx: Exception? = null
            var resultValue: Connection? = null
            Thread {
                connectAsync(
                    address = address,
                    connector = connector,
                    tokenSource = tokenSource,
                    nodeId = nodeId,
                    projectUuid = projectUuid,
                    pingTimeout = pingTimeout,
                    pingInterval = pingInterval,
                    autoReconnect = autoReconnect,
                    reconnectBaseInterval = reconnectBaseInterval,
                    reconnectMaxInterval = reconnectMaxInterval,
                    encoding = encoding,
                    callbacks = callbacks,
                    e2ECallCallbacks = e2ECallCallbacks
                ) { connection, exception ->
                    resultEx = exception
                    resultValue = connection
                    threadLock.withLock {
                        condition.signal()
                    }
                }
            }.start()
            threadLock.withLock {
                condition.await()
            }
            return Pair(resultValue, resultEx)
        }

        /**
         * 接続を行います。
         * @param address 接続先のアドレス。 `127.0.0.1:8080` 形式。
         * @param connector トランスポートのコネクター。
         * @param tokenSource トークンソース。iSCPコネクションを開くたびに、このメソッドをコールしトークンを取得します。
         * @param nodeId ノードID。
         * @param projectUuid プロジェクトID。
         * @param connectTimeout コネクトのタイムアウト（ミリ秒）。 `0` 以下の場合はタイムアウトしません。
         * @param pingTimeout Pingタイムアウト（秒）（UInt）。タイムアウトが発生した場合トランスポートを切断します。
         * @param pingInterval Ping間隔（秒）（UInt）。
         * @param autoReconnect 自動で再接続するかどうか。
         * @param reconnectBaseInterval 自動で再接続する際の、リトライ間隔の初期値（ミリ秒）。再接続に失敗すると、間隔を倍にしながらリトライを繰り返します
         * @param reconnectMaxInterval 自動で再接続する際の、リトライ間隔の最大値（ミリ秒）。
         * @param encoding エンコーディング名。
         * @param callbacks コネクションで発生するイベントをハンドリングするインターフェース。
         * @param e2ECallCallbacks コネクションで発生するE2Eコールイベントをハンドリングするインターフェース。
         * @param completion 処理完了時のコールバック。
         */
        fun connectAsync(
            address: String,
            connector: IConnector,
            tokenSource: (() -> String),
            nodeId: String = "",
            projectUuid: String = "",
            connectTimeout: Long = DEFAULT_CONNECT_TIMEOUT,
            pingTimeout: Int = DEFAULT_PING_TIMEOUT,
            pingInterval: Int = DEFAULT_PING_INTERVAL,
            autoReconnect: Boolean = DEFAULT_AUTO_RECONNECT,
            reconnectBaseInterval: Long = DEFAULT_RECONNECT_BASE_INTERVAL,
            reconnectMaxInterval: Long = DEFAULT_RECONNECT_MAX_INTERVAL,
            encoding: EncodingName = DEFAULT_ENCODING,
            callbacks: ConnectionCallbacks? = null,
            e2ECallCallbacks: ConnectionE2ECallCallbacks? = null,
            completion: ((Connection?, Exception?) -> Unit)
        ) {
            var connection = Connection(
                address = address,
                connector = connector,
                tokenSource = tokenSource,
                nodeId = nodeId,
                projectUuid = projectUuid,
                connectTimeout = connectTimeout,
                pingTimeout = pingTimeout,
                pingInterval = pingInterval,
                autoReconnect = autoReconnect,
                reconnectBaseInterval = reconnectBaseInterval,
                reconnectMaxInterval = reconnectMaxInterval,
                encoding = encoding
            )
            connection.callbacks = callbacks
            connection.e2ECallCallbacks = e2ECallCallbacks
            connection.connectAsync { exception ->
                if (exception != null) {
                    completion(null, exception)
                    return@connectAsync;
                }
                completion(connection, null)
            }
        }

        //endregion
    }

    //region Fields

    /**
     * オブジェクトを識別するためのタグ。
     */
    var tag: Int = 0

    /**
     * コネクションで発生するイベントのコールバック。
     */
    var callbacks: ConnectionCallbacks? = null

    /**
     * コネクションで発生するE2Eコールイベントのコールバック。
     */
    var e2ECallCallbacks: ConnectionE2ECallCallbacks? = null

    //endregion

    //region Config

    /**
     * プロトコルバージョン。
     */
    var protocolVersion: String
        private set
    /**
     * トランスポートのコネクター。
     */
    val connector: IConnector
    /**
     * 接続先のアドレス。
     */
    val address: String
    /**
     * ノードID。
     */
    val nodeId: String
    /**
     * プロジェクトID。
     */
    val projectUuid: String
    /**
     * コネクトのタイムアウト（ミリ秒）。
     */
    val connectTimeout: Long
    /**
     * Pingを送信する間隔（秒）（UInt）。
     */
    val pingInterval: Int
    /**
     * Pingを送信後、Pongが返却されるまでのタイムアウト時間（秒）（UInt）。
     */
    val pingTimeout: Int
    /**
     * トークンソース。
     */
    var tokenSource: (() -> (String))?
    /**
     * 自動で再接続するかどうか。
     */
    val autoReconnect: Boolean
    /**
     * 自動で再接続する際の、リトライ間隔の初期値（ミリ秒）。
     */
    val reconnectBaseInterval: Long
    /**
     * 自動で再接続する際の、リトライ間隔の最大値（ミリ秒）。
     */
    val reconnectMaxInterval: Long

    //endregion

    private var isClosing: Boolean = false
    private val closeLock: ReentrantLock = ReentrantLock()
    /**
     * 再接続中かどうか。
     */
    var isReconnecting = false
        private set
    private var isAutoReconnectWaiting = false
    /// 再接続中に断線が発生し、再接続完了後に再度再接続が必要かどうか。
    private var needsReconnectAfterCurrent = false
    private var reconnectInterval: Long
    private var resumeInterval: Long

    //region Encoding

    /**
     * エンコーディング名。
     */
    val encoding: EncodingName
    /**
     * エンコーディング方法。
     */
    internal val converter: IMessageConverter

    //endregion

    //region Transport

    internal var transport: ITransport? = null
    /**
     * 接続処理中かどうか。
     */
    val isOpen get() = transport != null
    /**
     * 実際にコネクションが接続中かどうか。
     */
    val isConnecting get() = transport?.isConnecting == true
    internal var receivers: Receivers = Receivers()
    internal var transportMessageLock: ReentrantLock = ReentrantLock()

    //endregion

    //region RequestId

    internal var requestIdGenerator: RequestIdGenerator = RequestIdGenerator.newGeneratorForClient()

    //endregion

    //region Disconnect Checker
    internal var disconnectChecker: DisconnectChecker? = null

    //endregion

    //region Ping Receiver
    internal var pingReceiver: Receiver? = null

    //endregion

    //region Downstream

    internal var downstreamIdGenerator: AliasGenerator = AliasGenerator(1u)
    internal var downstreams: MutableMap<UUID, Downstream> = mutableMapOf()
    internal var downstreamLock: ReentrantLock = ReentrantLock()

    internal fun getDownstreamList() : List<Downstream> {
        downstreamLock.withLock {
            return downstreams.values.toList()
        }
    }
    internal fun containsDownstream(downstream: Downstream) : Boolean {
        downstreamLock.withLock {
            return downstreams.keys.contains(downstream.id)
        }
    }
    internal fun registerDownstream(downstream: Downstream) {
        downstreamLock.withLock {
            var streamId = downstream.id
            if (!this.downstreams.keys.contains(streamId)){
                this.downstreams[streamId] = downstream
                downstream.isRegister = true
            }
        }
    }
    internal fun unregisterDownstream(downstream: Downstream) {
        downstreamLock.withLock {
            var streamId = downstream.id
            if (this.downstreams.keys.contains(streamId)) {
                this.downstreams.remove(streamId)
                downstream.isRegister = false
            }
        }
    }
    internal fun unregisterDownstreamAll() {
        downstreamLock.withLock {
            for (d in this.downstreams.values) {
                d.isRegister = false
            }
            this.downstreams.clear()
        }
    }

    internal fun updateDownstreamClosed() {
        downstreamLock.withLock {
            for (d in this.downstreams.values) {
                d.isOpen = false
            }
        }
    }

    /**
     * ダウンストリームを開きます。
     * @param downstreamFilters ダウンストリームフィルタのリスト。
     * @param dataIds エイリアスを設定するデータIDのリスト。
     * @param qos QoS。現在は `unreliable` のみサポート。
     * @param omitEmptyChunk 空チャンク省略フラグ。trueの場合、DownstreamChunk内のDataPointGroupsが空の時、DownstreamChunkの送信を省略します。
     * @param expiryInterval 有効期限（秒）（UShort）。このストリームが異常切断された時点からの有効期限を表します。最小値の `0` は、異常切断されたと同時に有効期限切れとなることを表します。
     * @param ackInterval Ack返却間隔（ミリ秒）。受信したメッセージに対するAckの返却間隔です。
     * @param openTimeout オープンのタイムアウト（ミリ秒）。 `0` 以下の場合はタイムアウトしません。
     * @param closeTimeout クローズのタイムアウト（ミリ秒）。 `0` 以下の場合はタイムアウトしません。
     */
    @JvmOverloads fun openDownstream(
        downstreamFilters: List<DownstreamFilter>,
        dataIds: List<DataId>? = null,
        qos: QoS = Downstream.DEFAULT_QOS,
        omitEmptyChunk: Boolean = Downstream.DEFAULT_OMIT_EMPTY_CHUNK,
        expiryInterval: Short = Downstream.DEFAULT_EXPIRY_INTERVAL,
        ackInterval: Long = Downstream.DEFAULT_ACK_INTERVAL,
        openTimeout: Long = Downstream.DEFAULT_OPEN_TIMEOUT,
        closeTimeout: Long = Downstream.DEFAULT_CLOSE_TIMEOUT
    ) : Pair<Downstream?, Exception?> {
        val threadLock = ReentrantLock()
        val condition = threadLock.newCondition()
        var resultEx: Exception? = null
        var resultValue: Downstream? = null
        Thread {
            openDownstreamAsync(
                downstreamFilters = downstreamFilters,
                dataIds = dataIds,
                qos = qos,
                omitEmptyChunk = omitEmptyChunk,
                expiryInterval = expiryInterval,
                ackInterval = ackInterval,
                openTimeout = openTimeout,
                closeTimeout = closeTimeout
            ) { downstream, exception ->
                resultEx = exception
                resultValue = downstream
                threadLock.withLock {
                    condition.signal()
                }
            }
        }.start()
        threadLock.withLock {
            condition.await()
        }
        return Pair(resultValue, resultEx)
    }

    /**
     * ダウンストリームを開きます。
     * @param option オプション。
     */
    fun openDownstream(
        option: Downstream.Option,
    ) : Pair<Downstream?, Exception?> {
        val threadLock = ReentrantLock()
        val condition = threadLock.newCondition()
        var resultEx: Exception? = null
        var resultValue: Downstream? = null
        Thread {
            openDownstreamAsync(
                downstreamFilters = option.downstreamFilters,
                dataIds = option.dataIds,
                qos = option.qos,
                omitEmptyChunk = option.omitEmptyChunk,
                expiryInterval = option.expiryInterval,
                ackInterval = option.ackInterval
            ) { downstream, exception ->
                resultEx = exception
                resultValue = downstream
                threadLock.withLock {
                    condition.signal()
                }
            }
        }.start()
        threadLock.withLock {
            condition.await()
        }
        return Pair(resultValue, resultEx)
    }

    /**
     * ダウンストリームを開きます。
     * @param downstreamFilters ダウンストリームフィルタのリスト。
     * @param dataIds エイリアスを設定するデータIDのリスト。
     * @param qos QoS。現在は `unreliable` のみサポート。
     * @param omitEmptyChunk 空チャンク省略フラグ。trueの場合、DownstreamChunk内のDataPointGroupsが空の時、DownstreamChunkの送信を省略します。
     * @param expiryInterval 有効期限（秒）（UShort）。このストリームが異常切断された時点からの有効期限を表します。最小値の `0` は、異常切断されたと同時に有効期限切れとなることを表します。
     * @param ackInterval Ack返却間隔（ミリ秒）。受信したメッセージに対するAckの返却間隔です。
     * @param openTimeout オープンのタイムアウト（ミリ秒）。 `0` 以下の場合はタイムアウトしません。
     * @param closeTimeout クローズのタイムアウト（ミリ秒）。 `0` 以下の場合はタイムアウトしません。
     * @param completion 処理完了時のコールバック。
     */
    @JvmOverloads fun openDownstreamAsync(
        downstreamFilters: List<DownstreamFilter>,
        dataIds: List<DataId>? = null,
        qos: QoS = Downstream.DEFAULT_QOS,
        omitEmptyChunk: Boolean = Downstream.DEFAULT_OMIT_EMPTY_CHUNK,
        expiryInterval: Short = Downstream.DEFAULT_EXPIRY_INTERVAL,
        ackInterval: Long = Downstream.DEFAULT_ACK_INTERVAL,
        openTimeout: Long = Downstream.DEFAULT_OPEN_TIMEOUT,
        closeTimeout: Long = Downstream.DEFAULT_CLOSE_TIMEOUT,
        completion: ((Downstream?, Exception?) -> Unit)? = null
    ) {
        this.invokeOpenDownstreamAsync(
            downstreamFilters = downstreamFilters,
            dataIds = dataIds,
            qos = qos,
            omitEmptyChunk = omitEmptyChunk,
            expiryInterval = expiryInterval,
            ackInterval = ackInterval,
            openTimeout = openTimeout,
            closeTimeout = closeTimeout,
            completion = completion
        )
    }

    /**
     * ダウンストリームを開きます。
     * @param option オプション。
     * @param completion 処理完了時のコールバック。
     */
    fun openDownstreamAsync(
        option: Downstream.Option,
        completion: ((Downstream?, Exception?) -> Unit)
    ) {
        this.invokeOpenDownstreamAsync(
            downstreamFilters = option.downstreamFilters,
            dataIds = option.dataIds,
            qos = option.qos,
            omitEmptyChunk = option.omitEmptyChunk,
            expiryInterval = option.expiryInterval,
            ackInterval = option.ackInterval,
            openTimeout = option.openTimeout,
            closeTimeout = option.closeTimeout,
            completion = completion
        )
    }

    /**
     * ストリーム設定を引き継いで別ストリームとして再度ダウンストリームを開きます。
     * @param downstream 既存のダウンストリーム。このダウンストリームの設定を引き継ぐ別のダウンストリームが開かれます。
     */
    @JvmOverloads fun reopenDownstream(downstream: Downstream) : Pair<Downstream?, Exception?> {
        val threadLock = ReentrantLock()
        val condition = threadLock.newCondition()
        var resultEx: Exception? = null
        var resultValue: Downstream? = null
        Thread {
            reopenDownstreamAsync(
                downstream = downstream,
            ) { newStream, exception ->
                resultEx = exception
                resultValue = newStream
                threadLock.withLock {
                    condition.signal()
                }
            }
        }.start()
        threadLock.withLock {
            condition.await()
        }
        return Pair(resultValue, resultEx)
    }

    /**
     * ストリーム設定を引き継いで別ストリームとして再度ダウンストリームを開きます。
     * @param downstream 既存のダウンストリーム。このダウンストリームの設定を引き継ぐ別のダウンストリームが開かれます。
     * @param completion 処理完了時のコールバック。
     */
    @JvmOverloads fun reopenDownstreamAsync(downstream: Downstream, completion: (((Downstream?, Exception?) -> Unit))? = null) {
        this.invokeReopenDownstreamAsync(
            downstream = downstream,
            completion = completion
        )
    }

    //endregion

    //region Upstream

    internal var upstreams: MutableMap<UUID, Upstream> = mutableMapOf()
    internal var upstreamLock: ReentrantLock = ReentrantLock()

    internal fun getUpstreamList() : List<Upstream> {
        upstreamLock.withLock {
            return this.upstreams.values.toList()
        }
    }
    internal fun containsUpstream(upstream: Upstream) : Boolean {
        this.upstreamLock.withLock {
            return this.upstreams.keys.contains(upstream.id)
        }
    }
    internal fun registerUpstream(upstream: Upstream) {
        this.upstreamLock.withLock {
            var streamId = upstream.id
            if (!this.upstreams.keys.contains(streamId)) {
                this.upstreams[streamId] = upstream
                upstream.isRegister = true
            }
        }
    }
    internal fun unregisterUpstream(upstream: Upstream) {
        this.upstreamLock.withLock {
            var streamId = upstream.id
            if (this.upstreams.keys.contains(streamId)) {
                this.upstreams.remove(streamId)
                upstream.isRegister = false
            }
        }
    }
    internal fun unregisterUpstreamAll() {
        this.upstreamLock.withLock {
            for (u in this.upstreams.values) {
                u.isRegister = false
            }
            this.upstreams.clear()
        }
    }
    internal fun updateUpstreamClosed() {
        this.upstreamLock.withLock {
            for (u in this.upstreams.values) {
                u.isOpen = false
            }
        }
    }

    /**
     * アップストリームを開きます。
     * @param sessionId セッションID。
     * @param ackInterval Ack返却間隔（ミリ秒）（UShort）。このストリームで送信されたデータに対する確認応答の間隔を表します。`0` が設定された場合、ブローカーは1つの `UpstreamChunk` メッセージごとに 1つの `UpstreamChunkAck` メッセージを返却します。
     * @param expiryInterval 有効期限（秒）（UShort）。このストリームが異常切断された時点からの有効期限を表します。最小値の `0` は、異常切断されたと同時に有効期限切れとなることを表します。
     * @param dataIds 送信予定のデータIDのリスト。送信されるデータのデータIDが `dataIDs` に含まれていなかった場合、自動的にそのデータIDが `dataIDs` に追加されます（そのため、`dataIDs` に空のリストが設定されていても問題ありません）。
     * @param qos QoS。現在は `unreliable` のみサポート。
     * @param persist 永続化するかどうか。
     * @param flushPolicy データポイントのフラッシュポリシー。
     * @param openTimeout オープンのタイムアウト（ミリ秒）。 `0` 以下の場合はタイムアウトしません。
     * @param closeTimeout クローズのタイムアウト（ミリ秒）。 `0` 以下の場合はタイムアウトしません。
     */
    @JvmOverloads fun openUpstream(
        sessionId: String,
        ackInterval: Short = Upstream.DEFAULT_ACK_INTERVAL,
        expiryInterval: Short = Upstream.DEFAULT_EXPIRY_INTERVAL,
        dataIds: List<DataId>? = null,
        qos: QoS = Upstream.DEFAULT_QOS,
        persist: Boolean = Upstream.DEFAULT_PERSIST,
        flushPolicy: FlushPolicy = Upstream.DEFAULT_FLUSH_POLICY,
        openTimeout: Long = Upstream.DEFAULT_OPEN_TIMEOUT,
        closeTimeout: Long = Upstream.DEFAULT_CLOSE_TIMEOUT
    ) : Pair<Upstream?, Exception?> {
        val threadLock = ReentrantLock()
        val condition = threadLock.newCondition()
        var resultEx: Exception? = null
        var resultValue: Upstream? = null
        Thread {
            openUpstreamAsync(
                sessionId = sessionId,
                ackInterval = ackInterval,
                expiryInterval = expiryInterval,
                dataIds = dataIds,
                qos = qos,
                persist = persist,
                flushPolicy = flushPolicy,
                openTimeout = openTimeout,
                closeTimeout = closeTimeout
            ) { upstream, exception ->
                resultEx = exception
                resultValue = upstream
                threadLock.withLock {
                    condition.signal()
                }
            }
        }.start()
        threadLock.withLock {
            condition.await()
        }
        return Pair(resultValue, resultEx)
    }

    /**
     * アップストリームを開きます。
     * @param option オプション。
     */
    fun openUpstream(
        option: Upstream.Option
    ) : Pair<Upstream?, Exception?> {
        val threadLock = ReentrantLock()
        val condition = threadLock.newCondition()
        var resultEx: Exception? = null
        var resultValue: Upstream? = null
        Thread {
            openUpstreamAsync(
                sessionId = option.sessionId,
                ackInterval = option.ackInterval,
                expiryInterval = option.expiryInterval,
                dataIds = option.dataIds,
                qos = option.qos,
                persist = option.persist,
                flushPolicy = option.flushPolicy,
                closeTimeout = option.closeTimeout
            ) { upstream, exception ->
                resultEx = exception
                resultValue = upstream
                threadLock.withLock {
                    condition.signal()
                }
            }
        }.start()
        threadLock.withLock {
            condition.await()
        }
        return Pair(resultValue, resultEx)
    }

    /**
     * アップストリームを開きます。
     * @param sessionId セッションID。
     * @param ackInterval Ack返却間隔（ミリ秒）（UShort）。このストリームで送信されたデータに対する確認応答の間隔を表します。`0` が設定された場合、ブローカーは1つの `UpstreamChunk` メッセージごとに 1つの `UpstreamChunkAck` メッセージを返却します。
     * @param expiryInterval 有効期限（秒）（UShort）。このストリームが異常切断された時点からの有効期限を表します。最小値の `0` は、異常切断されたと同時に有効期限切れとなることを表します。
     * @param dataIds 送信予定のデータIDのリスト。送信されるデータのデータIDが `dataIDs` に含まれていなかった場合、自動的にそのデータIDが `dataIDs` に追加されます（そのため、`dataIDs` に空のリストが設定されていても問題ありません）。
     * @param qos QoS。現在は `unreliable` のみサポート。
     * @param persist 永続化するかどうか。
     * @param flushPolicy データポイントのフラッシュポリシー。
     * @param openTimeout オープンのタイムアウト（ミリ秒）。 `0` 以下の場合はタイムアウトしません。
     * @param closeTimeout クローズのタイムアウト（ミリ秒）。 `0` 以下の場合はタイムアウトしません。
     * @param completion 処理完了時のコールバック。
     */
    @JvmOverloads fun openUpstreamAsync(
        sessionId: String,
        ackInterval: Short = Upstream.DEFAULT_ACK_INTERVAL,
        expiryInterval: Short = Upstream.DEFAULT_EXPIRY_INTERVAL,
        dataIds: List<DataId>? = null,
        qos: QoS = Upstream.DEFAULT_QOS,
        persist: Boolean = Upstream.DEFAULT_PERSIST,
        flushPolicy: FlushPolicy = Upstream.DEFAULT_FLUSH_POLICY,
        openTimeout: Long = Upstream.DEFAULT_OPEN_TIMEOUT,
        closeTimeout: Long = Upstream.DEFAULT_CLOSE_TIMEOUT,
        completion: ((Upstream?, Exception?) -> Unit)
    ) {
        this.invokeOpenUpstreamAsync(
            sessionId = sessionId,
            ackInterval = ackInterval,
            expiryInterval = expiryInterval,
            dataIds = dataIds,
            qos = qos,
            persist = persist,
            flushPolicy = flushPolicy,
            openTimeout = openTimeout,
            closeTimeout = closeTimeout,
            completion = completion
        )
    }

    /**
     * アップストリームを開きます。
     * @param option オプション。
     * @param completion 処理完了時のコールバック。
     */
    fun openUpstreamAsync(
        option: Upstream.Option,
        completion: ((Upstream?, Exception?) -> Unit)
    ) {
        this.invokeOpenUpstreamAsync(
            sessionId = option.sessionId,
            ackInterval = option.ackInterval,
            expiryInterval = option.expiryInterval,
            dataIds = option.dataIds,
            qos = option.qos,
            persist = option.persist,
            flushPolicy = option.flushPolicy,
            openTimeout = option.openTimeout,
            closeTimeout = option.closeTimeout,
            completion = completion
        )
    }

    /**
     * ストリーム設定を引き継いで別ストリームとして再度アップストリームを開きます。
     * @param upstream 既存のアップストリーム。このアップストリームの設定を引き継ぐ別のアップストリームが開かれます。
     * @param handoverDataPoints 未送信のデータポイントが存在すれば引き継ぐかどうか。
     */
    @JvmOverloads fun reopenUpstream(upstream: Upstream, handoverDataPoints: Boolean = true) : Pair<Upstream?, Exception?> {
        val threadLock = ReentrantLock()
        val condition = threadLock.newCondition()
        var resultEx: Exception? = null
        var resultValue: Upstream? = null
        Thread {
            reopenUpstreamAsync(
                upstream = upstream,
                handoverDataPoints = handoverDataPoints,
            ) { newStream, exception ->
                resultEx = exception
                resultValue = newStream
                threadLock.withLock {
                    condition.signal()
                }
            }
        }.start()
        threadLock.withLock {
            condition.await()
        }
        return Pair(resultValue, resultEx)
    }

    /**
     * ストリーム設定を引き継いで別ストリームとして再度アップストリームを開きます。
     * @param upstream 既存のアップストリーム。このアップストリームの設定を引き継ぐ別のアップストリームが開かれます。
     * @param handoverDataPoints 未送信のデータポイントが存在すれば引き継ぐかどうか。
     * @param completion 処理完了時のコールバック。
     */
    @JvmOverloads fun reopenUpstreamAsync(upstream: Upstream, handoverDataPoints: Boolean = true, completion: ((Upstream?, Exception?) -> Unit)) {
        this.invokeReopenUpstreamAsync(
            upstream = upstream,
            handoverDataPoints = handoverDataPoints,
            completion = completion
        )
    }

    //endregion

    //region E2E Call
    internal var downstreamCallReceiver: Receiver? = null

    /**
     * E2Eコールを送信します。
     * @param upstreamCall E2Eコール。
     * @param sendTimeout 送信のタイムアウト（ミリ秒）。 `0` 以下の場合はタイムアウトしません。
     * @return コールID。
     */
    fun sendCall(upstreamCall: UpstreamCall, sendTimeout: Long = DEFAULT_E2E_CALL_TIMEOUT) : Pair<String?, Exception?> {
        val threadLock = ReentrantLock()
        val condition = threadLock.newCondition()
        var resultEx: Exception? = null
        var resultValue: String? = null
        Thread {
            resultValue = sendCallAsync(
                upstreamCall = upstreamCall,
                sendTimeout = sendTimeout
            ) { exception ->
                resultEx = exception
                threadLock.withLock {
                    condition.signal()
                }
            }
        }.start()
        threadLock.withLock {
            condition.await()
        }
        return Pair(resultValue, resultEx)
    }

    /**
     * E2Eコールを送信します。
     * @param upstreamCall E2Eコール。
     * @param sendTimeout 送信のタイムアウト（ミリ秒）。 `0` 以下の場合はタイムアウトしません。
     * @param completion 処理完了時のコールバック。
     * @return コールID。
     */
    fun sendCallAsync(upstreamCall: UpstreamCall, sendTimeout: Long = DEFAULT_E2E_CALL_TIMEOUT, completion: ((Exception?) -> Unit)? = null) : String? {
        return this.invokeSendCallAsync(
            upstreamCall = upstreamCall,
            sendTimeout = sendTimeout,
            completion = completion
        )
    }

    /**
     * E2Eコールのリプライを送信します。
     * @param upstreamReplyCall E2Eリプライコール。
     * @param sendTimeout 送信のタイムアウト（ミリ秒）。 `0` 以下の場合はタイムアウトしません。
     * @return コールID。
     */
    fun sendReplyCall(upstreamReplyCall: UpstreamReplyCall, sendTimeout: Long = DEFAULT_E2E_CALL_TIMEOUT) : Pair<String?, Exception?> {
        val threadLock = ReentrantLock()
        val condition = threadLock.newCondition()
        var resultEx: Exception? = null
        var resultValue: String? = null
        Thread {
            resultValue = sendReplyCallAsync(
                upstreamReplyCall = upstreamReplyCall,
                sendTimeout = sendTimeout
            ) { exception ->
                resultEx = exception
                threadLock.withLock {
                    condition.signal()
                }
            }
        }.start()
        threadLock.withLock {
            condition.await()
        }
        return Pair(resultValue, resultEx)
    }

    /**
     * E2Eコールのリプライを送信します。
     * @param upstreamReplyCall E2Eリプライコール。
     * @param sendTimeout 送信のタイムアウト（ミリ秒）。 `0` 以下の場合はタイムアウトしません。
     * @param completion 処理完了時のコールバック。
     * @return コールID。
     */
    fun sendReplyCallAsync(upstreamReplyCall: UpstreamReplyCall, sendTimeout: Long = DEFAULT_E2E_CALL_TIMEOUT, completion: ((Exception?) -> Unit)? = null) : String? {
        return this.invokeSendReplyCallAsync(
            upstreamReplyCall = upstreamReplyCall,
            sendTimeout = sendTimeout,
            completion = completion
        )
    }

    /**
     * E2Eコールを送信し、リプライコールを受信します。
     * @param upstreamCall E2Eコール。
     * @param sendTimeout 送信のタイムアウト（ミリ秒）。 `0` 以下の場合はタイムアウトしません。
     * @param waitTimeout 受信のタイムアウト（ミリ秒）。 `0` 以下の場合はタイムアウトしません。
     * @return コールID。
     */
    fun sendCallAndWaitReplyCall(upstreamCall: UpstreamCall, sendTimeout: Long = DEFAULT_E2E_CALL_TIMEOUT, waitTimeout: Long = DEFAULT_E2E_CALL_TIMEOUT) : Triple<String?, DownstreamReplyCall?, Exception?> {
        val threadLock = ReentrantLock()
        val condition = threadLock.newCondition()
        var resultEx: Exception? = null
        var resultValue: String? = null
        var resultValue2: DownstreamReplyCall? = null
        Thread {
            resultValue = sendCallAndWaitReplyCallAsync(
                upstreamCall = upstreamCall,
                sendTimeout = sendTimeout,
                waitTimeout = waitTimeout
            ) { downstreamReplyCall, exception ->
                resultEx = exception
                resultValue2 = downstreamReplyCall
                threadLock.withLock {
                    condition.signal()
                }
            }
        }.start()
        threadLock.withLock {
            condition.await()
        }
        return Triple(resultValue, resultValue2, resultEx)
    }

    /**
     * E2Eコールを送信し、リプライコールを受信します。
     * @param upstreamCall E2Eコール。
     * @param sendTimeout 送信のタイムアウト（ミリ秒）。 `0` 以下の場合はタイムアウトしません。
     * @param waitTimeout 受信のタイムアウト（ミリ秒）。 `0` 以下の場合はタイムアウトしません。
     * @param completion 処理完了時のコールバック。
     * @return コールID。
     */
    fun sendCallAndWaitReplyCallAsync(upstreamCall: UpstreamCall, sendTimeout: Long = DEFAULT_E2E_CALL_TIMEOUT, waitTimeout: Long = DEFAULT_E2E_CALL_TIMEOUT, completion: ((DownstreamReplyCall?, Exception?) -> Unit)? = null) : String? {
        return this.invokeSendCallAndWaitReplyCallAsync(
            upstreamCall = upstreamCall,
            sendTimeout = sendTimeout,
            waitTimeout = waitTimeout,
            completion = completion,
        )
    }

    //endregion

    //region Metadata

    /**
     * 基準時刻を送信します。
     * @param baseTime 基準時刻。
     * @param persist 永続化するかどうか。
     * @param sendTimeout 送信のタイムアウト（ミリ秒）。 `0` 以下の場合はタイムアウトしません。
     * @return 成功時: null, 失敗時: エラー。
     */
    @JvmOverloads fun sendBaseTime(baseTime: BaseTime, persist: Boolean = false, sendTimeout: Long = DEFAULT_SEND_METADATA_TIMEOUT) : Exception? {
        val threadLock = ReentrantLock()
        val condition = threadLock.newCondition()
        var resultEx: Exception? = null
        Thread {
            sendBaseTimeAsync(
                baseTime = baseTime,
                persist = persist,
                sendTimeout = sendTimeout
            ) { exception ->
                resultEx = exception
                threadLock.withLock {
                    condition.signal()
                }
            }
        }.start()
        threadLock.withLock {
            condition.await()
        }
        return resultEx
    }

    /**
     * 基準時刻を送信します。
     * @param baseTime 基準時刻。
     * @param persist 永続化するかどうか。
     * @param sendTimeout 送信のタイムアウト（ミリ秒）。 `0` 以下の場合はタイムアウトしません。
     * @param completion 処理完了時のコールバック。
     */
    @JvmOverloads fun sendBaseTimeAsync(baseTime: BaseTime, persist: Boolean = false, sendTimeout: Long = DEFAULT_E2E_CALL_TIMEOUT, completion: ((Exception?) -> Unit)? = null) {
        this.invokeSendBaseTimeAsync(
            baseTime = baseTime,
            persist = persist,
            sendTimeout = sendTimeout,
            completion = completion
        )
    }

    //endregion

    private fun unregisterAll() {
        this.disconnectChecker?.dispose()
        this.disconnectChecker = null
        this.pingReceiver?.unsubscribe()
        this.pingReceiver = null
        this.downstreamCallReceiver?.unsubscribe()
        this.downstreamCallReceiver = null
        this.unregisterUpstreamAll()
        this.unregisterDownstreamAll()
        this.receivers.unregisterAll()
    }

    private fun setupConnectionObserver() {
        this.setupPingReceiver()
        this.setupDownstreamCallReceiver()
        this.setupDisconnectChecker()
    }

    private fun disposeConnectionObserver() {
        this.disconnectChecker?.dispose()
        this.disconnectChecker = null
        this.pingReceiver?.unsubscribe()
        this.pingReceiver = null
        this.downstreamCallReceiver?.unsubscribe()
        this.downstreamCallReceiver = null
    }

    //region Constructors

    /**
     * @param address 接続先のアドレス。 `127.0.0.1:8080` 形式。
     * @param connector トランスポートのコネクター。
     * @param tokenSource トークンソース。iSCPコネクションを開くたびに、このメソッドをコールしトークンを取得します。
     * @param nodeId ノードID。
     * @param projectUuid プロジェクトID。
     * @param connectTimeout コネクトのタイムアウト（ミリ秒）。 `0` 以下の場合はタイムアウトしません。
     * @param pingTimeout Pingタイムアウト（秒）（UInt）。タイムアウトが発生した場合トランスポートを切断します。
     * @param pingInterval Ping間隔（秒）（UInt）。
     * @param autoReconnect 自動で再接続するかどうか。
     * @param reconnectBaseInterval 自動で再接続する際の、リトライ間隔の初期値（ミリ秒）。再接続に失敗すると、間隔を倍にしながらリトライを繰り返します
     * @param reconnectMaxInterval 自動で再接続する際の、リトライ間隔の最大値（ミリ秒）。
     * @param encoding エンコーディング名。
     */
    @JvmOverloads constructor(
        address: String,
        connector: IConnector,
        tokenSource: (() -> (String)),
        nodeId: String = "",
        projectUuid: String = "",
        connectTimeout: Long = DEFAULT_CONNECT_TIMEOUT,
        pingTimeout: Int = DEFAULT_PING_TIMEOUT,
        pingInterval: Int = DEFAULT_PING_INTERVAL,
        autoReconnect: Boolean = DEFAULT_AUTO_RECONNECT,
        reconnectBaseInterval: Long = DEFAULT_RECONNECT_BASE_INTERVAL,
        reconnectMaxInterval: Long = DEFAULT_RECONNECT_MAX_INTERVAL,
        encoding: EncodingName = DEFAULT_ENCODING
    ) {
        // プロトコルバージョン
        this.protocolVersion = com.aptpod.iscp.SUPPORTED_PROTOCOL_VERSION
        // Config依存
        this.address = address
        this.connector = connector
        this.tokenSource = tokenSource
        this.nodeId = nodeId
        this.projectUuid = projectUuid
        this.connectTimeout = connectTimeout
        this.pingTimeout = pingTimeout
        this.pingInterval = pingInterval
        this.autoReconnect = autoReconnect
        this.reconnectBaseInterval = reconnectBaseInterval
        this.reconnectMaxInterval = reconnectMaxInterval
        // Exponential backoff and jitter値のリセット
        this.reconnectInterval = reconnectBaseInterval
        this.resumeInterval = reconnectBaseInterval
        this.encoding = encoding
        // エンコーディング
        when (encoding) {
            EncodingName.JSON -> this.converter = Json()
            EncodingName.PROTOBUF -> this.converter = Protobuf()
        }
    }

    //region Builder

    /**
     * iSCPのコネクションのビルダーパターンです。
     * @param address 接続先のアドレス。 `127.0.0.1:8080` 形式。
     * @param connector トランスポートの設定。
     * @param tokenSource トークンソース。iSCPコネクションを開くたびに、このメソッドをコールしトークンを取得します。
     */
    class Builder(private var address: String, private var connector: IConnector, private var tokenSource: (() -> String)) {

        private var nodeId: String = ""
        /**
         * @param nodeId ノードID。
         */
        fun setNodeId(nodeId: String) : Builder {
            this.nodeId = nodeId
            return this
        }
        private var projectUuid: String = ""
        /**
         * @param projectUuid プロジェクトID。
         */
        fun setProjectUuid(projectUuid: String) : Builder {
            this.projectUuid = projectUuid
            return this
        }
        private var connectTimeout: Long = DEFAULT_CONNECT_TIMEOUT
        fun setConnectTimeout(connectTimeout: Long) : Builder {
            this.connectTimeout = connectTimeout
            return this
        }
        private var pingTimeout: Int = DEFAULT_PING_TIMEOUT
        /**
         * @param pingTimeout Pingタイムアウト（秒）（UInt）。タイムアウトが発生した場合トランスポートを切断します。
         */
        fun setPingTimeout(pingTimeout: Int) : Builder {
            this.pingTimeout = pingTimeout
            return this
        }
        private var pingInterval: Int = DEFAULT_PING_INTERVAL
        /**
         * @param pingInterval Ping間隔（秒）（UInt）。
         */
        fun setPingInterval(pingInterval: Int) : Builder {
            this.pingInterval = pingInterval
            return this
        }
        private var autoReconnect: Boolean = DEFAULT_AUTO_RECONNECT
        /**
         * @param autoReconnect 自動で再接続するかどうか。
         */
        fun setAutoReconnect(autoReconnect: Boolean) : Builder {
            this.autoReconnect = autoReconnect
            return this
        }
        private var reconnectBaseInterval: Long = DEFAULT_RECONNECT_BASE_INTERVAL
        /**
         * @param reconnectBaseInterval 自動で再接続する際の、リトライ間隔の初期値（ミリ秒）。再接続に失敗すると、間隔を倍にしながらリトライを繰り返します。
         */
        fun setReconnectBaseInterval(reconnectBaseInterval: Long) : Builder {
            this.reconnectBaseInterval = reconnectBaseInterval
            return this
        }
        private var reconnectMaxInterval: Long = DEFAULT_RECONNECT_MAX_INTERVAL
        /**
         * @param reconnectMaxInterval 自動で再接続する際の、リトライ間隔の最大値（ミリ秒）。
         */
        fun setReconnectMaxInterval(reconnectMaxInterval: Long) : Builder {
            this.reconnectMaxInterval = reconnectMaxInterval
            return this
        }
        private  var encoding: EncodingName = DEFAULT_ENCODING
        /**
         * @param encoding エンコーディング名。
         */
        fun setEncoding(encoding: EncodingName) : Builder {
            this.encoding = encoding
            return this
        }
        private var callbacks: ConnectionCallbacks? = null
        /**
         * @param callbacks コネクションで発生するイベントをハンドリングするインターフェース。
         */
        fun setCallbacks(callbacks: ConnectionCallbacks) : Builder {
            this.callbacks = callbacks
            return this
        }
        private var e2ECallCallbacks: ConnectionE2ECallCallbacks? = null
        /**
         * @param e2ECallCallbacks コネクションで発生するE2Eコールイベントをハンドリングするインターフェース。
         */
        fun setE2ECallCallbacks(e2ECallCallbacks: ConnectionE2ECallCallbacks) : Builder {
            this.e2ECallCallbacks = e2ECallCallbacks
            return this
        }

        /**
         * ビルドします。
         */
        fun build() : Connection {
            var con = Connection(
                address = address,
                connector = connector,
                tokenSource = tokenSource,
                nodeId = nodeId,
                connectTimeout = connectTimeout,
                projectUuid = projectUuid,
                pingTimeout = pingTimeout,
                pingInterval = pingInterval,
                autoReconnect = autoReconnect,
                reconnectBaseInterval = reconnectBaseInterval,
                reconnectMaxInterval = reconnectMaxInterval,
                encoding = encoding)
            con.callbacks = callbacks
            con.e2ECallCallbacks = e2ECallCallbacks
            return con
        }
    }

    //endregion

    //endregion

    //region Methods

    /**
     * iSCPで接続します。
     */
    fun connect() : Exception? {
        val threadLock = ReentrantLock()
        val condition = threadLock.newCondition()
        var resultEx: Exception? = null
        Thread {
            connectAsync { exception ->
                resultEx = exception
                threadLock.withLock {
                    condition.signal()
                }
            }
        }.start()
        threadLock.withLock {
            condition.await()
        }
        return resultEx
    }

    /**
     * iSCPで接続します。
     * @param completion 処理完了時のコールバック。
     */
    fun connectAsync(completion: (Exception?) -> Unit) {
        if (this.isOpen) {
            completion(IscpException.Unexpected("connection already open."))
            return
        }
        val negotiationParams = NegotiationParams(this.converter.name)
        this.connector.connect(this.address, negotiationParams) { transport, exception ->
            if (transport == null) {
                completion(exception ?: IscpException.Unexpected("transport connection failed."))
                return@connect
            }
            setupTransportCallbacks(transport)
            // Reset Request ID
            this.requestIdGenerator.reset()
            // Setup Connection
            this.setupConnection(transport, completion)
        }
    }

    private fun setupConnection(transport: ITransport, completion: ((Exception?) -> Unit)) {
        var token = this.tokenSource?.invoke()
        if (token.isNullOrEmpty()) {
            completion?.invoke(IscpException.Unexpected("failed to get access token."))
            return
        }
        var accessToken = token
        this.transport = transport
        var requestId = this.requestIdGenerator.generate()
        var receiver = Receiver("(requestId: $requestId)", this.connectTimeout)
        receiver.subscribe<ConnectResponse> { msg, exception ->
            if (msg == null || exception != null) {
                IscpLog.e("failed to receive requestId($requestId) connectResponse. ${exception?.javaClass?.name ?: ""}, requestId: ${msg?.requestId?.toString() ?: "null"}, resultCode: ${msg?.resultCode?.code?.toString() ?: "null"}, resultString: ${msg?.resultString ?: "null"} - Connection")
                // Receiverを解除
                this.receivers.unregister(receiver)
                // Transportを削除し、リコネクト防止
                this.transport = null
                completion(exception ?: IscpException.Unexpected("connectResponse not found."))
                return@subscribe
            }
            if (msg.requestId != requestId) return@subscribe
            // Receiverを解除
            this.receivers.unregister(receiver)
            IscpLog.d("didReceived connectResponse(requestId: ${msg.requestId}, resultCode: ${msg.resultCode.code}, resultString: ${msg.resultString}, protocolVersion: ${msg.protocolVersion}) - Connection")
            if (msg.resultCode != ResultCode.SUCCEEDED) {
                // Transportを削除し、リコネクト防止
                this.transport = null
                completion(IscpException.FailedMessage(msg.resultCode.code, msg.resultString))
                return@subscribe
            }
            this.protocolVersion = msg.protocolVersion
            // Setup observer
            this.setupConnectionObserver()
            // Reset reconnect interval
            this.reconnectInterval = this.reconnectBaseInterval
            this.resumeInterval = this.reconnectBaseInterval
            // 接続に成功した
            completion.invoke(null)
        }
        // Receiverを登録
        this.receivers.register(receiver)

        // Send ConnectRequest
        var sendException = sendConnectRequest(requestId, accessToken)
        if (sendException != null) {
            this.receivers.unregister(receiver)
            completion.invoke(sendException)
        }
    }

    /**
     * Pingがブローカーから送られてきたらPongを返却するレシーバーのセットアップ
     */
    private fun setupPingReceiver() {
        this.pingReceiver?.let { r ->
            this.receivers.unregister(r)
        }
        var receiver = Receiver(0)
        this.pingReceiver = receiver
        receiver.subscribe<Ping> { msg, exception ->
            // Receiverは解除しない
            if (msg == null || exception != null) {
                IscpLog.e("failed to receive ping. ${exception?.javaClass?.name ?: ""}, requestId: ${msg?.requestId?.toString() ?: "null"} - Connection")
                return@subscribe
            }
            IscpLog.d("onReceived ping(requestId: ${msg.requestId}) - Connection")
            var sendException = this.sendPong(msg.requestId)
            if (sendException != null) {
                IscpLog.e("failed to send pong. ${sendException.javaClass.name}")
                return@subscribe
            }
        }
        // Receiverを登録
        this.receivers.register(receiver)
    }

    /**
     * ディスコネクト判定をするチェッカーのセットアップ
     */
    private fun setupDisconnectChecker() {
        if (this.disconnectChecker != null) return
        var checker = DisconnectChecker()
        checker.register(this) {
            this.callbacks?.onFailWithError(this, IscpException.Timeout)
            this.transport?.close(null)
            this.connectionClosedWithCheckReconnect()
        }
        this.disconnectChecker = checker
        checker.startSendPingTimer()
    }

    /**
     * コネクションを閉じます。
     * オープン済みのストリームは全て閉じられます。
     */
    fun close() : Exception? {
        val threadLock = ReentrantLock()
        val condition = threadLock.newCondition()
        var resultEx: Exception? = null
        Thread {
            closeAsync { exception ->
                resultEx = exception
                threadLock.withLock {
                    condition.signal()
                }
            }
        }.start()
        threadLock.withLock {
            condition.await()
        }
        return resultEx
    }

    /**
     * コネクションを閉じます。
     * オープン済みのストリームは全て閉じられます。
     * @param completion 処理完了時のコールバック。
     */
    fun closeAsync(completion: ((exception: Exception?) -> Unit)? = null) {
        this.closeLock.withLock {
            if (this.isClosing) {
                completion?.invoke(IscpException.Unexpected("already in closing."))
                return@withLock
            }
            this.isClosing = true
            this.needsReconnectAfterCurrent = false
            var transport: ITransport = this.transport ?: run {
                this.isClosing = false
                completion?.invoke(IscpException.TransportClosed)
                return@withLock
            }
            // Dispose Observer
            this.disposeConnectionObserver()
            this.receivers.unregisterAll()
            var group = DispatchGroup()
            // Downstreamの終了
            for (d in this.getDownstreamList()) {
                if (!d.isOpen) { continue }
                group.enter()
                this.closeDownstream(d) { exception ->
                    if (exception != null) {
                        IscpLog.e("close downstream, error. ${exception.javaClass.name} - Connection")
                    }
                    group.leave()
                }
            }
            this.unregisterDownstreamAll()
            // Upstreamの終了
            for (u in this.getUpstreamList()) {
                if (!u.isOpen) { continue }
                group.enter()
                this.closeUpstream(u) { exception ->
                    if (exception != null) {
                        IscpLog.e("close upstream, error. ${exception.javaClass.name} - Connection")
                    }
                    group.leave()
                }
            }
            this.unregisterUpstreamAll()
            group.notifyAsync {
                var error = this.sendDisconnect()
                if (error != null) {
                    IscpLog.e("failed to send disconnect. ${error.javaClass.name} - Connection")
                }
                this.transport = null
                transport.close(null)
                this.isClosing = false
                completion?.invoke(null)
            }
        }
    }

    internal fun connectionClosedWithCheckReconnect() {
        // ストリームをクローズ状態にする
        this.updateUpstreamClosed()
        this.updateDownstreamClosed()
        // Dispose observer
        this.disposeConnectionObserver()
        // 自動再接続処理
        if (this.autoReconnect) {
            if (!(!this.isClosing && this.isOpen)) return
            if (!(!this.isReconnecting && !this.isAutoReconnectWaiting)) {
                // 再接続中またはリトライ待ち中に断線が発生した場合、完了後に再度再接続を行う
                this.needsReconnectAfterCurrent = true
                return
            }
            this.isAutoReconnectWaiting = true
            // Exponential Backoff + Jitter
            var jitter = Random.nextDouble() + 0.5 // nextDouble()は0~1.0の範囲の乱数なので+0.5して0.5~1.5の範囲を生成
            var baseInterval = this.reconnectInterval
            var interval = (baseInterval.toDouble() * jitter).toLong()
            IscpLog.d("waiting for reconnect(baseInterval: $baseInterval, jitter: $jitter => interval: $interval) - Connection")
            DispatchQueue.Global.asyncAfter(interval) {
                this.isAutoReconnectWaiting = false
                if (!(!this.isClosing && this.isOpen)) return@asyncAfter
                if (!(!this.isReconnecting)) return@asyncAfter
                this.isReconnecting = true
                this.reconnectInterval *= 2
                if (this.reconnectInterval > this.reconnectMaxInterval) {
                    this.reconnectInterval = this.reconnectMaxInterval
                }
                IscpLog.d("try to reconnect. - Connection")
                this.reconnect { exception ->
                    this.isReconnecting = false
                    exception?.let { e ->
                        IscpLog.e("reconnect failed. ${e.message} - Connection")
                        this.needsReconnectAfterCurrent = false
                        this.connectionClosedWithCheckReconnect()
                        return@reconnect
                    }
                    // 再接続中に断線が発生していた場合、再度再接続を行う
                    if (this.needsReconnectAfterCurrent) {
                        IscpLog.d("reconnect successful but disconnect occurred during resume. reconnecting again. - Connection")
                        this.needsReconnectAfterCurrent = false
                        this.connectionClosedWithCheckReconnect()
                        return@reconnect
                    }
                    IscpLog.d("reconnect successful. - Connection")
                    this.reconnectInterval = this.reconnectBaseInterval
                    this.callbacks?.onReconnect(this)
                }
            }
        }
    }

    /**
     * 再接続を行います。
     */
    internal fun reconnect(completion: ((Exception?) -> Unit)?) {
        this.closeLock.withLock {
            if (this.isClosing) {
                completion?.invoke(IscpException.Unexpected("already in closing."))
                return@withLock
            }
            this.transport?.let { t ->
                // 接続中の場合は一度クローズする
                IscpLog.d("clear transport once. - Connection")
                t.callbacks = null
                t.close()
            }
            val negotiationParams = NegotiationParams(this.converter.name)
            this.connector.connect(this.address, negotiationParams) { transport, exception ->
                if (transport == null) {
                    completion?.invoke(exception ?: IscpException.Unexpected("transport connection failed."))
                    return@connect
                }
                // Reset Request ID
                this.requestIdGenerator.reset()
                // Resetup Connection
                this.resetupConnection(transport, completion)
            }
        }
    }

    private fun resetupConnection(transport: ITransport, completion: ((Exception?) -> Unit)?) {
        var token = this.tokenSource?.invoke()
        if (token.isNullOrEmpty()) {
            completion?.invoke(IscpException.Unexpected("failed to get access token."))
            return
        }
        var accessToken = token
        this.transport = transport
        setupTransportCallbacks(transport)
        var requestId = this.requestIdGenerator.generate()
        var receiver = Receiver("(requestId: $requestId)", this.connectTimeout)
        receiver.subscribe<ConnectResponse> { msg, exception ->
            if (msg == null || exception != null) {
                IscpLog.e("failed to receive connectResponse. ${exception?.javaClass?.name ?: ""}, requestId: ${msg?.requestId?.toString() ?: "null"}, resultCode: ${msg?.resultCode?.code?.toString() ?: "null"}, resultString: ${msg?.resultString ?: "null"} - Connection")
                // Receiverを解除
                this.receivers.unregister(receiver)
                completion?.invoke(exception ?: IscpException.Unexpected("connectResponse not found."))
                return@subscribe
            }
            if (msg.requestId != requestId) return@subscribe
            // Receiverを解除
            this.receivers.unregister(receiver)
            IscpLog.d("didReceived connectResponse(requestId: ${msg.requestId}, resultCode: ${msg.resultCode.code}, resultString: ${msg.resultString}, protocolVersion: ${msg.protocolVersion}) - Connection")
            if (msg.resultCode != ResultCode.SUCCEEDED) {
                completion?.invoke(IscpException.FailedMessage(msg.resultCode.code, msg.resultString))
                return@subscribe
            }
            this.protocolVersion = msg.protocolVersion
            // Setup observer
            this.setupConnectionObserver()
            // ストリームを再開する
            this.resumeStreams(getUpstreamList(), getDownstreamList()) { _, exception ->
                // ストリームのresume失敗は無視する
                completion?.invoke(null)
            }
        }
        // Receiverを登録
        this.receivers.register(receiver)

        // Send ConnectRequest
        var sendException = sendConnectRequest(requestId, accessToken)
        if (sendException != null) {
            this.receivers.unregister(receiver)
            completion?.invoke(sendException)
        }
    }

    private fun resumeStreams(upstreams: List<Upstream>, downstreams: List<Downstream>, completion: ((Boolean, Exception?) -> Unit)?) {
        var group = DispatchGroup()
        var error: Exception? = null
        var retryDownstreams: MutableList<Downstream> = mutableListOf()
        var retryUpstreams: MutableList<Upstream> = mutableListOf()
        // Downstream
        for (d in downstreams) {
            if (!(d.expiryInterval.toUShort() > 0u)) {
                d.callbacks?.onCloseWithError(d, IscpException.Unexpected("downstream resume failed because ExpiryInterval is 0."))
                continue
            }
            group.enter()
            resumeDownstreamAsync(d) { d2, e ->
                try {
                    if (e != null) {
                        if (e is FailedMessageException) {
                            if (e.resultCode == ResultCode.RESUME_REQUEST_CONFLICT.code) {
                                IscpLog.w("downstream[${d2.id}] resume failed, retry. ${e.message} - Connection")
                                retryDownstreams.add(d2)
                                return@resumeDownstreamAsync
                            }
                        }
                        IscpLog.e("failed to resume downstream[${d2.id}]. ${e.message} - Connection")
                        d2.callbacks?.onCloseWithError(d2, e);
                        error = e;
                    }
                    else {
                        IscpLog.d("successful downstream[${d2.id}] resume. - Connection");
                        d2.callbacks?.onResume(d2);
                    }
                }
                finally {
                    group.leave()
                }
            }
        }
        // Upstream
        for (u in upstreams) {
            if (!(u.expiryInterval.toUShort() > 0u)) {
                u.callbacks?.onCloseWithError(u, IscpException.Unexpected("upstream resume failed because ExpiryInterval is 0."))
                continue
            }
            group.enter()
            resumeUpstreamAsync(u) { u2, e ->
                try {
                    if (e != null) {
                        if (e is FailedMessageException) {
                            if (e.resultCode == ResultCode.RESUME_REQUEST_CONFLICT.code) {
                                IscpLog.w("upstream[${u2.id}] resume failed, retry. ${e.message} - Connection")
                                retryUpstreams.add(u2)
                                return@resumeUpstreamAsync
                            }
                        }
                        IscpLog.e("failed to resume upstream[${u2.id}]. ${e.message} - Connection")
                        u2.callbacks?.onCloseWithError(u2, e);
                        error = e;
                    }
                    else {
                        IscpLog.d("successful upstream[${u2.id}] resume. - Connection");
                        u2.callbacks?.onResume(u2);
                    }
                }
                finally {
                    group.leave()
                }
            }
        }

        group.notifyAsync {
            var retry = retryUpstreams.count() != 0 || retryDownstreams.count() != 0
            // 全ストリームの全オープン処理が終わった
            completion?.invoke(retry, error)
            // resumeのリトライ
            if (retry) {
                this.retryResumeStreams(retryUpstreams.toList(), retryDownstreams.toList())
            }
        }
    }

    private fun retryResumeStreams(upstreams: List<Upstream>, downstreams: List<Downstream>) {
        IscpLog.d("retryResumeStreams. ${upstreams.count()} upstreams, ${downstreams.count()} downstreams.")
        if (!(!this.isClosing && this.isOpen)) return
        if (!(!this.isReconnecting && !this.isAutoReconnectWaiting)) return
        // Exponential Backoff + Jitter
        var jitter = Random.nextDouble() + 0.5 // nextDouble()は0~1.0の範囲の乱数なので+0.5して0.5~1.5の範囲を生成
        var baseInterval = this.resumeInterval
        var interval = (baseInterval.toDouble() * jitter).toLong()
        IscpLog.d("waiting for resumeStreams(baseInterval: $baseInterval, jitter: $jitter => interval: $interval) - Connection")
        DispatchQueue.Global.asyncAfter(interval) {
            if (!(!this.isClosing && this.isOpen)) return@asyncAfter
            if (!(!this.isReconnecting)) return@asyncAfter
            this.resumeInterval *= 2
            if (this.resumeInterval > this.reconnectMaxInterval) {
                this.resumeInterval = this.reconnectMaxInterval
            }
            IscpLog.d("try to resume. - Connection")
            this.resumeStreams(upstreams, downstreams) { retried, exception ->
                if (exception != null) {
                    IscpLog.e("resume failed. ${exception.javaClass.name} - Connection")
                }
                else if (!retried) {
                    IscpLog.d("resume successful. - Connection")
                    this.resumeInterval = this.reconnectBaseInterval
                }
            }
        }
    }

    fun dispose() {
        this.callbacks = null
        this.tokenSource = null
        this.transport?.close()
        this.transport = null
        this.unregisterAll()
    }

    //endregion

}