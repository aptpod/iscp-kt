package com.aptpod.iscp.message

/**
 * @param sourceNodeId 送信元ノードID
 * @param dataFilters データフィルタ
 */
internal class DownstreamFilter(
    var sourceNodeId: String = "",
    var dataFilters: List<DataFilter> = listOf()
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        var self = other as? DownstreamFilter ?: return false
        if (this.sourceNodeId != self.sourceNodeId) return false
        if (!this.dataFilters.equals(self.dataFilters)) return false
        return true
    }
}

/**
 * @param name 名称
 * @param type 型
 */
internal class DataFilter(
    var name: String = "",
    var type: String = ""
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        var self = other as? DataFilter ?: return false
        if (this.name != self.name) return false
        if (this.type != self.type) return false
        return true
    }
}

/**
 * @param downstreamFilterIndex ダウンストリームフィルタのインデックス
 * @param dataFilterIndex データフィルタのインデックス
 */
internal class DownstreamFilterReference(
    var downstreamFilterIndex: UInt = 0u,
    var dataFilterIndex: UInt = 0u
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        var self = other as? DownstreamFilterReference ?: return false
        if (this.downstreamFilterIndex != self.downstreamFilterIndex) return false
        if (this.dataFilterIndex != self.dataFilterIndex) return false
        return true
    }
}

/**
 * @param references フィルタ参照リスト
 */
internal class DownstreamFilterReferences(
    var references: List<DownstreamFilterReference> = listOf()
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        var self = other as? DownstreamFilterReferences ?: return false
        if (!this.references.equals(self.references)) return false
        return true
    }
}