package com.aptpod.iscp.message

/**
 * @param requestId リクエストID
 * @param protocolVersion プロトコルバージョン
 * @param nodeId ノードID
 * @param pingInterval Ping間隔
 *
 * 単位は秒
 * @param pingTimeout Pingタイムアウト
 *
 * 単位は秒
 * @param extensionFields 拡張フィールド
 */
internal class ConnectRequest(
    var requestId: UInt = 0u,
    var protocolVersion: String = "",
    var nodeId: String = "",
    var pingInterval: UInt = 0u,
    var pingTimeout: UInt = 0u,
    var extensionFields: ExtensionFields = ExtensionFields()
) : IMessage {

    /**
     * @param accessToken アクセストークン
     * @param intdash intdash用拡張フィールド
     */
    class ExtensionFields(
        var accessToken: String = "",
        var intdash: IntdashExtensionFields = IntdashExtensionFields()
    ) {
        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            var self = other as? ExtensionFields ?: return false
            if (this.accessToken != self.accessToken) return false
            if (this.intdash != self.intdash) return false
            return true
        }
    }

    /**
     * @param projectUuid プロジェクトID
     */
    class IntdashExtensionFields(
        var projectUuid: String = "00000000-0000-0000-0000-000000000000"
    ) {
        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            var self = other as? IntdashExtensionFields ?: return false
            if (projectUuid != self.projectUuid) return false
            return true
        }
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        var self = other as? ConnectRequest ?: return false
        if (this.requestId != self.requestId) return false
        if (this.protocolVersion != self.protocolVersion) return false
        if (this.nodeId != self.nodeId) return false
        if (this.pingInterval != self.pingInterval) return false
        if (this.pingTimeout != self.pingTimeout) return false
        if (!this.extensionFields.equals(self.extensionFields)) return false
        return true
    }
}

/**
 * @param requestId リクエストID
 * @param protocolVersion プロトコルバージョン
 * @param resultCode 結果コード
 * @param resultString 結果文字列
 * @param extensionFields 拡張フィールド
 */
internal class ConnectResponse(
    var requestId: UInt = 0u,
    var protocolVersion: String = "",
    var resultCode: ResultCode = ResultCode.SUCCEEDED,
    var resultString: String = "",
    var extensionFields: ExtensionFields = ExtensionFields()
) : IMessage {

    class ExtensionFields {

        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            var self = other as? ExtensionFields ?: return false
            return true
        }
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        var self = other as? ConnectResponse ?: return false
        if (this.requestId != self.requestId) return false
        if (this.protocolVersion != self.protocolVersion) return false
        if (this.resultCode != self.resultCode) return false
        if (this.resultString != self.resultString) return false
        if (!this.extensionFields.equals(self.extensionFields)) return false
        return true
    }
}

/**
 * @param resultCode 結果コード
 * @param resultString 結果文字列
 * @param extensionFields 拡張フィールド
 */
internal class Disconnect(
    var resultCode: ResultCode = ResultCode.SUCCEEDED,
    var resultString: String = "",
    var extensionFields: ExtensionFields = ExtensionFields()
) : IMessage {

    class ExtensionFields {

        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            var self = other as? ExtensionFields ?: return false
            return true
        }
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        var self = other as? Disconnect ?: return false
        if (this.resultCode != self.resultCode) return false
        if (this.resultString != self.resultString) return false
        if (!this.extensionFields.equals(self.extensionFields)) return false
        return true
    }
}