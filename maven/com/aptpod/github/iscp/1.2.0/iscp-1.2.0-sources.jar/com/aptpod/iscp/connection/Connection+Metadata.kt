package com.aptpod.iscp.connection

import com.aptpod.iscp.model.IscpException
import com.aptpod.iscp.model.BaseTime
import com.aptpod.iscp.logger.IscpLog
import com.aptpod.iscp.message.ResultCode
import com.aptpod.iscp.message.UpstreamMetadataAck
import com.aptpod.iscp.transport.Receiver

/**
 * 基準時刻を送信します。
 */
internal fun Connection.invokeSendBaseTimeAsync(baseTime: BaseTime, persist: Boolean, sendTimeout: Long, completion: ((Exception?) -> Unit)?) {
    var requestId = this.requestIdGenerator.generate()
    var receiver = Receiver("(requestId: ${requestId})", sendTimeout)
    receiver.subscribe<UpstreamMetadataAck> { msg, exception ->
        if (msg == null || exception != null) {
            IscpLog.e("failed to receive requestId($requestId) upstreamMetadataAck. ${exception?.javaClass?.name ?: ""}, requestId: ${msg?.requestId?.toString() ?: "null"}, resultCode: ${msg?.resultCode?.code?.toString() ?: "null"}, resultString: ${msg?.resultString ?: "null"} - Connection")
            // Receiverを解除
            this.receivers.unregister(receiver)
            completion?.invoke(exception ?: IscpException.Unexpected("upstreamMetadataAck not found."))
            return@subscribe
        }
        if (msg.requestId != requestId) { return@subscribe }
        // Receiverを解除
        this.receivers.unregister(receiver)
        IscpLog.d("didReceived upstreamMetadataAck(requestId: ${msg.requestId}, resultCode: ${msg.resultCode.code}, resultString: ${msg.resultString}) - Connection)")
        if (msg.resultCode != ResultCode.SUCCEEDED) {
            completion?.invoke(IscpException.FailedMessage(msg.resultCode.code, msg.resultString))
            return@subscribe
        }

        // メタデータの送信に成功
        completion?.invoke(null)
    }
    // Receiverを登録
    this.receivers.register(receiver)

    // Send UpstreamMetadataBaseTime
    var sendException = this.sendUpstreamMetadataBaseTime(requestId, baseTime, persist)
    if (sendException != null) {
        this.receivers.unregister(receiver)
        completion?.invoke(sendException)
        return
    }
}