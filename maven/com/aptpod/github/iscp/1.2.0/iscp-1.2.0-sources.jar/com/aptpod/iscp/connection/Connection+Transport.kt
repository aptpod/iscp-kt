package com.aptpod.iscp.connection

import com.aptpod.iscp.logger.IscpLog
import com.aptpod.iscp.transport.ITransport
import com.aptpod.iscp.transport.TransportCallbacks
import kotlin.concurrent.withLock

internal fun Connection.setupTransportCallbacks(transport: ITransport) {
    var self = this
    transport.callbacks = object : TransportCallbacks {

        override fun onConnect(transport: ITransport) {
            IscpLog.d("did connect transport.")
        }

        override fun onDisconnect(transport: ITransport) {
            IscpLog.d("did disconnect transport.")
            self.callbacks?.onDisconnect(self)
            connectionClosedWithCheckReconnect()
        }

        override fun onFailWithError(transport: ITransport, exception: Exception) {
            IscpLog.d("transport error. ${exception?.message ?: ""}")
            self.callbacks?.onFailWithError(self, exception)
        }

        override fun onReceiveMessage(transport: ITransport, data: ByteArray) {
            IscpLog.d("did receive transport message. ${data.size} bytes")
            self.transportMessageLock.withLock {
                var (msg, err) = self.converter.decodeFrom(data)
                if (msg == null) {
                    IscpLog.w("protocol message decoding failed. ${err?.message ?: ""}")
                    // デコードに失敗した場合は何もしない
                    return@withLock
                }
                IscpLog.d("received message: ${msg.javaClass.name}")
                self.receivers.setReceivedMessage(msg)
            }
        }
    }
}