package com.aptpod.iscp.helpers

import java.util.concurrent.locks.ReentrantLock
import kotlin.concurrent.withLock

/**
 * 複数のタスクをまとめて管理するためのグループです。
 *
 * グループにタスクを登録すると、それらのタスクが同じキューまたは別のキューで非同期的に実行されるよう管理することができます。すべてのタスクが終了すると、グループ完了時の処理が実行されます。または、グループ内のすべてのタスクが同期的に処理され完了するまで待機することもできます。
 */
class DispatchGroup {

    private var count = 0
    private var runnable: Runnable? = null

    @Synchronized fun enter() {
        count += 1
    }

    @Synchronized fun leave() {
        count -= 1
        notifyGroup()
    }

    fun notifyAsync(r: Runnable) {
        runnable = r
        notifyGroup()
    }

    fun notifySync() {
        val threadLock = ReentrantLock()
        val condition = threadLock.newCondition()
        runnable = Runnable {
            threadLock.withLock {
                condition.signal()
            }
        }
        Thread {
            notifyGroup()
        }.start()
        threadLock.withLock {
            condition.await()
        }
    }

    private fun notifyGroup() {
        if(count <= 0 && runnable != null) {
            runnable?.run()
        }
    }

}