package com.aptpod.iscp.encoding.protobuf

import com.aptpod.iscp.encoding.autogen.iscp2.v1.Message as ProtoMessage
import com.aptpod.iscp.encoding.EncodingName
import com.aptpod.iscp.encoding.IMessageConverter
import com.aptpod.iscp.encoding.convert.protoToWire
import com.aptpod.iscp.encoding.convert.wireToProto
import com.aptpod.iscp.message.IMessage

internal class Protobuf : IMessageConverter {

    override val name: EncodingName
        get() = EncodingName.PROTOBUF

    override fun encodeTo(message: IMessage) : Pair<ByteArray?, Exception?> {
        try {
            var (pb, err) = wireToProto(message)
            if (err != null) {
                return Pair(null, err)
            }
            return Pair(pb!!.toByteArray(), null)
        }
        catch (e: Exception) {
            return Pair(null, e)
        }
    }

    override fun decodeFrom(serializedData: ByteArray): Pair<IMessage?, Exception?> {
        try {
            var pb = ProtoMessage.parseFrom(serializedData)
            return protoToWire(pb)
        }
        catch (e: Exception) {
            return Pair(null, e)
        }
    }
}