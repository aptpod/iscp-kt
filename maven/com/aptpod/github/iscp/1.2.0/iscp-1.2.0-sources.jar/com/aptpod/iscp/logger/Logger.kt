package com.aptpod.iscp.logger

import com.aptpod.iscp.LOG_TAG
import java.util.concurrent.CopyOnWriteArrayList
import java.util.logging.Logger

/**
 * ログレベルを表す列挙型です。
 */
enum class IscpLogLevel(val value: Int) {
    VERBOSE(0),
    DEBUG(1),
    INFO(2),
    WARNING(3),
    ERROR(4),
    NONE(5);

    val logHeader: String
        get() {
            return when (this) {
                VERBOSE -> "[VERB]"
                DEBUG -> "[DEBUG]"
                INFO -> "[INFO]"
                WARNING -> "[WARN]"
                ERROR -> "[ERROR]"
                NONE -> ""
            }
        }
}

/**
 * IscpLogを使ってログを出力する際に使用するイベントリスナーです。
 */
interface IscpLogListener {
    fun onOutputLog(message: String, level: IscpLogLevel, function: String, file: String, line: Int)
}

/**
 * iSCPクライアント内のログ出力クラスです。
 */
class IscpLog {

    private object Holder {
        val Shared = IscpLog()
    }
    companion object {
        val Shared: IscpLog by lazy { Holder.Shared }

        internal fun d(message: String) {
            Shared.d(message, Thread.currentThread().stackTrace[3])
        }

        internal fun i(message: String) {
            Shared.i(message, Thread.currentThread().stackTrace[3])
        }

        internal fun w(message: String) {
            Shared.w(message, Thread.currentThread().stackTrace[3])
        }

        internal fun e(message: String) {
            Shared.e(message, Thread.currentThread().stackTrace[3])
        }
    }

    val logger = Logger.getLogger(LOG_TAG)

    /**
     * 設定されているログレベル。
     */
    var level: IscpLogLevel

    private var listeners: CopyOnWriteArrayList<IscpLogListener> = CopyOnWriteArrayList()

    fun addListener(listener: IscpLogListener) {
        if (!listeners.contains(listener)) {
            listeners.add(listener)
        }
    }

    fun removeListener(listener: IscpLogListener) {
        if (listeners.contains(listener)) {
            listeners.remove(listener)
        }
    }

    init {
        level = IscpLogLevel.INFO
    }

    internal fun d(message: String, stack: StackTraceElement) {
        val fileName = stack.fileName ?: stack.className.substringAfterLast('.')
        outputLog(message, IscpLogLevel.DEBUG, stack.methodName, fileName, stack.lineNumber)
    }

    internal fun i(message: String, stack: StackTraceElement) {
        val fileName = stack.fileName ?: stack.className.substringAfterLast('.')
        outputLog(message, IscpLogLevel.INFO, stack.methodName, fileName, stack.lineNumber)
    }

    internal fun w(message: String, stack: StackTraceElement) {
        val fileName = stack.fileName ?: stack.className.substringAfterLast('.')
        outputLog(message, IscpLogLevel.WARNING, stack.methodName, fileName, stack.lineNumber)
    }

    internal fun e(message: String, stack: StackTraceElement) {
        val fileName = stack.fileName ?: stack.className.substringAfterLast('.')
        outputLog(message, IscpLogLevel.ERROR, stack.methodName, fileName, stack.lineNumber)
    }

    private fun outputLog(message: String, targetLevel: IscpLogLevel, function: String, fileName: String, line: Int) {
        listeners.forEach { it.onOutputLog(message, targetLevel, function, fileName, line) }

        if (targetLevel.value < this.level.value) return

        if (this.level == IscpLogLevel.VERBOSE) {
            logger.info("${targetLevel.logHeader} $fileName[$line] $function: $message")
        }
        else {
            when (targetLevel) {
                IscpLogLevel.WARNING -> logger.warning("$message")
                IscpLogLevel.ERROR -> logger.severe("$message")
                else -> logger.info("${targetLevel.logHeader}: $message")
            }
        }
    }
}