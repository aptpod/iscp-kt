#!/bin/bash
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
AUTOGEN_DIR="$SCRIPT_DIR/autogen"
PROTO_DIR="$SCRIPT_DIR/../../../../../../../../../iscp-proto/proto"

if [ -e "$AUTOGEN_DIR" ]; then rm -rf "$AUTOGEN_DIR"; fi

cd "$SCRIPT_DIR"
buf generate --template buf.gen.yaml "$PROTO_DIR"
