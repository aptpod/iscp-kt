package com.aptpod.iscp.message

internal interface IMessage