package com.aptpod.iscp.message

import com.aptpod.iscp.helpers.UUIDUtils
import java.util.UUID

/**
 * @param requestId リクエストID
 * @param sessionId セッションID
 * @param ackInterval ACKの返却間隔
 *
 * 単位はミリ秒
 * @param expiryInterval 有効期限
 *
 * 単位は秒
 * @param dataIds データIDリスト
 * @param qos QoS
 * @param extensionFields 拡張フィールド
 */
internal class UpstreamOpenRequest(
    var requestId: UInt = 0u,
    var sessionId: String = "",
    var ackInterval: UShort = 0u,
    var expiryInterval: UShort = 0u,
    var dataIds: List<DataId> = listOf(),
    var qos: QoS = QoS.UNRELIABLE,
    var extensionFields: ExtensionFields = ExtensionFields()
) : IMessage {
    /**
     * @param persist 永続化フラグ
     */
    class ExtensionFields(
        var persist: Boolean = false
    ) {
        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            var self = other as? ExtensionFields ?: return false
            if (this.persist != self.persist) return false
            return true
        }
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        var self = other as? UpstreamOpenRequest ?: return false
        if (this.requestId != self.requestId) return false
        if (this.sessionId != self.sessionId) return false
        if (this.ackInterval != self.ackInterval) return false
        if (this.expiryInterval != self.expiryInterval) return false
        if (!this.dataIds.equals(self.dataIds)) return false
        if (this.qos != self.qos) return false
        if (!this.extensionFields.equals(self.extensionFields)) return false
        return true
    }
}

/**
 * @param requestId リクエストID
 * @param assignedStreamId 割り当てられたストリームID
 * @param assignedStreamIdAlias 割り当てられたストリームIDエイリアス
 * @param dataIdAliases データIDエイリアス
 * @param serverTime サーバー時刻
 *
 * 単位はナノ秒
 * @param resultCode 結果コード
 * @param resultString 結果文字列
 * @param resumeToken ストリーム再開用トークン
 * @param extensionFields 拡張フィールド
 */
internal class UpstreamOpenResponse(
    var requestId: UInt = 0u,
    var assignedStreamId: UUID = UUIDUtils.empty(),
    var assignedStreamIdAlias: UInt = 0u,
    var dataIdAliases: MutableMap<UInt, DataId> = mutableMapOf(),
    var serverTime: Long = 0,
    var resultCode: ResultCode = ResultCode.SUCCEEDED,
    var resultString: String = "",
    var resumeToken: String = "",
    var extensionFields: ExtensionFields = ExtensionFields()
) : IMessage {
    class ExtensionFields {

        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            var self = other as? ExtensionFields ?: return false
            return true
        }
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        var self = other as? UpstreamOpenResponse ?: return false
        if (this.requestId != self.requestId) return false
        if (this.assignedStreamId != self.assignedStreamId) return false
        if (this.assignedStreamIdAlias != self.assignedStreamIdAlias) return false
        if (!this.dataIdAliases.equals(self.dataIdAliases)) return false
        if (this.serverTime != self.serverTime) return false
        if (this.resultCode != self.resultCode) return false
        if (this.resultString != self.resultString) return false
        if (!this.extensionFields.equals(self.extensionFields)) return false
        return true
    }
}

/**
 * @param requestId リクエストID
 * @param streamId ストリームID
 * @param resumeToken ストリーム再開用トークン
 * @param extensionFields 拡張フィールド
 */
internal class UpstreamResumeRequest(
    var requestId: UInt = 0u,
    var streamId: UUID = UUIDUtils.empty(),
    var resumeToken: String = "",
    var extensionFields: ExtensionFields = ExtensionFields()
) : IMessage {

    class ExtensionFields {

        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            var self = other as? ExtensionFields ?: return false
            return true
        }
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        var self = other as? UpstreamResumeRequest ?: return false
        if (this.requestId != self.requestId) return false
        if (this.streamId != self.streamId) return false
        return true
    }
}

/**
 * @param requestId リクエストID
 * @param assignedStreamIdAlias 割り当てられたストリームIDエイリアス
 * @param resultCode 結果コード
 * @param resultString 結果文字列
 * @param resumeToken ストリーム再開用トークン
 * @param extensionFields 拡張フィールド
 */
internal class UpstreamResumeResponse(
    var requestId: UInt = 0u,
    var assignedStreamIdAlias: UInt = 0u,
    var resultCode: ResultCode = ResultCode.SUCCEEDED,
    var resultString: String = "",
    var resumeToken: String = "",
    var extensionFields: ExtensionFields = ExtensionFields()
) : IMessage {

    class ExtensionFields {

        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            var self = other as? ExtensionFields ?: return false
            return true
        }
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        var self = other as? UpstreamResumeResponse ?: return false
        if (this.requestId != self.requestId) return false
        if (this.assignedStreamIdAlias != self.assignedStreamIdAlias) return false
        if (this.resultCode != self.resultCode) return false
        if (this.resultString != self.resultString) return false
        if (!this.extensionFields.equals(self.extensionFields)) return false
        return true
    }
}

/**
 * @param requestId リクエストID
 * @param streamId ストリームID
 * @param totalDataPoints 総データポイント数
 * @param finalSequenceNumber 最終シーケンス番号
 * @param extensionFields 拡張フィールド
 */
internal class UpstreamCloseRequest(
    var requestId: UInt = 0u,
    var streamId: UUID = UUIDUtils.empty(),
    var totalDataPoints: ULong = 0u,
    var finalSequenceNumber: UInt = 0u,
    var extensionFields: ExtensionFields = ExtensionFields()
) : IMessage {

    /**
     * @param closeSession セッションの終了要否
     */
    class ExtensionFields(var closeSession: Boolean = false) {

        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            var self = other as? ExtensionFields ?: return false
            if (this.closeSession != self.closeSession) return false
            return true
        }
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        var self = other as? UpstreamCloseRequest ?: return false
        if (this.requestId != self.requestId) return false
        if (this.streamId != self.streamId) return false
        if (!this.extensionFields.equals(self.extensionFields)) return false
        return true
    }
}

/**
 * @param requestId リクエストID
 * @param resultCode 結果コード
 * @param resultString 結果文字列
 * @param extensionFields 拡張フィールド
 */
internal class UpstreamCloseResponse(
    var requestId: UInt = 0u,
    var resultCode: ResultCode = ResultCode.SUCCEEDED,
    var resultString: String = "",
    var extensionFields: ExtensionFields = ExtensionFields()
) : IMessage {

    class ExtensionFields {

        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            var self = other as? ExtensionFields ?: return false
            return true
        }
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        var self = other as? UpstreamCloseResponse ?: return false
        if (this.requestId != self.requestId) return false
        if (this.resultCode != self.resultCode) return false
        if (this.resultString != self.resultString) return false
        if (!this.extensionFields.equals(self.extensionFields)) return false
        return true
    }
}