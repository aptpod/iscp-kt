package com.aptpod.iscp.model

import com.aptpod.iscp.helpers.UUIDUtils
import java.util.UUID


/**
 * `Upstream` のフラッシュの方法について定義します。
 */
class FlushPolicy {

    companion object {
        /**
         * データポイントのフラッシュポリシーのデフォルト値。
         */
        val DEFAULT_FLUSH_TYPE = FlushType.INTERVAL_OR_BUFFER_SIZE
        /**
         * フラッシュのバッファサイズのデフォルト値（UInt）。
         */
        const val DEFAULT_BUFFER_SIZE: Int = 10_000
        /**
         * フラッシュの送信間隔のデフォルト値。
         */
        const val DEFAULT_INTERVAL: Long = 100

        /**
         * 即時フラッシュを行う `FlushPolicy` 。
         */
        fun immediately() : FlushPolicy {
            return FlushPolicy(FlushType.IMMEDIATELY, 0, 0)
        }

        /**
         * インターバルによるフラッシュを行うFlushPolicy。
         * @param interval Long: フラッシュの間隔（ミリ秒）。
         */
        fun intervalOnly(interval: Long = DEFAULT_INTERVAL) : FlushPolicy {
            return FlushPolicy(FlushType.INTERVAL_ONLY, interval, 0)
        }

        /**
         * インターバル、またはバッファサイズによるフラッシュを行う `FlushPolicy` 。
         * @param interval フラッシュの間隔（ミリ秒）。
         * @param bufferSize フラッシュのバッファサイズ（UInt）。
         */
        fun intervalOrBufferSize(interval: Long = DEFAULT_INTERVAL, bufferSize: Int = DEFAULT_BUFFER_SIZE) : FlushPolicy {
            return FlushPolicy(FlushType.INTERVAL_OR_BUFFER_SIZE, interval, bufferSize)
        }

        /**
         * バッファサイズによるフラッシュを行う `FlushPolicy` 。
         * @param bufferSize フラッシュのバッファサイズ（UInt）。
         */
        fun bufferSizeOnly(bufferSize: Int = DEFAULT_BUFFER_SIZE) : FlushPolicy {
            return FlushPolicy(FlushType.BUFFER_SIZE_ONLY, 0, bufferSize)
        }

        /**
         * フラッシュを行わない `FlushPolicy` 。
         *
         * この `FlushPolicy` は明示的なフラッシュを強制します。
         */
        fun noFlush() : FlushPolicy {
            return FlushPolicy(FlushType.NONE, 0, 0)
        }
    }

    /**
     * `Upstream` のフラッシュ方法です。
     */
    enum class FlushType {
        /**
         * フラッシュを行わない。
         */
        NONE,
        /**
         * 時間間隔によるフラッシュのみ。
         */
        INTERVAL_ONLY,
        /**
         * バッファサイズによるフラッシュのみ。
         */
        BUFFER_SIZE_ONLY,
        /**
         * 時間間隔によるフラッシュ、またはバッファサイズによるフラッシュ。
         *
         * どちらかの条件を満たしたらフラッシュする。
         */
        INTERVAL_OR_BUFFER_SIZE,
        /**
         * 即時フラッシュ。
         */
        IMMEDIATELY
    }

    /**
     * `Upstream` のフラッシュ方法。
     */
    val type: FlushType
    /**
     * フラッシュの間隔（ミリ秒）。
     *
     * `FlushPolicy` が `IntervalOnly` または `IntervalOrBufferSize` の場合のみ有効となります。
     */
    val interval: Long
    /**
     * フラッシュのバッファサイズ（UInt）。
     *
     * `FlushPolicy` が `BufferSizeOnly` または `IntervalOrBufferSize` の場合のみ有効となります。
     */
    val bufferSize: Int

    internal constructor(type: FlushType = DEFAULT_FLUSH_TYPE, interval: Long = DEFAULT_INTERVAL, bufferSize: Int = DEFAULT_BUFFER_SIZE) {
        this.type = type
        this.interval = interval
        this.bufferSize = bufferSize
    }
}

/**
 * `QoS` を表します。
 *
 * `QoS（Quality of Service）` は、トランスポートのコネクションが切断された場合のデータの取扱を規定します。
 */
enum class QoS {
    /**
     * 低信頼。
     */
    UNRELIABLE,
    /**
     * 高信頼。
     */
    RELIABLE,
    /**
     * 信頼性のあるトランスポートを利用する低信頼。
     */
    PARTIAL
}

/**
 * ダウンストリームフィルタリファレンス。
 *
 * ダウンストリームされたデータポイントグループが、どのダウンストリームフィルタのどのデータフィルタにマッチしているかを示します。
 * @param downstreamFilterIndex ダウンストリームフィルタインデックス。
 *
 * ダウンストリームのオープン時に設定したダウンストリームフィルタの配列のうち、マッチした要素のインデックス番号です。
 * @param dataFilterIndex データフィルタインデックス。
 *
 * `downstreamFilterIndex` で示されたダウンストリームフィルタが持つデータフィルタの配列（データIDの配列）のうち、このデータポイントグループにマッチした要素のインデックス番号です。
 */
class DownstreamFilterReference internal constructor(
    var downstreamFilterIndex: Int = 0,
    var dataFilterIndex: Int = 0
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        var self = other as? DownstreamFilterReference ?: return false
        if (this.downstreamFilterIndex != self.downstreamFilterIndex) return false
        if (this.dataFilterIndex != self.dataFilterIndex) return false
        return true
    }
}

/**
 * ダウンストリームフィルタリファレンス。
 *
 * ダウンストリームフィルタリファレンスは、データポイントグループがどのダウンストリームフィルタにマッチしたことによりダウンストリームされているのかを示す情報です。
 *
 * データポイントグループが複数のダウンストリームフィルタにマッチしている場合、 `references` には複数の `DownstreamFilterReference` が格納されます。
 * @param references データポイントグループがマッチしたダウンストリームフィルタとデータフィルタを示す `DownstreamFilterReference` の配列。
 */
class DownstreamFilterReferences internal constructor(
    var references: List<DownstreamFilterReference> = listOf()
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        var self = other as? DownstreamFilterReferences ?: return false
        if (!this.references.equals(self.references)) return false
        return true
    }
}

/**
 * ダウンストリームフィルタです。
 *
 * ダウンストリームフィルタはダウンストリームにおいてブローカーからノードに送信するデータを特定します。
 * @param sourceNodeId 送信元ノードID。
 * @param dataFilters データフィルタのリスト。
 */
class DownstreamFilter(
    var sourceNodeId: String = "",
    var dataFilters: List<DataFilter> = listOf()
) {

    companion object {
        /**
         * 指定したノードが送信するすべてのデータを取得するフィルタです。
         * @param sourceNodeId データ取得対象とする送信元ノード。
         */
        fun allFor(sourceNodeId: String) : DownstreamFilter {
            return DownstreamFilter(sourceNodeId, listOf(DataFilter.all))
        }
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        var self = other as? DownstreamFilter ?: return false
        if (this.sourceNodeId != self.sourceNodeId) return false
        if (!this.dataFilters.equals(self.dataFilters)) return false
        return true
    }
}

/**
 * 受信するデータを指定するためのデータフィルタです。
 *
 * 名称や型の指定において階層構造を表現したいときには、特殊文字 `/` をセパレータとして使用することができます。
 *
 * 特殊文字 `#` はマルチレベルワイルドカードです。
 * - フィルタが `#` のとき、 `name` はマッチします。
 * - フィルタが `#` のとき、` group/name` はマッチします。
 * - フィルタが `group/#` のとき、 `group/name` はマッチします。
 * - フィルタが `group/#` のとき、 `group/sub-group/name` はマッチします。
 * - フィルタが `group/#` のとき、 `other-group/name` はマッチしません。
 * @param name 名称。
 * @param type 型。
 */
class DataFilter(
    var name: String = "",
    var type: String = ""
) {

    companion object {
        /**
         * 全データ型、全データ名称を受信対象とするデータフィルタです。
         */
        @JvmStatic val all: DataFilter get() = DataFilter("#", "#")

        /**
         * DataFilterの文字列表現からDataFilterを生成します。
         */
        fun parse(string: String) : Pair<DataFilter?, Exception?> {
            try {
                var data = string.toByteArray(Charsets.UTF_8)
                var str = data.toString(Charsets.UTF_8)
                var sp = str.split(":")
                if (sp.count() != 2) {
                    return Pair(null, IscpException.Unexpected("invalid dataFilter. [$str]"))
                }
                return Pair(DataFilter(sp[0], sp[1]), null)
            }
            catch (e: Exception) {
                return Pair(null, e)
            }
        }
    }

    /**
     * データフィルタの文字列表現です。
     */
    val string: String get() = "$name:$type"

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        var self = other as? DataFilter ?: return false
        if (this.name != self.name) return false
        if (this.type != self.type) return false
        return true
    }
}

/**
 * データポイントの、名称とデータ型を表す識別子です。
 *
 * おもに、ブローカーおよびノードでのデータの意味と型の特定、ダウンストリームフィルタにて指定された受信条件に各時系列データポイントが合致するかどうかの判定、などに使用されます。
 *
 * 特殊文字 `/` はセパレータです。名称/型の階層構造を表現することができます。
 * @param name 名称。
 * @param type 型。
 */
class DataId(
    var name: String = "",
    var type: String = ""
) {
    companion object {
        /**
         * データIDの文字列表現からDataIdを生成します。
         */
        fun parse(string: String) : Pair<DataId?, Exception?> {
            try {
                var data = string.toByteArray(Charsets.UTF_8)
                var str = data.toString(Charsets.UTF_8)
                var sp = str.split(":")
                if (sp.count() != 2) {
                    return Pair(null, IscpException.Unexpected("invalid dataId. [$str]"))
                }
                return Pair(DataId(sp[0], sp[1]), null)
            }
            catch (e: Exception) {
                return Pair(null, e)
            }
        }

        /**
         * データIDに使用される名前及び型に使用する文字列が有効かどうか調べます。
         */
        fun isValid(str: String) : Boolean {
            if (str.isNullOrEmpty()) { return false }
            if (str == "/") { return false }
            if (str == "//") { return false }
            if (str.contains("#") || str.contains("+")) { return false }
            if (str.contains(":")) { return false }
            return true
        }
    }

    /**
     * 設定中の名前が有効かどうか。
     */
    val isNameValid: Boolean get() = isValid(name)

    /**
     * 設定中の型が有効かどうか。
     */
    val isTypeValid: Boolean get() = isValid(type)

    /**
     * データIDの文字列表現です。
     */
    val string: String get() = "$name:$type"

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        var self = other as? DataId ?: return false
        if (this.name != self.name) return false
        if (this.type != self.type) return false
        return true
    }
}

/**
 * アップストリームチャンクを表します。
 *
 * 上り用のストリームチャンクです。
 *
 * iSCP におけるデータ伝送は、このチャンク単位で行われます。
 * @param sequenceNumber 送信予定のシーケンス番号（UInt）。
 * @param dataPointGroups 送信予定のデータポイントをデータIDごとにまとめた集合のリスト。
 * @param dataPointCount 送信予定のデータポイント数（ULong）。
 * @param payloadSize 送信予定のペイロードサイズ（ULong）。
 */
class UpstreamChunk internal constructor(
    var sequenceNumber: Int,
    var dataPointGroups: List<DataPointGroup>,
    var dataPointCount: Long,
    var payloadSize: Long
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        var self = other as? UpstreamChunk ?: return false
        if (this.sequenceNumber != self.sequenceNumber) return false
        if (!this.dataPointGroups.equals(self.dataPointGroups)) return false
        if (this.dataPointCount != self.dataPointCount) return false
        if (this.payloadSize != self.payloadSize) return false
        return true
    }
}

/**
 * アップストリームチャンクに対する確認応答です。
 * @param sequenceNumber 受信したシーケンス番号（UInt）。
 * @param resultCode 受信した結果コード（UInt）。
 * @param resultString 受信した結果文字列。
 */
class UpstreamChunkAck internal constructor(
    var sequenceNumber: Int,
    var resultCode: Int,
    var resultString: String
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        var self = other as? UpstreamChunkAck ?: return false
        if (this.sequenceNumber != self.sequenceNumber) return false
        if (this.resultCode != self.resultCode) return false
        if (this.resultString != self.resultString) return false
        return true
    }
}

/**
 * ダウンストリームチャンクを表します。
 *
 * 下り用のストリームチャンクです。iSCP におけるデータ伝送は、このチャンク単位で行われます。
 * @param sequenceNumber シーケンス番号（UInt）。
 * @param dataPointGroups データポイントグループのリスト。
 * @param upstreamInfo アップストリーム情報。
 * @param downstreamFilterReferences `dataPointGroups` の各データポイントグループがマッチしたフィルタ条件を示す `DownstreamFilterReferences` の配列。
 *
 * 要素数は `dataPointGroups` の要素数と同じです。
 * `downstreamFilterReferences[i]` は `dataPointGroups[i]` に対応します。
 * ブローカーが `DownstreamFilterReferences` 機能を未サポートの場合は要素数が `0` になります。
 */
class DownstreamChunk internal constructor(
    var sequenceNumber: Int = 0,
    var dataPointGroups: List<DataPointGroup> = listOf(),
    var upstreamInfo: UpstreamInfo = UpstreamInfo(),
    var downstreamFilterReferences: List<DownstreamFilterReferences> = listOf()
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        val self = other as? DownstreamChunk ?: return false
        if (this.sequenceNumber != self.sequenceNumber) return false
        if (!this.dataPointGroups.equals(self.dataPointGroups)) return false
        if (!this.upstreamInfo.equals(self.upstreamInfo)) return false
        if (!this.downstreamFilterReferences.equals(self.downstreamFilterReferences)) return false
        return true
    }
}

/**
 * アップストリーム情報。
 * @param sessionId セッションID。
 * @param streamId StreamId;
 * @param sourceNodeId SourceNodeId;
 */
class UpstreamInfo internal constructor(
    var sessionId: String = "",
    var streamId: UUID = UUIDUtils.empty(),
    var sourceNodeId: String = ""
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        var self = other as? UpstreamInfo ?: return false
        if (this.sessionId != self.sessionId) return false
        if (this.streamId != self.streamId) return false
        if (this.sourceNodeId != self.sourceNodeId) return false
        return true
    }
}

/**
 * ストリームチャンクの中のデータポイントをデータIDごとにまとめた集合です。
 * @param dataId データID。
 * @param dataPoints データポイントのリスト。
 */
class DataPointGroup(
    var dataId: DataId = DataId(),
    var dataPoints: MutableList<DataPoint> = mutableListOf()
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        var self = other as? DataPointGroup ?: return false
        if (!this.dataId.equals(self.dataId)) return false
        if (!this.dataPoints.equals(self.dataPoints)) return false
        return true
    }
}

/**
 * データポイントです。
 *
 * データポイントは、経過時間を付与されたバイナリデータです。 バイナリデータのことをペイロードと呼びます。
 * @param elapsedTime 経過時間（ナノ秒）。
 * @param payload ペイロード。
 */
class DataPoint(
    var elapsedTime: Long = 0,
    var payload: ByteArray = ByteArray(0)
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        var self = other as? DataPoint ?: return false
        if (this.elapsedTime != self.elapsedTime) return false
        if (!this.payload.contentEquals(self.payload)) return false
        return true
    }
}

//region Metadata

/**
 * 基準時刻です。
 *
 * あるセッションの基準となる時刻です。
 * @param sessionId セッションID
 * @param name 基準時刻の名称
 * @param priority 優先度（UByte）
 * @param elapsedTime 経過時間
 *
 * 単位はナノ秒
 * @param baseTime 基準時刻
 *
 * 単位はナノ秒
 */
class BaseTime(
    var sessionId: String = "",
    var name: String = "",
    var priority: Byte = 0,
    var elapsedTime: Long = 0,
    var baseTime: Long = 0
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        var self = other as? BaseTime ?: return false
        if (this.sessionId != self.sessionId) return false
        if (this.name != self.name) return false
        if (this.priority != self.priority) return false
        if (this.elapsedTime != self.elapsedTime) return false
        if (this.baseTime != self.baseTime) return false
        return true
    }
}

/**
 * あるダウンストリームが異常切断したことを知らせるメタデータです。
 * @param streamId ストリームID。
 */
class DownstreamAbnormalClose internal constructor(
    var streamId: UUID = UUIDUtils.empty()
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        var self = other as? DownstreamAbnormalClose ?: return false
        if (this.streamId != self.streamId) return false
        return true
    }
}

/**
 * あるダウンストリームが正常切断したことを知らせるメタデータです。
 * @param streamId ストリームID。
 */
class DownstreamNormalClose internal constructor(
    var streamId: UUID = UUIDUtils.empty()
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        var self = other as? DownstreamNormalClose ?: return false
        if (this.streamId != self.streamId) return false
        return true
    }
}

/**
 * あるダウンストリームが開いたことを知らせるメタデータです。
 * @param streamId ストリームID。
 * @param downstreamFilters ダウンストリームフィルタのリスト。
 * @param qos QoS。
 */
class DownstreamOpen internal constructor(
    var streamId: UUID = UUIDUtils.empty(),
    var downstreamFilters: List<DownstreamFilter> = listOf(),
    var qos: QoS = QoS.UNRELIABLE
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        var self = other as? DownstreamOpen ?: return false
        if (this.streamId != self.streamId) return false
        if (!this.downstreamFilters.equals(self.downstreamFilters)) return false
        if (this.qos != self.qos) return false
        return true
    }
}

/**
 * あるダウンストリームが再開したことを知らせるメタデータです。
 * @param streamId ストリームID。
 * @param downstreamFilters ダウンストリームフィルタのリスト。
 * @param qos QoS。
 */
class DownstreamResume  internal constructor(
    var streamId: UUID = UUIDUtils.empty(),
    var downstreamFilters: List<DownstreamFilter> = listOf(),
    var qos: QoS = QoS.UNRELIABLE
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        var self = other as? DownstreamResume ?: return false
        if (this.streamId != self.streamId) return false
        if (!this.downstreamFilters.equals(self.downstreamFilters)) return false
        if (this.qos != self.qos) return false
        return true
    }
}

/**
 * あるアップストリームが異常切断したことを知らせるメタデータです。
 * @param streamId ストリームID。
 * @param sessionId セッションID。
 */
class UpstreamAbnormalClose internal constructor(
    var streamId: UUID = UUIDUtils.empty(),
    var sessionId: String = ""
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        var self = other as? UpstreamAbnormalClose ?: return false
        if (this.streamId != self.streamId) return false
        if (this.sessionId != self.sessionId) return false
        return true
    }
}

/**
 * あるアップストリームが正常切断したことを知らせるメタデータです。
 * @param streamId ストリームID。
 * @param sessionId セッションID。
 * @param totalDataPoints 総データポイント数（ULong）。
 * @param finalSequenceNumber 最終シーケンス番号（UInt）。
 */
class UpstreamNormalClose internal constructor(
    var streamId: UUID = UUIDUtils.empty(),
    var sessionId: String = "",
    var totalDataPoints: Long = 0,
    var finalSequenceNumber: Int = 0
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        var self = other as? UpstreamNormalClose ?: return false
        if (this.streamId != self.streamId) return false
        if (this.sessionId != self.sessionId) return false
        if (this.totalDataPoints != self.totalDataPoints) return false
        if (this.finalSequenceNumber != self.finalSequenceNumber) return false
        return true
    }
}

/**
 * あるアップストリームが開いたことを知らせるメタデータです。
 * @param streamId ストリームID。
 * @param sessionId セッションID。
 * @param qos QoS。
 */
class UpstreamOpen internal constructor(
    var streamId: UUID = UUIDUtils.empty(),
    var sessionId: String = "",
    var qos: QoS = QoS.UNRELIABLE
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        var self = other as? UpstreamOpen ?: return false
        if (this.streamId != self.streamId) return false
        if (this.sessionId != self.sessionId) return false
        if (this.qos != self.qos) return false
        return true
    }
}

/**
 * あるアップストリームが再開したことを知らせるメタデータです。
 * @param streamId ストリームID。
 * @param sessionId セッションID。
 */
class UpstreamResume internal constructor(
    var streamId: UUID = UUIDUtils.empty(),
    var sessionId: String = ""
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        var self = other as? UpstreamResume ?: return false
        if (this.streamId != self.streamId) return false
        if (this.sessionId != self.sessionId) return false
        return true
    }
}

//endregion

/**
 * ダウンストリームメタデータです。
 *
 * メタデータを格納してブローカーからノードへ転送する為のメッセージです。
 * @param sourceNodeId
 */
class DownstreamMetadata internal constructor(
    var sourceNodeId: String = ""
) {

    /**
     * メタ情報の識別値。
     */
    var type: MetadataType? = null
        internal set

    /**
     * メタデータの識別値。
     */
    enum class MetadataType {
        /**
         * 基準時刻のメタデータ。
         */
        BASE_TIME,
        /**
         * あるアップストリームが開いたことを知らせるメタデータ。
         */
        UPSTREAM_OPEN,
        /**
         * あるアップストリームが異常切断したことを知らせるメタデータ。
         */
        UPSTREAM_ABNORMAL_CLOSE,
        /**
         * あるアップストリームが再開したことを知らせるメタデータ。
         */
        UPSTREAM_RESUME,
        /**
         * あるアップストリームが正常切断したことを知らせるメタデータ。
         */
        UPSTREAM_NORMAL_CLOSE,
        /**
         * あるダウンストリームが開いたことを知らせるメタデータ。
         */
        DOWNSTREAM_OPEN,
        /**
         * あるダウンストリームが異常切断したことを知らせるメタデータ。
         */
        DOWNSTREAM_ABNORMAL_CLOSE,
        /**
         * あるダウンストリームが再開したことを知らせるメタデータ。
         */
        DOWNSTREAM_RESUME,
        /**
         * あるダウンストリームが正常切断したことを知らせるメタデータ。
         */
        DOWNSTREAM_NORMAL_CLOSE
    }
    internal var metadata: Any? = null

    var baseTime: BaseTime?
        get() = if (type == MetadataType.BASE_TIME) metadata as? BaseTime else null
        set(value) {
            metadata = value
            type = if (value == null) null else MetadataType.BASE_TIME
        }

    var upstreamOpen: UpstreamOpen?
        get() = if (type == MetadataType.UPSTREAM_OPEN) metadata as? UpstreamOpen else null
        set(value) {
            metadata = value
            type = if (value == null) null else MetadataType.UPSTREAM_OPEN
        }

    var upstreamAbnormalClose: UpstreamAbnormalClose?
        get() = if (type == MetadataType.UPSTREAM_ABNORMAL_CLOSE) metadata as? UpstreamAbnormalClose else null
        set(value) {
            metadata = value
            type = if (value == null) null else MetadataType.UPSTREAM_ABNORMAL_CLOSE
        }

    var upstreamResume: UpstreamResume?
        get() = if (type == MetadataType.UPSTREAM_RESUME) metadata as? UpstreamResume else null
        set(value) {
            metadata = value
            type = if (value == null) null else MetadataType.UPSTREAM_RESUME
        }

    var upstreamNormalClose: UpstreamNormalClose?
        get() = if (type == MetadataType.UPSTREAM_NORMAL_CLOSE) metadata as? UpstreamNormalClose else null
        set(value) {
            metadata = value
            type = if (value == null) null else MetadataType.UPSTREAM_NORMAL_CLOSE
        }

    var downstreamOpen: DownstreamOpen?
        get() = if (type == MetadataType.DOWNSTREAM_OPEN) metadata as? DownstreamOpen else null
        set(value) {
            metadata = value
            type = if (value == null) null else MetadataType.DOWNSTREAM_OPEN
        }

    var downstreamAbnormalClose: DownstreamAbnormalClose?
        get() = if (type == MetadataType.DOWNSTREAM_ABNORMAL_CLOSE) metadata as? DownstreamAbnormalClose else null
        set(value) {
            metadata = value
            type = if (value == null) null else MetadataType.DOWNSTREAM_ABNORMAL_CLOSE
        }

    var downstreamResume: DownstreamResume?
        get() = if (type == MetadataType.DOWNSTREAM_RESUME) metadata as? DownstreamResume else null
        set(value) {
            metadata = value
            type = if (value == null) null else MetadataType.DOWNSTREAM_RESUME
        }

    var downstreamNormalClose: DownstreamNormalClose?
        get() = if (type == MetadataType.DOWNSTREAM_NORMAL_CLOSE) metadata as? DownstreamNormalClose else null
        set(value) {
            metadata = value
            type = if (value == null) null else MetadataType.DOWNSTREAM_NORMAL_CLOSE
        }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        var self = other as? DownstreamMetadata ?: return false
        if (this.metadata != self.metadata) return false
        return true
    }
}

/**
 * アップストリームコールです。
 * @param destinationNodeId 宛先ノードID。
 * @param name 名称。
 * @param type 型。
 * @param payload ペイロード。
 */
class UpstreamCall(
    var destinationNodeId: String,
    var name: String = "",
    var type: String = "",
    var payload: ByteArray = ByteArray(0)
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        var self = other as? UpstreamCall ?: return false
        if (this.destinationNodeId != self.destinationNodeId) return false
        if (this.name != self.name) return false
        if (this.type != self.type) return false
        if (!this.payload.contentEquals(self.payload)) return false
        return true
    }
}

/**
 * アップストリームリプライコールです。
 * @param requestCallId リクエストコールID。
 * @param destinationNodeId 宛先ノードID。
 * @param name 名称。
 * @param type 型。
 * @param payload ペイロード。
 */
class UpstreamReplyCall(
    var requestCallId: String,
    var destinationNodeId: String,
    var name: String = "",
    var type: String = "",
    var payload: ByteArray = ByteArray(0)
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        var self = other as? UpstreamReplyCall ?: return false
        if (this.requestCallId != self.requestCallId) return false
        if (this.destinationNodeId != self.destinationNodeId) return false
        if (this.name != self.name) return false
        if (this.type != self.type) return false
        if (!this.payload.contentEquals(self.payload)) return false
        return true
    }
}

/**
 * ダウンストリームコールです。
 * @param callId コールID。
 * @param sourceNodeId 送信元ノードID。
 * @param name 名称。
 * @param type 型。
 * @param payload ペイロード。
 */
class DownstreamCall internal constructor(
    var callId: String,
    var sourceNodeId: String,
    var name: String,
    var type: String,
    var payload: ByteArray
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        var self = other as? DownstreamCall ?: return false
        if (this.callId != self.callId) return false
        if (this.sourceNodeId != self.sourceNodeId) return false
        if (this.name != self.name) return false
        if (this.type != self.type) return false
        if (!this.payload.contentEquals(self.payload)) return false
        return true
    }
}

/**
 * ダウンストリームリプライコールです。
 * @param requestCallId リクエストコールID。
 * @param sourceNodeId 送信元ノードID。
 * @param name 名称。
 * @param type 型。
 * @param payload ペイロード。
 */
class DownstreamReplyCall internal constructor(
    var requestCallId: String,
    var sourceNodeId: String,
    var name: String,
    var type: String,
    var payload: ByteArray
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        var self = other as? DownstreamReplyCall ?: return false
        if (this.requestCallId != self.requestCallId) return false
        if (this.sourceNodeId != self.sourceNodeId) return false
        if (this.name != self.name) return false
        if (this.type != self.type) return false
        if (!this.payload.contentEquals(self.payload)) return false
        return true
    }
}