package com.aptpod.iscp.connection

import com.aptpod.iscp.helpers.AliasGenerator
import com.aptpod.iscp.model.IscpException
import com.aptpod.iscp.model.DataId
import com.aptpod.iscp.stream.Downstream
import com.aptpod.iscp.model.DownstreamFilter
import com.aptpod.iscp.model.QoS
import com.aptpod.iscp.logger.IscpLog
import com.aptpod.iscp.message.DownstreamCloseResponse
import com.aptpod.iscp.message.DownstreamOpenResponse
import com.aptpod.iscp.message.DownstreamResumeResponse
import com.aptpod.iscp.message.ResultCode
import com.aptpod.iscp.extensions.toMaskString
import com.aptpod.iscp.transport.Receiver

/**
 * ダウンストリームを開きます。
 */
internal fun Connection.invokeOpenDownstreamAsync(
    downstreamFilters: List<DownstreamFilter>,
    dataIds: List<DataId>?,
    qos: QoS,
    omitEmptyChunk: Boolean,
    expiryInterval: Short,
    ackInterval: Long,
    openTimeout: Long,
    closeTimeout: Long,
    completion: (((Downstream?, Exception?) -> Unit)?)
) {
    if (!this.isConnecting) {
        completion?.invoke(null, IscpException.TransportClosed)
        return
    }
    // エイリアスの生成
    var alias = this.downstreamIdGenerator.getAndAdd()

    // dataIdAlias
    var nonNullDataIds = dataIds ?: listOf()
    var dataIdAliasMap = mutableMapOf<UInt, DataId>()
    var dataIdAliasGenerator = AliasGenerator(1u)
    for (d in nonNullDataIds) {
        var a = dataIdAliasGenerator.getAndAdd()
        dataIdAliasMap[a] = d
    }

    var requestId = this.requestIdGenerator.generate()
    var receiver = Receiver("(requestId: $requestId)", openTimeout)
    receiver.subscribe<DownstreamOpenResponse> { msg, exception ->
        if (msg == null || exception != null) {
            IscpLog.e("failed to receive requestId($requestId) downstreamOpenResponse. ${exception?.javaClass?.name ?: ""}, requestId: ${msg?.requestId?.toString() ?: "null"}, resultCode: ${msg?.resultCode?.code?.toString() ?: "null"}, resultString: ${msg?.resultString ?: "null"}, resumeToken: ${msg?.resumeToken?.toMaskString() ?: "null"} - Connection")
            // Receiverを解除
            this.receivers.unregister(receiver)
            completion?.invoke(null, exception ?: IscpException.Unexpected("downstreamOpenResponse not found."))
            return@subscribe
        }
        if (msg.requestId != requestId) { return@subscribe }
        // Receiverを解除
        this.receivers.unregister(receiver)
        IscpLog.d("didReceived downstreamOpenResponse(requestId: ${msg.requestId}, resultCode: ${msg.resultCode.code}, resultString: ${msg.resultString}, resumeToken: ${if (msg.resumeToken.isNotEmpty()) msg.resumeToken.toMaskString() else "null"}) - Connection")
        if (msg.resultCode != ResultCode.SUCCEEDED)
        {
            completion?.invoke(null, IscpException.FailedMessage(msg.resultCode.code, msg.resultString))
            return@subscribe
        }

        // ダウンストリームのオープンに成功
        var downstream = Downstream(
            downstreamFilters = downstreamFilters,
            expiryInterval = expiryInterval,
            qos = qos,
            omitEmptyChunk = omitEmptyChunk,
            ackInterval = ackInterval,
            openTimeout = openTimeout,
            closeTimeout = closeTimeout,
            connection = this,
            alias = alias,
            dataIdAliasMap = dataIdAliasMap,
            dataIdAliasGenerator = dataIdAliasGenerator,
            openResponse = msg
        )
        this.registerDownstream(downstream)
        downstream.isOpen = true
        completion?.invoke(downstream, null)
    }
    // Receiverを登録
    this.receivers.register(receiver)

    // Send DownstreamOpenRequest
    var sendException = this.sendDownstreamOpenRequest(
        requestId = requestId,
        desiredStreamIdAlias = alias,
        downstreamFilters = downstreamFilters,
        expiryInterval = expiryInterval.toUShort(),
        dataIdAliases = dataIdAliasMap,
        qos = qos,
        omitEmptyChunk = omitEmptyChunk
    )
    if (sendException != null) {
        this.receivers.unregister(receiver)
        completion?.invoke(null, sendException)
        return
    }
}

/**
 * ストリーム設定を引き継いで別ストリームとして再度ダウンストリームを開きます。
 */
internal fun com.aptpod.iscp.connection.Connection.invokeReopenDownstreamAsync(downstream: Downstream, completion: ((Downstream?, Exception?) -> Unit)?) {
    IscpLog.d("reopenDownstream(downstream: ${downstream.id}) - Connection")
    if (!this.isConnecting) {
        completion?.invoke(null, IscpException.TransportClosed)
        return
    }
    // エイリアスの生成
    var alias = this.downstreamIdGenerator.getAndAdd()
    var requestId = this.requestIdGenerator.generate()
    var receiver = Receiver("(requestId: $requestId)", downstream.openTimeout)
    receiver.subscribe<DownstreamOpenResponse> { msg, exception ->
        if (msg == null || exception != null) {
            IscpLog.e("failed to receive request($requestId) downstreamOpenResponse. ${exception?.javaClass?.name ?: ""}, requestId: ${msg?.requestId?.toString() ?: "null"}, resultCode: ${msg?.resultCode?.code?.toString() ?: "null"}, resultString: ${msg?.resultString ?: "null"}, resumeToken: ${msg?.resumeToken?.toMaskString() ?: "null"} - Connection")
            // Receiverを解除
            this.receivers.unregister(receiver)
            completion?.invoke(null, exception ?: IscpException.Unexpected("downstreamOpenResponse not found."))
            return@subscribe
        }
        if (msg.requestId != requestId) { return@subscribe }
        // Receiverを解除
        this.receivers.unregister(receiver)
        IscpLog.d("didReceived downstreamOpenResponse(requestId: ${msg.requestId}, resultCode: ${msg.resultCode.code}, resultString: ${msg.resultString}, resumeToken: ${if (msg.resumeToken.isNotEmpty()) msg.resumeToken.toMaskString() else "null"}) - Connection")
        if (msg.resultCode != ResultCode.SUCCEEDED)
        {
            completion?.invoke(null, IscpException.FailedMessage(msg.resultCode.code, msg.resultString))
            return@subscribe
        }

        // ダウンストリームの再オープンに成功
        var reDownstream = Downstream(downstream, this, alias, msg)
        this.registerDownstream(reDownstream)
        reDownstream.isOpen = true
        completion?.invoke(reDownstream, null)
    }
    // Receiverを登録
    this.receivers.register(receiver)

    // Send DownstreamOpenRequest
    var sendException = this.sendDownstreamOpenRequestForReconnect(requestId, alias, downstream)
    if (sendException != null) {
        this.receivers.unregister(receiver)
        completion?.invoke(null, sendException)
        return
    }
}

internal fun com.aptpod.iscp.connection.Connection.resumeDownstreamAsync(downstream: Downstream, completion: ((Downstream, Exception?) -> Unit)?) {
    IscpLog.d("resumeDownstream(downstream: ${downstream.id}, resumeToken: ${downstream.resumeToken.toMaskString()}) - Connection")
    if (!this.isConnecting) {
        completion?.invoke(downstream, IscpException.TransportClosed)
        return
    }
    var requestId = this.requestIdGenerator.generate()
    var receiver = Receiver("(requestId: $requestId)", downstream.openTimeout)
    receiver.subscribe<DownstreamResumeResponse> { msg, exception ->
        if (msg == null || exception != null) {
            IscpLog.e("failed to receive requestId($requestId) downstreamResumeResponse. ${exception?.javaClass?.name ?: ""}, requestId: ${msg?.requestId?.toString() ?: "null"}, resultCode: ${msg?.resultCode?.code?.toString() ?: "null"}, resultString: ${msg?.resultString ?: "null"}, resumeToken: ${msg?.resumeToken?.toMaskString() ?: "null"} - Connection")
            // Receiverを解除
            this.receivers.unregister(receiver)
            completion?.invoke(downstream, exception ?: IscpException.Unexpected("downstreamResumeResponse not found."))
            return@subscribe
        }
        if (msg.requestId != requestId) { return@subscribe }
        // Receiverを解除
        this.receivers.unregister(receiver)
        IscpLog.d("didReceived downstreamResumeResponse(requestId: ${msg.requestId}, resultCode: ${msg.resultCode.code}, resultString: ${msg.resultString}, resumeToken: ${if (msg.resumeToken.isNotEmpty()) msg.resumeToken.toMaskString() else "null"}) - Connection")
        if (msg.resultCode != ResultCode.SUCCEEDED)
        {
            completion?.invoke(downstream, IscpException.FailedMessage(msg.resultCode.code, msg.resultString))
            return@subscribe
        }

        // ダウンストリームの再オープンに成功
        downstream.resumeToken = msg.resumeToken
        downstream.isOpen = true
        completion?.invoke(downstream, null)
    }
    // Receiverを登録
    this.receivers.register(receiver)

    // Send DownstreamResumeRequest
    var sendException = this.sendDownstreamResumeRequest(requestId, downstream)
    if (sendException != null) {
        this.receivers.unregister(receiver)
        completion?.invoke(downstream, sendException)
        return
    }
}

internal fun com.aptpod.iscp.connection.Connection.closeDownstream(downstream: Downstream, completion: ((Exception?) -> Unit)?) {
    try {
        if (!this.containsDownstream(downstream)) {
            completion?.invoke(IscpException.StreamClosed)
            return
        }
        if (!this.isConnecting) {
            completion?.invoke(IscpException.TransportClosed)
            return
        }
        var requestId = this.requestIdGenerator.generate()
        var receiver = Receiver("(requestId: $requestId)", downstream.closeTimeout)
        receiver.subscribe<DownstreamCloseResponse> { msg, exception ->
            if (msg == null || exception != null) {
                IscpLog.e("failed to receive requestId($requestId) downstreamCloseResponse. ${exception?.javaClass?.name ?: ""}, requestId: ${msg?.requestId?.toString() ?: "null"}, resultCode: ${msg?.resultCode?.code?.toString() ?: "null"}, resultString: ${msg?.resultString ?: "null"} - Connection")
                // Receiverを解除
                this.receivers.unregister(receiver)
                completion?.invoke(exception ?: IscpException.Unexpected("downstreamCloseResponse not found."))
                return@subscribe
            }
            if (msg.requestId != requestId) { return@subscribe }
            // Receiverを解除
            this.receivers.unregister(receiver)
            IscpLog.d("didReceived downstreamCloseResponse(requestId: ${msg.requestId}, resultCode: ${msg.resultCode.code}, resultString: ${msg.resultString}) - Connection")
            if (msg.resultCode != ResultCode.SUCCEEDED)
            {
                completion?.invoke(IscpException.FailedMessage(msg.resultCode.code, msg.resultString))
                return@subscribe
            }

            // ダウンストリームのクローズに成功
            downstream.isOpen = false
            completion?.invoke(null)
        }
        // Receiverを登録
        this.receivers.register(receiver)

        // Send DownstreamCloseRequest
        var sendException = this.sendDownstreamCloseRequest(requestId, downstream)
        if (sendException != null) {
            this.receivers.unregister(receiver)
            completion?.invoke(sendException)
            return
        }
    }
    finally {
        downstream.dispose()
        // ダウンストリームの登録を解除
        this.unregisterDownstream(downstream)
    }
}
