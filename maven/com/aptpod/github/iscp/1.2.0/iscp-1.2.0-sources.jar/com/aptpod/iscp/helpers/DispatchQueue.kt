package com.aptpod.iscp.helpers

import com.aptpod.iscp.logger.IscpLog
import java.util.Timer
import java.util.TimerTask
import java.util.concurrent.locks.ReentrantLock
import kotlin.concurrent.withLock

private typealias Action = ()->Unit

/**
 * タスクが順次的にまたは同時に行われるのを管理するオブジェクトです。
 */
class DispatchQueue {

    private object Holder {
        val Global = DispatchQueue("global")
    }
    companion object {
        val Global: DispatchQueue by lazy { Holder.Global }
    }

    val label: String

    private var thread: Thread? = null
    private var actions: MutableList<Action> = mutableListOf()
    private var threadLock: ReentrantLock = ReentrantLock()
    private val condition = threadLock.newCondition()

    private var disposed: Boolean = false

    constructor(label: String) {
        this.label = label
        startNewThread()
    }

    private fun startNewThread() {
        // Memo: 本来はスレッドを１つ作って同じ関数を再帰呼び出してループさせて利用したいがその場合だと
        // 処理を続けているとどこかのタイミングでエラーを出力する為、都度スレッドを作成する。
        // Potentially dangerous stack overflow in ReservedStackAccess annotated method com.aptpod.iscp.helpers.DispatchQueue.thread_OnCall
        this.thread = Thread {
            thread_OnCall()
        }
        this.thread!!.name = label
        this.thread?.start()
    }

    private fun thread_OnCall() {
        try {
            var action: Action? = null
            threadLock.withLock {
                if (actions.count() > 0)
                {
                    action = actions[0]
                    actions.removeAt(0)
                }
            }
            if (action != null) {
                action?.invoke()
            }
            else
            {
                threadLock.withLock {
                    condition.await()
                }
            }
        }
        catch (e: Exception) {
            IscpLog.e("DispatchQueue error. ${e.message} - DispatchQueue<$label>")
            disposed = true
        }
        finally {
            if (!disposed)
            {
                startNewThread()
            }
            else
            {
                IscpLog.d("thread finished. - DispatchQueue<$label>")
            }
        }
    }

    fun async(work: Action) {
        threadLock.withLock {
            actions.add(work)
            condition.signal()
        }
    }

    fun asyncAfter(millisecond: Long, work: Action) {
        var t = Timer()
        t.schedule(object : TimerTask() {
            override fun run() {
                this.cancel()
                async(work)
            }
        }, millisecond)
    }

    fun dispose() {
        threadLock.withLock {
            disposed = true
            condition.signal()
        }
    }
}