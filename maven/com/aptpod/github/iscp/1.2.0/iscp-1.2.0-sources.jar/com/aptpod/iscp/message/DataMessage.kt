package com.aptpod.iscp.message

import com.aptpod.iscp.helpers.UUIDUtils
import java.util.UUID

//region Message

/**
 * @param streamIdAlias ストリームIDエイリアス
 * @param dataIds データID
 * @param streamChunk ストリームチャンク
 * @param extensionFields 拡張フィールド
 */
internal class UpstreamChunk(
    var streamIdAlias: UInt = 0u,
    var dataIds: List<DataId> = listOf(),
    var streamChunk: StreamChunk = StreamChunk(),
    var extensionFields: ExtensionFields = ExtensionFields(),

) : IMessage {

    class ExtensionFields {

        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            var self = other as? ExtensionFields ?: return false
            return true
        }
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        var self = other as? UpstreamChunk ?: return false
        if (this.streamIdAlias != self.streamIdAlias) return false
        if (!this.dataIds.equals(self.dataIds)) return false
        if (!this.streamChunk.equals(self.streamChunk)) return false
        if (!this.extensionFields.equals(self.extensionFields)) return false
        return true
    }

}

/**
 * @param streamIdAlias ストリームIDエイリアス
 * @param results 処理結果
 * @param dataIdAliases データIDエイリアス
 * @param extensionFields 拡張フィールド
 */
internal class UpstreamChunkAck(
    var streamIdAlias: UInt = 0u,
    var results: List<UpstreamChunkResult> = listOf(),
    var dataIdAliases: Map<UInt, DataId> = mapOf(),
    var extensionFields: ExtensionFields = ExtensionFields()
) : IMessage {

    class ExtensionFields {

        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            var self = other as? ExtensionFields ?: return false
            return true
        }
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        var self = other as? UpstreamChunkAck ?: return false
        if (this.streamIdAlias != self.streamIdAlias) return false
        if (!this.results.equals(self.results)) return false
        if (!this.dataIdAliases.equals(self.dataIdAliases)) return false
        if (!this.extensionFields.equals(self.extensionFields)) return false
        return true
    }
}

/**
 * @param streamIdAlias ストリームIDエイリアス
 * @param upstreamOrAliasCase アップストリーム情報、またはアップストリームエイリアス
 * @param streamChunk ストリームチャンク
 * @param extensionFields 拡張フィールド
 */
internal class DownstreamChunk(
    var streamIdAlias: UInt = 0u,
    upstreamOrAliasCase: UpstreamOrAliasCase? = null,
    var streamChunk: StreamChunk = StreamChunk(),
    var extensionFields: ExtensionFields = ExtensionFields(),
    var downstreamFilterReferences: List<DownstreamFilterReferences> = listOf()
) : IMessage {

    /**
     * アップストリーム情報、またはアップストリームエイリアス
     */
    var upstreamOrAliasCase: UpstreamOrAliasCase? = upstreamOrAliasCase
        internal set

    enum class UpstreamOrAliasCase {
        UPSTREAM_INFO,
        UPSTREAM_ALIAS
    }
    internal var upstreamOrAlias: Any? = null

    var upstreamInfo: UpstreamInfo?
        get() = if (upstreamOrAliasCase == UpstreamOrAliasCase.UPSTREAM_INFO) upstreamOrAlias as? UpstreamInfo else null
        set(value) {
            upstreamOrAlias = value
            upstreamOrAliasCase = if(value == null) null else UpstreamOrAliasCase.UPSTREAM_INFO
        }

    var upstreamAlias: UInt?
        get() = if (upstreamOrAliasCase == UpstreamOrAliasCase.UPSTREAM_ALIAS) upstreamOrAlias as? UInt else null
        set(value) {
            upstreamOrAlias = value
            upstreamOrAliasCase = if(value == null) null else UpstreamOrAliasCase.UPSTREAM_ALIAS
        }

    class ExtensionFields {

        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            var self = other as? ExtensionFields ?: return false
            return true
        }
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        var self = other as? DownstreamChunk ?: return false
        if (this.streamIdAlias != self.streamIdAlias) return false
        if (this.upstreamOrAliasCase != self.upstreamOrAliasCase) return false
        if (this.upstreamOrAlias != self.upstreamOrAlias) return false
        if (!this.streamChunk.equals(self.streamChunk)) return false
        if (!this.extensionFields.equals(self.extensionFields)) return false
        if (!this.downstreamFilterReferences.equals(self.downstreamFilterReferences)) return false
        return true
    }
}

/**
 * @param streamIdAlias ストリームエイリアス
 * @param ackId ACK ID
 * @param results 処理結果
 * @param upstreamAliases アップストリームエイリアス
 * @param dataIdAliases データIDエイリアス
 * @param extensionFields 拡張フィールド
 */
internal class DownstreamChunkAck(
    var streamIdAlias: UInt = 0u,
    var ackId: UInt = 0u,
    var results: List<DownstreamChunkResult> = listOf(),
    var upstreamAliases: Map<UInt, UpstreamInfo> = mapOf(),
    var dataIdAliases: Map<UInt, DataId> = mapOf(),
    var extensionFields: ExtensionFields = ExtensionFields()
) : IMessage {

    class ExtensionFields {

        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            var self = other as? ExtensionFields ?: return false
            return true
        }
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        var self = other as? DownstreamChunkAck ?: return false
        if (this.streamIdAlias != self.streamIdAlias) return false
        if (this.ackId != self.ackId) return false
        if (!this.results.equals(self.results)) return false
        if (!this.upstreamAliases.equals(self.upstreamAliases)) return false
        if (this.dataIdAliases != self.dataIdAliases) return false
        if (!this.extensionFields.equals(self.extensionFields)) return false
        return true
    }
}

/**
 * @param streamIdAlias ストリームエイリアス
 * @param ackId ACK ID
 * @param resultCode 結果コード
 * @param resultString 結果文字列
 * @param extensionFields 拡張フィールド
 */
internal class DownstreamChunkAckComplete(
    var streamIdAlias: UInt = 0u,
    var ackId: UInt = 0u,
    var resultCode: ResultCode = ResultCode.SUCCEEDED,
    var resultString: String = "",
    var extensionFields: ExtensionFields = ExtensionFields()
) : IMessage {

    class ExtensionFields {

        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            var self = other as? ExtensionFields ?: return false
            return true
        }
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        var self = other as? DownstreamChunkAckComplete ?: return false
        if (this.streamIdAlias != self.streamIdAlias) return false
        if (this.ackId != self.ackId) return false
        if (this.resultCode != self.resultCode) return false
        if (this.resultString != self.resultString) return false
        if (!this.extensionFields.equals(self.extensionFields)) return false
        return true
    }
}

//endregion

//region Data

/**
 * @param elapsedTime 経過時間
 *
 * 単位はナノ秒
 * @param payload ペイロード
 */
internal class DataPoint(
    var elapsedTime: Long = 0,
    var payload: ByteArray = ByteArray(0)
) {

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        var self = other as? DataPoint ?: return false
        if (this.elapsedTime != self.elapsedTime) return false
        if (!this.payload.contentEquals(self.payload)) return false
        return true
    }

}

/**
 * @param sequenceNumber シーケンス番号
 * @param resultCode 結果コード
 * @param resultString 結果文字列
 * @param extensionFields 拡張フィールド
 */
internal class UpstreamChunkResult(
    var sequenceNumber: UInt = 0u,
    var resultCode: ResultCode = ResultCode.SUCCEEDED,
    var resultString: String = "",
    var extensionFields: ExtensionFields = ExtensionFields()
) {

    class ExtensionFields {

        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            var self = other as? ExtensionFields ?: return false
            return true
        }
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        var self = other as? UpstreamChunkResult ?: return false
        if (this.sequenceNumber != self.sequenceNumber) return false
        if (this.resultCode != self.resultCode) return false
        if (this.resultString != self.resultString) return false
        if (!this.extensionFields.equals(self.extensionFields)) return false
        return true
    }
}

/**
 * @param streamIdOfUpstream アップストリームのストリームID
 * @param sequenceNumberInUpstream アップストリームにおけるシーケンス番号
 * @param resultCode 結果コード
 * @param resultString 結果文字列
 * @param extensionFields 拡張フィールド
 */
internal class DownstreamChunkResult(
    var streamIdOfUpstream: UUID = UUIDUtils.empty(),
    var sequenceNumberInUpstream: UInt = 0u,
    var resultCode: ResultCode = ResultCode.SUCCEEDED,
    var resultString: String = "",
    var extensionFields: ExtensionFields = ExtensionFields()
) {

    class ExtensionFields {

        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            var self = other as? ExtensionFields ?: return false
            return true
        }
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        var self = other as? DownstreamChunkResult ?: return false
        if (this.streamIdOfUpstream != self.streamIdOfUpstream) return false
        if (this.sequenceNumberInUpstream != self.sequenceNumberInUpstream) return false
        if (this.resultCode != self.resultCode) return false
        if (this.resultString != self.resultString) return false
        if (!this.extensionFields.equals(self.extensionFields)) return false
        return true
    }
}

/**
 * @param sessionId セッションID
 * @param streamId ストリームID
 * @param sourceNodeId 生成元ノードID
 */
internal class UpstreamInfo(
    var sessionId: String = "",
    var streamId: UUID = UUIDUtils.empty(),
    var sourceNodeId: String = ""
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        var self = other as? UpstreamInfo ?: return false
        if (this.sessionId != self.sessionId) return false
        if (this.streamId != self.streamId) return false
        if (this.sourceNodeId != self.sourceNodeId) return false
        return true
    }
}

/**
 * @param sequenceNumber シーケンス番号
 * @param dataPointGroups データポイントグループのリスト
 */
internal class StreamChunk(
    var sequenceNumber: UInt = 0u,
    var dataPointGroups: List<DataPointGroup> = listOf(),

) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        var self = other as? StreamChunk ?: return false
        if (this.sequenceNumber != self.sequenceNumber) return false
        if (!this.dataPointGroups.equals(self.dataPointGroups)) return false
        return true
    }
}

/**
 * @param dataPoints データポイント
 * @param dataIdOrAliasCase データIDまたはエイリアス
 */
internal class DataPointGroup(
    var dataPoints: MutableList<DataPoint> = mutableListOf(),
    dataIdOrAliasCase: DataIdOrAliasCase? = null,
) {
    /**
     * データIDまたはエイリアス
     */
    var dataIdOrAliasCase: DataIdOrAliasCase? = dataIdOrAliasCase
        internal set

    internal var dataIdOrAlias: Any? = null

    enum class DataIdOrAliasCase {
        DATA_ID,
        DATA_ID_ALIAS
    }

    var dataId: DataId?
        get() = if (dataIdOrAliasCase == DataIdOrAliasCase.DATA_ID) dataIdOrAlias as? DataId else null
        set(value) {
            dataIdOrAlias = value
            dataIdOrAliasCase = if(value == null) null else DataIdOrAliasCase.DATA_ID
        }

    var dataIdAlias: UInt?
        get() = if (dataIdOrAliasCase == DataIdOrAliasCase.DATA_ID_ALIAS) dataIdOrAlias as? UInt else null
        set(value) {
            dataIdOrAlias = value
            dataIdOrAliasCase = if(value == null) null else DataIdOrAliasCase.DATA_ID_ALIAS
        }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        var self = other as? DataPointGroup ?: return false
        if (!this.dataPoints.equals(self.dataPoints)) return false
        if (this.dataIdOrAliasCase != self.dataIdOrAliasCase) return false
        if (this.dataIdOrAlias != self.dataIdOrAlias) return false
        return true
    }
}

//endregion