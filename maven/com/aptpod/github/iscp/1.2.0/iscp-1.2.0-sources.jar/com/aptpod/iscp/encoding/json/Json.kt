package com.aptpod.iscp.encoding.json

import com.aptpod.iscp.encoding.autogen.iscp2.v1.Message as ProtoMessage
import com.google.protobuf.util.JsonFormat
import com.aptpod.iscp.encoding.EncodingName
import com.aptpod.iscp.encoding.IMessageConverter
import com.aptpod.iscp.encoding.convert.protoToWire
import com.aptpod.iscp.encoding.convert.wireToProto
import com.aptpod.iscp.logger.IscpLog
import com.aptpod.iscp.message.IMessage

internal class Json : IMessageConverter {

    override val name: EncodingName
        get() = EncodingName.JSON

    override fun encodeTo(message: IMessage) : Pair<ByteArray?, Exception?> {
        try {
            var (pb, err) = wireToProto(message)
            if (err != null) {
                return Pair(null, err)
            }
            var json = JsonFormat.printer().preservingProtoFieldNames().print(pb)
            IscpLog.d("encodeToJson: $json")
            return Pair(json.toByteArray(Charsets.UTF_8), null)
        }
        catch (e: Exception) {
            return Pair(null, e)
        }
    }

    override fun decodeFrom(serializedData: ByteArray): Pair<IMessage?, Exception?> {
        try {
            var json = String(serializedData, Charsets.UTF_8)
            IscpLog.d("decodeFromJson: $json")
            var builder = ProtoMessage.newBuilder()
            JsonFormat.parser().merge(json, builder)
            var pb = builder.build()
            return protoToWire(pb)
        }
        catch (e: Exception) {
            return Pair(null, e)
        }
    }
}