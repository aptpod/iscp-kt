package com.aptpod.iscp.encoding

import com.aptpod.iscp.message.IMessage

internal interface IMessageConverter {
    fun encodeTo(message: IMessage) : Pair<ByteArray?, Exception?>

    fun decodeFrom(serializedData: ByteArray): Pair<IMessage?, Exception?>

    val name: EncodingName
}

/**
 * エンコーディングの名前です。
 */
enum class EncodingName(val value: String) {
    /**
     * JSON。
     */
    JSON("json"),
    /**
     * ProtocolBuffer。
     */
    PROTOBUF("proto")
}