package com.aptpod.iscp.message

/**
 * @param requestId 結果コード
 * @param extensionFields 拡張フィールド
 */
internal class Ping(
    var requestId: UInt = 0u,
    var extensionFields: ExtensionFields = ExtensionFields()
) : IMessage {

    class ExtensionFields {

        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            var self = other as? ExtensionFields ?: return false
            return true
        }
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        var self = other as? Ping ?: return false
        if (this.requestId != self.requestId) return false
        if (!this.extensionFields.equals(self.extensionFields)) return false
        return true
    }
}

/**
 * @param requestId 結果コード
 * @param extensionFields 拡張フィールド
 */
internal class Pong(
    var requestId: UInt = 0u,
    var extensionFields: Ping.ExtensionFields = Ping.ExtensionFields()
) : IMessage {

    class ExtensionFields {

        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            var self = other as? ExtensionFields ?: return false
            return true
        }
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        var self = other as? Pong ?: return false
        if (this.requestId != self.requestId) return false
        if (!this.extensionFields.equals(self.extensionFields)) return false
        return true
    }
}