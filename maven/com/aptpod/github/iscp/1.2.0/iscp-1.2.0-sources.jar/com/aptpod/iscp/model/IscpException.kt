package com.aptpod.iscp.model

/**
 * iSCPクライアント内部で発生するエラーの定義です。
 */
abstract class IscpException(override val message: String?) : Exception(message) {

    companion object {
        @JvmStatic
        var TransportClosed = TransportClosedException()
        @JvmField
        var StreamClosed = StreamClosedException()
        @JvmStatic
        fun MalformedMessage(errorMessage: String = "unsupported message.") = MalformedMessageException(errorMessage)
        @JvmStatic
        fun FailedMessage(resultCode: UInt, resultString: String) = FailedMessageException(resultCode, resultString)
        @JvmField
        var Timeout = TimeoutException()
        @JvmStatic
        fun Unexpected(errorMessage: String = "unsupported message.") = UnexpectedException(errorMessage)
    }
}

/**
 * トランスポートが閉じられている際にトランスポートに対して読み書きをしようとした際に出力されます。
 */
class TransportClosedException : IscpException("closed iscp transport.") {

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        var self = other as? TransportClosedException ?: return false
        if (message != self.message) return false
        return true
    }
}

/**
 * ストリームが既にクローズされている際に何らかの処理を実行しようとした際に出力されます。
 */
class StreamClosedException : IscpException("closed iscp stream.") {

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        var self = other as? StreamClosedException ?: return false
        if (message != self.message) return false
        return true
    }
}

/**
 * メッセージのエンコードやデコードに失敗した際に出力されます。
 */
class MalformedMessageException(val errorMessage: String = "unsupported message.") : IscpException("malformed message.  $errorMessage") {

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        var self = other as? MalformedMessageException ?: return false
        if (errorMessage != self.errorMessage) return false
        if (message != self.message) return false
        return true
    }
}

/**
 * iSCPでの通信中に、失敗を意味する結果コードが含まれたメッセージを受信した場合に出力されます。
 */
class FailedMessageException(val resultCode: UInt, val resultString: String) : IscpException("failed message. resultCode: $resultCode, resultString: $resultString") {

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        var self = other as? FailedMessageException ?: return false
        if (resultCode != self.resultCode) return false
        if (resultString != self.resultString) return false
        if (message != self.message) return false
        return true
    }

}

/**
 * iSCP通信中に結果コードが返却されずタイムアウトした際に出力されます。
 */
class TimeoutException : IscpException("process timeout") {

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        var self = other as? TimeoutException ?: return false
        if (message != self.message) return false
        return true
    }

}

/**
 * 定義されていないエラーが発生した際に出力されます。
 */
class UnexpectedException(val errorMessage: String = "unsupported message.") : IscpException("unexpected error. $errorMessage") {

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        var self = other as? UnexpectedException ?: return false
        if (errorMessage != self.errorMessage) return false
        if (message != self.message) return false
        return true
    }

}

