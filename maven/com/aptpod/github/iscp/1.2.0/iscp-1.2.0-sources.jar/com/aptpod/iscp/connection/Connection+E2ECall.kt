package com.aptpod.iscp.connection

import com.aptpod.iscp.model.IscpException
import com.aptpod.iscp.model.DownstreamReplyCall
import com.aptpod.iscp.model.UpstreamCall
import com.aptpod.iscp.model.UpstreamReplyCall
import com.aptpod.iscp.stream.toDownstreamCallStream
import com.aptpod.iscp.stream.toDownstreamReplyCallStream
import com.aptpod.iscp.logger.IscpLog
import com.aptpod.iscp.message.DownstreamCall
import com.aptpod.iscp.message.ResultCode
import com.aptpod.iscp.message.UpstreamCallAck
import com.aptpod.iscp.transport.Receiver
import java.util.UUID

internal fun Connection.setupDownstreamCallReceiver() {
    this.downstreamCallReceiver?.let { r ->
        this.receivers.unregister(r)
    }
    var receiver = Receiver(0)
    this.downstreamCallReceiver = receiver
    receiver.subscribe<DownstreamCall> { msg, exception ->
        // Receiverは解除しない
        if (msg == null || exception != null) {
            IscpLog.e("failed to receive downstreamCall. ${exception?.javaClass?.name ?: ""}, callId: ${msg?.callId ?: "null"}, requestCallId: ${msg?.requestCallId ?: "null"}, sourceNodeId: ${msg?.sourceNodeId ?: "null"} - Connection")
            return@subscribe
        }
        IscpLog.d("didReceived downstreamCall(callId: ${msg.callId}, requestCallId: ${msg.requestCallId}, sourceNodeId: ${msg.sourceNodeId}) - Connection")
        if (msg.requestCallId.isNullOrEmpty()) {
            var downstreamCall = toDownstreamCallStream(msg)
            this.e2ECallCallbacks?.onReceiveCall(this, downstreamCall)
        }
        else {
            var downstreamReplyCall = toDownstreamReplyCallStream(msg)
            this.e2ECallCallbacks?.onReceiveReplyCall(this, downstreamReplyCall)
        }
    }
    // Receiverを登録
    this.receivers.register(receiver)
}

/**
 * E2Eコールを送信します。
 */
internal fun Connection.invokeSendCallAsync(upstreamCall: UpstreamCall, sendTimeout: Long, completion: ((Exception?) -> Unit)?) : String? {
    if (!this.isConnecting) {
        completion?.invoke(IscpException.TransportClosed)
        return null
    }
    var callId = this.randomString
    var receiver = Receiver("(callId: $callId)", sendTimeout)
    receiver.subscribe<UpstreamCallAck> { msg, exception ->
        if (msg == null || exception != null) {
            IscpLog.e("failed to receive callId($callId) upstreamCallAck. ${exception?.javaClass?.name ?: ""}, callId: ${msg?.callId ?: "null"}, resultCode: ${msg?.resultCode?.code?.toString() ?: "null"}, resultString: ${msg?.resultString ?: "null"} - Connection")
            // Receiverを解除
            this.receivers.unregister(receiver)
            completion?.invoke(exception ?: IscpException.Unexpected("upstreamCallAck not found."))
            return@subscribe
        }
        if (msg.callId != callId) { return@subscribe }
        // Receiverを解除
        this.receivers.unregister(receiver)
        IscpLog.d("didReceived upstreamCallAck(callId: ${msg.callId}, resultCode: ${msg.resultCode.code}, resultString: ${msg.resultString}) - Connection")
        if (msg.resultCode != ResultCode.SUCCEEDED)
        {
            completion?.invoke(IscpException.FailedMessage(msg.resultCode.code, msg.resultString))
            return@subscribe
        }

        // UpstreamCallの送信に成功
        completion?.invoke(null)
    }
    // Receiverを登録
    this.receivers.register(receiver)

    // Send UpstreamCall
    this.sendUpstreamCall(
        upstreamCall = upstreamCall,
        callId = callId
    )?.let { sendException ->
        this.receivers.unregister(receiver)
        completion?.invoke(sendException)
        return null
    }

    return callId
}

/**
 * E2Eコールのリプライを送信します。
 */
internal fun Connection.invokeSendReplyCallAsync(upstreamReplyCall: UpstreamReplyCall, sendTimeout: Long, completion: ((Exception?) -> Unit)?) : String? {
    if (!this.isConnecting) {
        completion?.invoke(IscpException.TransportClosed)
        return null
    }
    var callId = this.randomString
    var receiver = Receiver("(callId: $callId)", sendTimeout)
    receiver.subscribe<UpstreamCallAck> { msg, exception ->
        if (msg == null || exception != null) {
            IscpLog.e("failed to receive callId($callId) upstreamReplyCallAck. ${exception?.javaClass?.name ?: ""}, callId: ${msg?.callId ?: "null"}, resultCode: ${msg?.resultCode?.code?.toString() ?: "null"}, resultString: ${msg?.resultString ?: "null"} - Connection")
            // Receiverを解除
            this.receivers.unregister(receiver)
            completion?.invoke(exception ?: IscpException.Unexpected("upstreamReplyCallAck not found."))
            return@subscribe
        }
        if (msg.callId != callId) { return@subscribe }
        // Receiverを解除
        this.receivers.unregister(receiver)
        IscpLog.d("didReceived upstreamReplyCallAck(callId: ${msg.callId}, resultCode: ${msg.resultCode.code}, resultString: ${msg.resultString}) - Connection")
        if (msg.resultCode != ResultCode.SUCCEEDED)
        {
            completion?.invoke(IscpException.FailedMessage(msg.resultCode.code, msg.resultString))
            return@subscribe
        }

        // UpstreamCallの送信に成功
        completion?.invoke(null)
    }
    // Receiverを登録
    this.receivers.register(receiver)

    // Send UpstreamCall
    this.sendUpstreamCall(
        upstreamReplyCall = upstreamReplyCall,
        callId = callId
    )?.let { sendException ->
        this.receivers.unregister(receiver)
        completion?.invoke(sendException)
        return null
    }

    return callId
}

/**
 * E2Eコールを送信し、リプライコールを受信します。
 */
internal fun Connection.invokeSendCallAndWaitReplyCallAsync(upstreamCall: UpstreamCall, sendTimeout: Long, waitTimeout: Long, completion: ((DownstreamReplyCall?, Exception?) -> Unit)?) : String? {
    if (!this.isConnecting) {
        completion?.invoke(null, IscpException.TransportClosed)
        return null
    }
    var callId = this.randomString
    var receiver = Receiver("(callId: $callId)", sendTimeout)
    receiver.subscribe<UpstreamCallAck> { msg, exception ->
        if (msg == null || exception != null) {
            IscpLog.e("failed to receive callId($callId) upstreamCallAck. ${exception?.javaClass?.name ?: ""}, callId: ${msg?.callId ?: "null"}, resultCode: ${msg?.resultCode?.code?.toString() ?: "null"}, resultString: ${msg?.resultString ?: "null"} - Connection")
            // Receiverを解除
            this.receivers.unregister(receiver)
            completion?.invoke(null, exception ?: IscpException.Unexpected("upstreamCallAck not found."))
            return@subscribe
        }
        if (msg.callId != callId) { return@subscribe }
        // Receiverを解除
        this.receivers.unregister(receiver)
        IscpLog.d("didReceived upstreamCallAck(callId: ${msg.callId}, resultCode: ${msg.resultCode.code}, resultString: ${msg.resultString}) - Connection")
        if (msg.resultCode != ResultCode.SUCCEEDED)
        {
            completion?.invoke(null, IscpException.FailedMessage(msg.resultCode.code, msg.resultString))
            return@subscribe
        }

        // UpstreamCallの送信に成功。DownstreamCallの受信を待つ。
        var receiver2 = Receiver("(callId: $callId)", waitTimeout)
        receiver2.subscribe<DownstreamCall> { msg2, exception ->
            if (msg2 == null || exception != null) {
                IscpLog.e("failed to receive callId($callId) downstreamCall. ${exception?.javaClass?.name ?: ""}, ${msg2?.callId ?: "null"}, requestCallId: ${msg2?.requestCallId ?: "null"}, sourceNodeId: ${msg2?.sourceNodeId ?: "null"} - Connection")
                // Receiverを解除
                this.receivers.unregister(receiver2)
                completion?.invoke(null, exception ?: IscpException.Unexpected("downstreamCall not found."))
                return@subscribe
            }
            if (msg2.requestCallId != callId) { return@subscribe }
            // Receiverを解除
            this.receivers.unregister(receiver2)
            IscpLog.d("didReceived downstreamReplyCall(callId: ${msg2.callId}, requestCallId: ${msg2.requestCallId}, sourceNodeId: ${msg2.sourceNodeId}) - Connection")
            // DownstreamReplyCallを受信した。
            var downstreamReplyCall = toDownstreamReplyCallStream(msg2)
            completion?.invoke(downstreamReplyCall, null)
        }
        // Receiverを登録
        this.receivers.register(receiver2)
    }
    // Receiverを登録
    this.receivers.register(receiver)

    // Send UpstreamCall
    this.sendUpstreamCall(
        upstreamCall = upstreamCall,
        callId = callId
    )?.let { sendException ->
        this.receivers.unregister(receiver)
        completion?.invoke(null, sendException)
        return null
    }

    return callId
}

internal val Connection.randomString: String
    get() {
        return UUID.randomUUID().toString().lowercase()
    }