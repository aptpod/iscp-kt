package com.aptpod.iscp.transport.websocket

import com.aptpod.iscp.model.IscpException
import com.aptpod.iscp.logger.IscpLog
import com.aptpod.iscp.transport.IConnector
import com.aptpod.iscp.transport.ITransport
import com.aptpod.iscp.transport.NegotiationParams
import com.aptpod.iscp.transport.TransportCallbacks
import org.java_websocket.drafts.Draft
import org.java_websocket.drafts.Draft_6455
import org.java_websocket.handshake.ServerHandshake
import java.net.URI
import java.nio.ByteBuffer

@Deprecated(
    message = "WebSocketConfig has been renamed to WebSocketConnector.",
    replaceWith = ReplaceWith("WebSocketConnector"),
    level = DeprecationLevel.WARNING
)
class WebSocketConfig : WebSocketConnector() {}

/**
 * WebSocketの設定です。
 */
open class WebSocketConnector : IConnector {

    companion object {
        /**
         * デフォルトのパス。
         */
        const val DEFAULT_PATH: String = "/api/iscp/connect"
    }

    /**
     * パス。
     *
     * デフォルトは `/api/iscp/connect` です。
     */
    var path: String
    /**
     * ポート。
     *
     * `null` が設定されている場合デフォルトのポートが利用されます。
     */
    var port: Int?
    /**
     * TLSが有効かどうか。
     */
    var enableTls: Boolean

    /**
     * @param path パス。デフォルトは `/api/iscp/connect` です。
     * @param port ポート。`null` が設定されている場合デフォルトのポートが利用されます。
     * @param enableTls TLSが有効かどうか。
     */
    constructor(path: String = DEFAULT_PATH, port: Int? = null, enableTls: Boolean = false) {
        this.path = path
        this.port = port
        this.enableTls = enableTls
    }

    override fun connect(address: String, negotiationParams: NegotiationParams, completion: (transport: ITransport?, exception: Exception?) -> Unit) {
        val transport = WebSocketTransport(this)
        transport.connect(address = address, negotiationParams = negotiationParams, completion = { exception ->
            if (exception != null) {
                completion(null, exception)
                return@connect
            }
            completion(transport, null)
        })
    }
}

internal class WebSocketTransport : ITransport {

    companion object {
        private const val WS: String = "ws://"
        private const val WSS: String = "wss://"

        internal fun getWebSocketEndpoint(address: String, path: String, enableTls: Boolean) : String? {
            if (address.isNullOrEmpty()) {
                return null
            }
            val url: String = (if (enableTls) WSS else WS) + address
            return url + path
        }
    }

    override val name: String get() = "WebSocket"
    override var address: String? = ""
    override var negotiationParams: NegotiationParams? = null
    override var callbacks: TransportCallbacks? = null

    private val connector: WebSocketConnector
    private val path: String get() = connector.path
    private val port: Int? get() = connector.port
    private val enableTls: Boolean get() = connector.enableTls

    private var webSocket: MyWebSocket? = null
    override val isConnecting: Boolean get() = webSocket != null

    internal var connectRequestCompletion: ((Exception?) -> Unit)? = null
    internal var disconnectRequestCompletion: ((Exception?) -> Unit)? = null
    private var closingWebSocket: MyWebSocket? = null

    internal constructor(config: WebSocketConnector) {
        this.connector = config
    }

    /**
     * サーバーへ接続する際にコールされるメソッドです。
     * @param address 接続先のアドレス。 `127.0.0.1:8080` 形式。
     * @param negotiationParams ネゴシエーションパラメータ。
     * @param completion 処理完了時のコールバック。
     */
    fun connect(address: String, negotiationParams: NegotiationParams, completion: (exception: Exception?) -> Unit) {
        var endpoint: String = getWebSocketEndpoint(address, this.path, this.enableTls) as? String ?: run {
            completion(IscpException.Unexpected("invalid address."))
            return
        }
        if (!endpoint.contains("?")) {
            endpoint += "?"
        } else {
            endpoint += "&"
        }
        endpoint += negotiationParams.toQueryString()
        var parser = URI.create(endpoint)
        var port = parser.port
        if (this.port != null) {
            port = this.port!!
        }
        var uri = URI(parser.scheme, parser.userInfo, parser.host, port, parser.path, parser.query, parser.fragment)
        IscpLog.d("connect with WebSocket.")
        var webSocket = MyWebSocket(this, uri)
        webSocket.isTcpNoDelay = true

        this.address = address
        this.negotiationParams = negotiationParams
        this.connectRequestCompletion = completion
        this.webSocket = webSocket
        IscpLog.i("connect(uri: $uri) - WebSocket")
        webSocket.connect()
    }

    override fun close(completion: ((exception: Exception?) -> Unit)?) {
        var ws = webSocket ?: run {
            completion?.invoke(IscpException.TransportClosed)
            return
        }
        this.webSocket = null
        this.closingWebSocket = ws
        this.disconnectRequestCompletion = completion
        ws.close()
    }

    override fun write(data: ByteArray): Exception? {
        val ws = webSocket ?: return IscpException.TransportClosed
        ws.send(data)
        return null
    }

    //region WebSocketClient

    private class MyWebSocket(val ws: WebSocketTransport, uri: URI, httpHeaders: Map<String, String> = mapOf(), draft: Draft = Draft_6455()) : org.java_websocket.client.WebSocketClient(uri, draft, httpHeaders) {
        override fun onOpen(handshakedata: ServerHandshake?) {
            IscpLog.i("webSocket opened.")
            ws.callbacks?.onConnect(ws)
            ws.connectRequestCompletion?.invoke(null)
            ws.connectRequestCompletion = null
        }

        override fun onMessage(message: String?) {
            var message = message ?: return
            IscpLog.d("webSocket messageText: ${message.length} characters.")
        }

        override fun onMessage(bytes: ByteBuffer?) {
            var data = bytes?.array() ?: return
            IscpLog.d("webSocket messageData: ${data.size} bytes.")
            ws.callbacks?.onReceiveMessage(ws, data)
        }

        override fun onClose(code: Int, reason: String?, remote: Boolean) {
            IscpLog.i("webSocket closed.")
            ws.callbacks?.onDisconnect(ws)
            ws.disconnectRequestCompletion?.invoke(null)
            ws.disconnectRequestCompletion = null
        }

        override fun onError(ex: java.lang.Exception?) {
            IscpLog.e("webSocket error. " + ex?.message ?: "")
            var error = IscpException.Unexpected("webSocket error. " + ex?.message ?: "")
            ws.callbacks?.onFailWithError(ws, error)
            ws.connectRequestCompletion?.invoke(error)
            ws.connectRequestCompletion = null
            ws.disconnectRequestCompletion?.invoke(error)
            ws.disconnectRequestCompletion = null
        }
    }

    //endregion
}