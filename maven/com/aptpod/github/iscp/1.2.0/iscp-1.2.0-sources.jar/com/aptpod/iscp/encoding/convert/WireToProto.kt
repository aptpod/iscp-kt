package com.aptpod.iscp.encoding.convert

import com.aptpod.iscp.encoding.autogen.iscp2.v1.Message as ProtoMessage
import com.aptpod.iscp.encoding.autogen.iscp2.v1.ResultCode as ProtoResultCode
import com.aptpod.iscp.encoding.autogen.iscp2.v1.DataID
import com.aptpod.iscp.encoding.autogen.iscp2.v1.QoS as ProtoQoS
import com.aptpod.iscp.encoding.autogen.iscp2.v1.DownstreamFilter as ProtoDownstreamFilter
import com.aptpod.iscp.encoding.autogen.iscp2.v1.DataFilter as ProtoDataFilter
import com.aptpod.iscp.encoding.autogen.iscp2.v1.StreamChunk as ProtoStreamChunk
import com.aptpod.iscp.encoding.autogen.iscp2.v1.DataPointGroup as ProtoDataPointGroup
import com.aptpod.iscp.encoding.autogen.iscp2.v1.DataPoint as ProtoDataPoint
import com.aptpod.iscp.encoding.autogen.iscp2.v1.ConnectRequest as ProtoConnectRequest
import com.aptpod.iscp.encoding.autogen.iscp2.v1.Disconnect as ProtoDisconnect
import com.aptpod.iscp.encoding.autogen.iscp2.v1.Ping as ProtoPing
import com.aptpod.iscp.encoding.autogen.iscp2.v1.Pong as ProtoPong
import com.aptpod.iscp.encoding.autogen.iscp2.v1.DownstreamOpenRequest as ProtoDownstreamOpenRequest
import com.aptpod.iscp.encoding.autogen.iscp2.v1.DownstreamResumeRequest as ProtoDownstreamResumeRequest
import com.aptpod.iscp.encoding.autogen.iscp2.v1.DownstreamCloseRequest as ProtoDownstreamCloseRequest
import com.aptpod.iscp.encoding.autogen.iscp2.v1.DownstreamMetadataAck as ProtoDownstreamMetadataAck
import com.aptpod.iscp.encoding.autogen.iscp2.v1.DownstreamChunkAck as ProtoDownstreamChunkAck
import com.aptpod.iscp.encoding.autogen.iscp2.v1.DownstreamChunkResult as ProtoDownstreamChunkResult
import com.aptpod.iscp.encoding.autogen.iscp2.v1.UpstreamInfo as ProtoUpstreamInfo
import com.aptpod.iscp.encoding.autogen.iscp2.v1.UpstreamOpenRequest as ProtoUpstreamOpenRequest
import com.aptpod.iscp.encoding.autogen.iscp2.v1.UpstreamResumeRequest as ProtoUpstreamResumeRequest
import com.aptpod.iscp.encoding.autogen.iscp2.v1.UpstreamCloseRequest as ProtoUpstreamCloseRequest
import com.aptpod.iscp.encoding.autogen.iscp2.v1.UpstreamMetadata as ProtoUpstreamMetadata
import com.aptpod.iscp.encoding.autogen.iscp2.v1.UpstreamChunk as ProtoUpstreamChunk
import com.aptpod.iscp.encoding.autogen.iscp2.v1.UpstreamCall as ProtoUpstreamCall
import com.aptpod.iscp.encoding.autogen.iscp2.v1.BaseTime as ProtoBaseTime
import com.aptpod.iscp.encoding.autogen.iscp2.v1.extensions.UpstreamCloseRequestExtensionFields
import com.aptpod.iscp.encoding.autogen.iscp2.v1.extensions.UpstreamMetadataExtensionFields
import com.aptpod.iscp.encoding.autogen.iscp2.v1.extensions.UpstreamOpenRequestExtensionFields
import com.google.protobuf.ByteString
import com.aptpod.iscp.model.IscpException
import com.aptpod.iscp.helpers.toByteString
import com.aptpod.iscp.logger.IscpLog
import com.aptpod.iscp.message.*

internal fun wireToProto(inMsg: IMessage) : Pair<ProtoMessage?, Exception?> {
    var inDat = inMsg
    when (inDat) {
        is ConnectRequest -> {
            var outDat = ProtoConnectRequest.newBuilder()
            outDat.requestId = inDat.requestId.toInt()
            outDat.protocolVersion = inDat.protocolVersion
            outDat.nodeId = inDat.nodeId
            outDat.pingInterval = inDat.pingInterval.toInt()
            outDat.pingTimeout = inDat.pingTimeout.toInt()
            var extensionFields = outDat.extensionFieldsBuilder
            extensionFields.accessToken = inDat.extensionFields.accessToken
            var intdashExtensionFields = extensionFields.intdashBuilder
            // プロジェクトIDが空の場合はフィールドがセットされずエラーになるので何かしらセットする。
            intdashExtensionFields.projectUuid = if (inDat.extensionFields.intdash.projectUuid.isNullOrEmpty()) "00000000-0000-0000-0000-000000000000" else inDat.extensionFields.intdash.projectUuid
            // MEMO: intdashExtensionFields をセットしなくとも intdash {} フィールドが追加されてしまう。
            extensionFields.setIntdash(intdashExtensionFields)
            outDat.setExtensionFields(extensionFields)
            var outMsg = ProtoMessage.newBuilder()
            outMsg.connectRequest = outDat.build()
            return Pair(outMsg.build(), null)
        }
        is Disconnect -> {
            var outDat = ProtoDisconnect.newBuilder()
            var (rc, err) = toResultCodeProto(inDat.resultCode)
            if (err != null) {
                return Pair(null, err)
            }
            outDat.resultCode = rc!!
            outDat.resultString = inDat.resultString
            var outMsg = ProtoMessage.newBuilder()
            outMsg.disconnect = outDat.build()
            return Pair(outMsg.build(), null)
        }
        is Ping -> {
            var outDat = ProtoPing.newBuilder()
            outDat.requestId = inDat.requestId.toInt()
            var outMsg = ProtoMessage.newBuilder()
            outMsg.ping = outDat.build()
            return Pair(outMsg.build(), null)
        }
        is Pong -> {
            var outDat = ProtoPong.newBuilder()
            outDat.requestId = inDat.requestId.toInt()
            var outMsg = ProtoMessage.newBuilder()
            outMsg.pong = outDat.build()
            return Pair(outMsg.build(), null)
        }
        is DownstreamOpenRequest -> {
            var (qos, err) = toQosProto(inDat.qos)
            if (err != null) {
                return Pair(null, err)
            }
            var outDat = ProtoDownstreamOpenRequest.newBuilder()
            outDat.requestId = inDat.requestId.toInt()
            outDat.desiredStreamIdAlias = inDat.desiredStreamIdAlias.toInt()
            outDat.addAllDownstreamFilters(toDownstreamFiltersProto(inDat.downstreamFilters))
            outDat.expiryInterval = inDat.expiryInterval.toShort().toInt()
            for (kv in toDataIdAliasesProto(inDat.dataIdAliases)) {
                outDat.putDataIdAliases(kv.key, kv.value)
            }
            outDat.omitEmptyChunk = inDat.omitEmptyChunk
            outDat.qos = qos!!
            var outMsg = ProtoMessage.newBuilder()
            outMsg.downstreamOpenRequest = outDat.build()
            return Pair(outMsg.build(), null)
        }
        is DownstreamResumeRequest -> {
            var outDat = ProtoDownstreamResumeRequest.newBuilder()
            outDat.requestId = inDat.requestId.toInt()
            outDat.streamId = inDat.streamId.toByteString()
            outDat.desiredStreamIdAlias = inDat.desiredStreamIdAlias.toInt()
            outDat.resumeToken = inDat.resumeToken
            var outMsg = ProtoMessage.newBuilder()
            outMsg.downstreamResumeRequest = outDat.build()
            return Pair(outMsg.build(), null)
        }
        is DownstreamCloseRequest -> {
            var outDat = ProtoDownstreamCloseRequest.newBuilder()
            outDat.requestId = inDat.requestId.toInt()
            outDat.streamId = inDat.streamId.toByteString()
            var outMsg = ProtoMessage.newBuilder()
            outMsg.downstreamCloseRequest = outDat.build()
            return Pair(outMsg.build(), null)
        }
        is DownstreamMetadataAck -> {
            var (rc, err) = toResultCodeProto(inDat.resultCode)
            if (err != null) {
                return Pair(null, err)
            }
            var outDat = ProtoDownstreamMetadataAck.newBuilder()
            outDat.requestId = inDat.requestId.toInt()
            outDat.resultCode = rc!!
            outDat.resultString = inDat.resultString
            var outMsg = ProtoMessage.newBuilder()
            outMsg.downstreamMetadataAck = outDat.build()
            return Pair(outMsg.build(), null)
        }
        is DownstreamChunkAck -> {
            var (dprs, err) = toDownstreamChunkResultsProto(inDat.results)
            if (err != null) {
                return Pair(null, err)
            }
            var outDat = ProtoDownstreamChunkAck.newBuilder()
            outDat.streamIdAlias = inDat.streamIdAlias.toInt()
            outDat.ackId = inDat.ackId.toInt()
            outDat.addAllResults(dprs!!)
            for (kv in toUpstreamAliasesProto(inDat.upstreamAliases)) {
                outDat.putUpstreamAliases(kv.key, kv.value)
            }
            for (kv in toDataIdAliasesProto(inDat.dataIdAliases)) {
                outDat.putDataIdAliases(kv.key, kv.value)
            }
            var outMsg = ProtoMessage.newBuilder()
            outMsg.downstreamChunkAck = outDat.build()
            return Pair(outMsg.build(), null)
        }
        is UpstreamOpenRequest -> {
            var (qos, err) = toQosProto(inDat.qos)
            if (err != null) {
                return Pair(null, err)
            }
            var outDat = ProtoUpstreamOpenRequest.newBuilder()
            outDat.requestId = inDat.requestId.toInt()
            outDat.sessionId = inDat.sessionId
            outDat.ackInterval = inDat.ackInterval.toShort().toInt()
            outDat.expiryInterval = inDat.expiryInterval.toShort().toInt()
            outDat.addAllDataIds(toDataIdsProto(inDat.dataIds))
            outDat.qos = qos!!
            var extensionField = UpstreamOpenRequestExtensionFields.newBuilder()
            extensionField.persist = inDat.extensionFields.persist
            outDat.setExtensionFields(extensionField)
            var outMsg = ProtoMessage.newBuilder()
            outMsg.upstreamOpenRequest = outDat.build()
            return Pair(outMsg.build(), null)
        }
        is UpstreamResumeRequest -> {
            var outDat = ProtoUpstreamResumeRequest.newBuilder()
            outDat.requestId = inDat.requestId.toInt()
            outDat.streamId = inDat.streamId.toByteString()
            outDat.resumeToken = inDat.resumeToken
            var outMsg = ProtoMessage.newBuilder()
            outMsg.upstreamResumeRequest = outDat.build()
            return Pair(outMsg.build(), null)
        }
        is UpstreamCloseRequest -> {
            var outDat = ProtoUpstreamCloseRequest.newBuilder()
            outDat.requestId = inDat.requestId.toInt()
            outDat.streamId = inDat.streamId.toByteString()
            outDat.totalDataPoints = inDat.totalDataPoints.toLong()
            outDat.finalSequenceNumber = inDat.finalSequenceNumber.toInt()
            var extensionFields = UpstreamCloseRequestExtensionFields.newBuilder()
            extensionFields.closeSession = inDat.extensionFields.closeSession
            outDat.setExtensionFields(extensionFields)
            var outMsg = ProtoMessage.newBuilder()
            outMsg.upstreamCloseRequest = outDat.build()
            return Pair(outMsg.build(), null)
        }
        is UpstreamMetadata -> {
            var (metadataCase, metadata, err) = toUpstreamMetadataProto(inDat.metadataCase, inDat.metadata)
            if (err != null) {
                return Pair(null, err)
            }
            var outDat = ProtoUpstreamMetadata.newBuilder()
            outDat.requestId = inDat.requestId.toInt()
            when (metadataCase) {
                ProtoUpstreamMetadata.MetadataCase.BASE_TIME -> {
                    outDat.baseTime = metadata as? ProtoBaseTime
                }
                else -> {
                    return Pair(null, IscpException.MalformedMessage())
                }
            }
            var extensionFields = UpstreamMetadataExtensionFields.newBuilder()
            extensionFields.persist = inDat.extensionFields.persist
            outDat.setExtensionFields(extensionFields)
            var outMsg = ProtoMessage.newBuilder()
            outMsg.upstreamMetadata = outDat.build()
            return Pair(outMsg.build(), null)
        }
        is UpstreamChunk -> {
            var outDat = ProtoUpstreamChunk.newBuilder()
            outDat.streamIdAlias = inDat.streamIdAlias.toInt()
            outDat.streamChunk = toStreamChunkProto(inDat.streamChunk)
            outDat.addAllDataIds(toDataIdsProto(inDat.dataIds))
            var outMsg = ProtoMessage.newBuilder()
            outMsg.upstreamChunk = outDat.build()
            return Pair(outMsg.build(), null)
        }
        is UpstreamCall -> {
            var outDat = ProtoUpstreamCall.newBuilder()
            outDat.callId = inDat.callId
            outDat.requestCallId = inDat.requestCallId
            outDat.destinationNodeId = inDat.destinationNodeId
            outDat.name = inDat.name
            outDat.type = inDat.type
            outDat.payload = ByteString.copyFrom(inDat.payload)
            var outMsg = ProtoMessage.newBuilder()
            outMsg.upstreamCall = outDat.build()
            return Pair(outMsg.build(), null)
        }
        else -> {}
    }
    return Pair(null, IscpException.MalformedMessage())
}

internal fun toResultCodeProto(code: ResultCode) : Pair<ProtoResultCode?, Exception?> {
    when (code) {
        ResultCode.SUCCEEDED -> return Pair(ProtoResultCode.SUCCEEDED, null)
        ResultCode.NORMAL_CLOSURE -> return Pair(ProtoResultCode.NORMAL_CLOSURE, null)
        ResultCode.INCOMPATIBLE_VERSION -> return Pair(ProtoResultCode.INCOMPATIBLE_VERSION, null)
        ResultCode.MAXIMUM_DATA_ID_ALIAS -> return Pair(ProtoResultCode.MAXIMUM_DATA_ID_ALIAS, null)
        ResultCode.MAXIMUM_UPSTREAM_ALIAS -> return Pair(ProtoResultCode.MAXIMUM_UPSTREAM_ALIAS, null)
        ResultCode.UNSPECIFIED_ERROR -> return Pair(ProtoResultCode.UNSPECIFIED_ERROR, null)
        ResultCode.NO_NODE_ID -> return Pair(ProtoResultCode.NO_NODE_ID, null)
        ResultCode.AUTH_FAILED -> return Pair(ProtoResultCode.AUTH_FAILED, null)
        ResultCode.CONNECT_TIMEOUT -> return Pair(ProtoResultCode.CONNECT_TIMEOUT, null)
        ResultCode.MALFORMED_MESSAGE -> return Pair(ProtoResultCode.MALFORMED_MESSAGE, null)
        ResultCode.PROTOCOL_ERROR -> return Pair(ProtoResultCode.PROTOCOL_ERROR, null)
        ResultCode.ACK_TIMEOUT -> return Pair(ProtoResultCode.ACK_TIMEOUT, null)
        ResultCode.INVALID_PAYLOAD -> return Pair(ProtoResultCode.INVALID_PAYLOAD, null)
        ResultCode.INVALID_DATA_ID -> return Pair(ProtoResultCode.INVALID_DATA_ID, null)
        ResultCode.INVALID_DATA_ID_ALIAS -> return Pair(ProtoResultCode.INVALID_DATA_ID_ALIAS, null)
        ResultCode.INVALID_DATA_FILTER -> return Pair(ProtoResultCode.INVALID_DATA_FILTER, null)
        ResultCode.STREAM_NOT_FOUND -> return Pair(ProtoResultCode.STREAM_NOT_FOUND, null)
        ResultCode.RESUME_REQUEST_CONFLICT -> return Pair(ProtoResultCode.RESUME_REQUEST_CONFLICT, null)
        ResultCode.PROCESS_FAILED -> return Pair(ProtoResultCode.PROCESS_FAILED, null)
        ResultCode.DESIRED_QOS_NOT_SUPPORTED -> return Pair(ProtoResultCode.DESIRED_QOS_NOT_SUPPORTED, null)
        ResultCode.PING_TIMEOUT -> return Pair(ProtoResultCode.PING_TIMEOUT, null)
        ResultCode.TOO_LARGE_MESSAGE_SIZE -> return Pair(ProtoResultCode.TOO_LARGE_MESSAGE_SIZE, null)
        ResultCode.TOO_MANY_DATA_ID_ALIASES -> return Pair(ProtoResultCode.TOO_MANY_DATA_ID_ALIASES, null)
        ResultCode.TOO_MANY_STREAMS -> return Pair(ProtoResultCode.TOO_MANY_STREAMS, null)
        ResultCode.TOO_LONG_ACK_INTERVAL -> return Pair(ProtoResultCode.TOO_LONG_ACK_INTERVAL, null)
        ResultCode.TOO_MANY_DOWNSTREAM_FILTERS -> return Pair(ProtoResultCode.TOO_MANY_DOWNSTREAM_FILTERS, null)
        ResultCode.TOO_MANY_DATA_FILTERS -> return Pair(ProtoResultCode.TOO_MANY_DATA_FILTERS, null)
        ResultCode.TOO_LONG_EXPIRY_INTERVAL -> return Pair(ProtoResultCode.TOO_LONG_EXPIRY_INTERVAL, null)
        ResultCode.TOO_LONG_PING_TIMEOUT -> return Pair(ProtoResultCode.TOO_LONG_PING_TIMEOUT, null)
        ResultCode.TOO_SHORT_PING_INTERVAL -> return Pair(ProtoResultCode.TOO_SHORT_PING_INTERVAL, null)
        ResultCode.TOO_SHORT_PING_TIMEOUT -> return Pair(ProtoResultCode.TOO_SHORT_PING_TIMEOUT, null)
        ResultCode.RATE_LIMIT_REACHED -> return Pair(ProtoResultCode.RATE_LIMIT_REACHED, null)
        ResultCode.TOO_LARGE_FEED_ID -> return Pair(ProtoResultCode.TOO_LARGE_FEED_ID, null)
        ResultCode.TOO_MANY_TARGET_NODES -> return Pair(ProtoResultCode.TOO_MANY_TARGET_NODES, null)
        ResultCode.FEED_NOT_FOUND -> return Pair(ProtoResultCode.FEED_NOT_FOUND, null)
        ResultCode.INVALID_RESUME_TOKEN -> return Pair(ProtoResultCode.INVALID_RESUME_TOKEN, null)
        ResultCode.NODE_ID_MISMATCH -> return Pair(ProtoResultCode.NODE_ID_MISMATCH, null)
        ResultCode.SESSION_NOT_FOUND -> return Pair(ProtoResultCode.SESSION_NOT_FOUND, null)
        ResultCode.SESSION_ALREADY_CLOSED -> return Pair(ProtoResultCode.SESSION_ALREADY_CLOSED, null)
        ResultCode.SESSION_CANNOT_CLOSED -> return Pair(ProtoResultCode.SESSION_CANNOT_CLOSED, null)
    }
    return Pair(null, IscpException.MalformedMessage())
}

internal fun toDataIdAliasesProto(dic: Map<UInt, DataId>) : Map<Int, DataID> {
    var res: MutableMap<Int, DataID> = mutableMapOf()
    for (kv in dic) {
        var v = DataID.newBuilder()
        v.name = kv.value.name
        v.type = kv.value.type
        res[kv.key.toInt()] = v.build()
    }
    return res.toMap()
}

internal fun toDataIdsProto(dataIds: List<DataId>) : List<DataID> {
    var res = mutableListOf<DataID>()
    for (d in dataIds) {
        var v = DataID.newBuilder()
        v.name = d.name
        v.type = d.type
        res.add(v.build())
    }
    return res.toList()
}

internal fun toQosProto(qos: QoS) : Pair<ProtoQoS?, Exception?> {
    when (qos) {
        QoS.RELIABLE -> return Pair(ProtoQoS.RELIABLE, null)
        QoS.UNRELIABLE -> return Pair(ProtoQoS.UNRELIABLE, null)
        QoS.PARTIAL -> return Pair(ProtoQoS.PARTIAL, null)
        else -> {}
    }
    return Pair(null, IscpException.MalformedMessage())
}

internal fun toDownstreamFiltersProto(filters: List<DownstreamFilter>) : List<ProtoDownstreamFilter> {
    var res = mutableListOf<ProtoDownstreamFilter>()
    for (f in filters) {
        var v = ProtoDownstreamFilter.newBuilder()
        v.sourceNodeId = f.sourceNodeId
        v.addAllDataFilters(toDataFiltersProto(f.dataFilters))
        res.add(v.build())
    }
    return res.toList()
}

internal fun toDataFiltersProto(filters: List<DataFilter>) : List<ProtoDataFilter> {
    var res = mutableListOf<ProtoDataFilter>()
    for (f in filters) {
        var v = ProtoDataFilter.newBuilder()
        v.name = f.name
        v.type = f.type
        res.add(v.build())
    }
    return res.toList()
}

internal fun toDownstreamChunkResultsProto(results: List<DownstreamChunkResult>) : Pair<List<ProtoDownstreamChunkResult>?, Exception?> {
    var res = mutableListOf<ProtoDownstreamChunkResult>()
    for (v in results) {
        var (rc, err) = toResultCodeProto(v.resultCode)
        if (err != null) {
            return Pair(null, err)
        }
        var nv = ProtoDownstreamChunkResult.newBuilder()
        nv.streamIdOfUpstream = v.streamIdOfUpstream.toByteString()
        nv.sequenceNumberInUpstream = v.sequenceNumberInUpstream.toInt()
        nv.resultCode = rc!!
        nv.resultString = v.resultString
        res.add(nv.build())
    }
    return Pair(res.toList(), null)
}

internal fun toUpstreamAliasesProto(dic: Map<UInt, UpstreamInfo>) : Map<Int, ProtoUpstreamInfo> {
    var res: MutableMap<Int, ProtoUpstreamInfo> = mutableMapOf()
    for (kv in dic) {
        res[kv.key.toInt()] = toUpstreamInfoProto(kv.value)
    }
    return res.toMap()
}

internal fun toUpstreamInfoProto(info: UpstreamInfo) : ProtoUpstreamInfo {
    var nv = ProtoUpstreamInfo.newBuilder()
    nv.sessionId = info.sessionId
    nv.sourceNodeId = info.sourceNodeId
    nv.streamId = info.streamId.toByteString()
    return nv.build()
}

internal fun toUpstreamMetadataProto(metadataCase: UpstreamMetadata.MetadataCase?, metadata: Any?) : Triple<ProtoUpstreamMetadata.MetadataCase?, Any?, Exception?> {
    when (metadataCase) {
        UpstreamMetadata.MetadataCase.BASE_TIME -> {
            var baseTime = metadata as BaseTime
            var nv = ProtoBaseTime.newBuilder()
            nv.sessionId = baseTime.sessionId
            nv.name = baseTime.name
            nv.priority = baseTime.priority.toInt()
            nv.elapsedTime = baseTime.elapsedTime
            nv.baseTime = baseTime.baseTime
            return Triple(ProtoUpstreamMetadata.MetadataCase.BASE_TIME, nv.build(), null)
        }
        else -> {}
    }
    return Triple(null, null, IscpException.MalformedMessage())
}

internal fun toStreamChunkProto(streamChunk: StreamChunk) : ProtoStreamChunk {
    var nv = ProtoStreamChunk.newBuilder()
    nv.sequenceNumber = streamChunk.sequenceNumber.toInt()
    nv.addAllDataPointGroups(toDataPointGroupsProto(streamChunk.dataPointGroups))
    return nv.build()
}

internal fun toDataPointGroupsProto(groups: List<DataPointGroup>) : List<ProtoDataPointGroup> {
    var res = mutableListOf<ProtoDataPointGroup>()
    for (g in groups) {
        var nv = ProtoDataPointGroup.newBuilder()
        nv.addAllDataPoints(toDataPointsProto(g.dataPoints))
        when (g.dataIdOrAliasCase) {
            DataPointGroup.DataIdOrAliasCase.DATA_ID -> {
                var (dataIdCase, dataId) = toDataIdOrAliasProto(g.dataIdOrAliasCase, g.dataId)
                nv.dataId = dataId as DataID
            }
            DataPointGroup.DataIdOrAliasCase.DATA_ID_ALIAS -> {
                var (aliasCase, alias) = toDataIdOrAliasProto(g.dataIdOrAliasCase, g.dataIdAlias)
                nv.dataIdAlias = alias as Int
            }
            else -> {
                IscpLog.e("not supported dataIdOrAliasCase")
                continue
            }
        }
        res.add(nv.build())
    }
    return res.toList()
}

internal fun toDataIdOrAliasProto(idOrAliasCase: DataPointGroup.DataIdOrAliasCase?, idOrAlias: Any?) : Pair<ProtoDataPointGroup.DataIdOrAliasCase?, Any?> {
    when(idOrAliasCase)
    {
        DataPointGroup.DataIdOrAliasCase.DATA_ID -> {
            var dataId = idOrAlias as DataId
            var nv = DataID.newBuilder()
            nv.name = dataId.name
            nv.type = dataId.type
            return Pair(ProtoDataPointGroup.DataIdOrAliasCase.DATA_ID, nv.build())
        }
        DataPointGroup.DataIdOrAliasCase.DATA_ID_ALIAS -> {
            var dataIdAlias = idOrAlias as UInt
            return Pair(ProtoDataPointGroup.DataIdOrAliasCase.DATA_ID_ALIAS, dataIdAlias.toInt())
        }
        else -> {}
    }
    return Pair(null, null)
}

internal fun toDataPointsProto(points: List<DataPoint>) : List<ProtoDataPoint> {
    var res = mutableListOf<ProtoDataPoint>()
    for (p in points) {
        var nv = ProtoDataPoint.newBuilder()
        nv.elapsedTime = p.elapsedTime
        nv.payload = ByteString.copyFrom(p.payload)
        res.add(nv.build())
    }
    return res.toList()
}
