package com.aptpod.iscp


/**
 * このライブラリのバージョン。
 */
const val LIBRARY_VERSION = "1.2.0"

/**
 * 対応しているプロトコルバージョン。
 */
const val SUPPORTED_PROTOCOL_VERSION = "3.0.0"

internal const val LOG_TAG = "iSCP"