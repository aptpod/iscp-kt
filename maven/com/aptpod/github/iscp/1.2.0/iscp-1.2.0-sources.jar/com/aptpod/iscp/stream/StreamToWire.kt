package com.aptpod.iscp.stream

import com.aptpod.iscp.model.BaseTime
import com.aptpod.iscp.model.DataFilter
import com.aptpod.iscp.model.DataId
import com.aptpod.iscp.model.DownstreamFilter
import com.aptpod.iscp.model.QoS
import com.aptpod.iscp.model.UpstreamCall
import com.aptpod.iscp.model.UpstreamReplyCall

internal fun toDataIdsWire(dataIds: List<DataId>) : List<com.aptpod.iscp.message.DataId> {
    var res = mutableListOf<com.aptpod.iscp.message.DataId>()
    for (v in dataIds) {
        res.add(toDataIdWire(v))
    }
    return res.toList()
}

internal fun toDataIdWire(dataId: DataId) : com.aptpod.iscp.message.DataId {
    var res = com.aptpod.iscp.message.DataId()
    res.name = dataId.name
    res.type = dataId.type
    return res
}

internal fun toQosWire(qos: QoS) : com.aptpod.iscp.message.QoS {
    return when (qos) {
        QoS.UNRELIABLE -> com.aptpod.iscp.message.QoS.UNRELIABLE
        QoS.RELIABLE -> com.aptpod.iscp.message.QoS.RELIABLE
        QoS.PARTIAL -> com.aptpod.iscp.message.QoS.PARTIAL
    }
}

internal fun toBaseTimeWire(baseTime: BaseTime) : com.aptpod.iscp.message.BaseTime {
    var msg = com.aptpod.iscp.message.BaseTime(
        sessionId = baseTime.sessionId,
        name = baseTime.name,
        priority = baseTime.priority.toUByte(),
        elapsedTime = baseTime.elapsedTime,
        baseTime = baseTime.baseTime
    )
    return msg
}

internal fun toUpstreamCallWire(upstreamCall: UpstreamCall, callId: String) : com.aptpod.iscp.message.UpstreamCall {
    var msg = com.aptpod.iscp.message.UpstreamCall(
        callId = callId,
        requestCallId = "",
        destinationNodeId = upstreamCall.destinationNodeId,
        name = upstreamCall.name,
        type = upstreamCall.type,
        payload = upstreamCall.payload
    )
    return msg
}

internal fun toUpstreamCallWire(upstreamReplyCall: UpstreamReplyCall, callId: String) : com.aptpod.iscp.message.UpstreamCall {
    var msg = com.aptpod.iscp.message.UpstreamCall(
        callId = callId,
        requestCallId = upstreamReplyCall.requestCallId,
        destinationNodeId = upstreamReplyCall.destinationNodeId,
        name = upstreamReplyCall.name,
        type = upstreamReplyCall.type,
        payload = upstreamReplyCall.payload
    )
    return msg
}

internal fun toDataIdAliasesWire(dataIdAliases: Map<UInt, DataId>) : MutableMap<UInt, com.aptpod.iscp.message.DataId> {
    var res: MutableMap<UInt, com.aptpod.iscp.message.DataId> = mutableMapOf()
    for (kv in dataIdAliases) {
        res[kv.key] = toDataIdWire(kv.value)
    }
    return res
}

internal fun toDownstreamFiltersWire(filters: List<DownstreamFilter>) : List<com.aptpod.iscp.message.DownstreamFilter> {
    var res = mutableListOf<com.aptpod.iscp.message.DownstreamFilter>()
    for (f in filters) {
        var v = com.aptpod.iscp.message.DownstreamFilter()
        v.sourceNodeId = f.sourceNodeId
        v.dataFilters = toDataFiltersWire(f.dataFilters)
        res.add(v)
    }
    return res.toList()
}

internal fun toDataFiltersWire(filters: List<DataFilter>) : List<com.aptpod.iscp.message.DataFilter> {
    var res = mutableListOf<com.aptpod.iscp.message.DataFilter>()
    for (f in filters) {
        var v = com.aptpod.iscp.message.DataFilter()
        v.name = f.name
        v.type = f.type
        res.add(v)
    }
    return res.toList()
}