package com.aptpod.iscp.message

/**
 * @param name 名称
 * @param type 型
 */
internal class DataId(
    var name: String = "",
    var type: String = ""
) {

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        var self = other as? DataId ?: return false
        if (name != self.name) return false
        if (type != self.type) return false
        return true
    }

}