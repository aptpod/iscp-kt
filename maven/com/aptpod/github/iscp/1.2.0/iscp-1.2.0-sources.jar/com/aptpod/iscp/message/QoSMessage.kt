package com.aptpod.iscp.message

internal enum class QoS {
    /**
     * 低信頼
     */
    UNRELIABLE,
    /**
     * 高信頼
     */
    RELIABLE,
    /**
     * 部分的信頼
     */
    PARTIAL
}