package com.aptpod.iscp.connection

import com.aptpod.iscp.model.IscpException
import com.aptpod.iscp.model.DataId
import com.aptpod.iscp.model.FlushPolicy
import com.aptpod.iscp.model.QoS
import com.aptpod.iscp.stream.Upstream
import com.aptpod.iscp.logger.IscpLog
import com.aptpod.iscp.message.ResultCode
import com.aptpod.iscp.message.UpstreamCloseResponse
import com.aptpod.iscp.message.UpstreamOpenResponse
import com.aptpod.iscp.message.UpstreamResumeResponse
import com.aptpod.iscp.extensions.toMaskString
import com.aptpod.iscp.transport.Receiver

/**
 * アップストリームを開きます。
 */
internal fun Connection.invokeOpenUpstreamAsync(
    sessionId: String,
    ackInterval: Short,
    expiryInterval: Short,
    dataIds: List<DataId>?,
    qos: QoS,
    persist: Boolean,
    flushPolicy: FlushPolicy,
    openTimeout: Long,
    closeTimeout: Long,
    completion: (((Upstream?, Exception?) -> Unit)?)
) {
    if (!this.isConnecting) {
        completion?.invoke(null, IscpException.TransportClosed)
        return
    }
    var requestId = this.requestIdGenerator.generate()
    var receiver = Receiver("(requestId: $requestId)", openTimeout)
    receiver.subscribe<UpstreamOpenResponse> { msg, exception ->
        if (msg == null || exception != null) {
            IscpLog.e("failed to receive requestId($requestId) upstreamOpenResponse. ${exception?.javaClass?.name ?: ""}, requestId: ${msg?.requestId?.toString() ?: "null"}, resultCode: ${msg?.resultCode?.code?.toString() ?: "null"}, resultString: ${msg?.resultString ?: "null"}, resumeToken: ${msg?.resumeToken?.toMaskString() ?: "null"} - Connection")
            // Receiverを解除
            this.receivers.unregister(receiver)
            completion?.invoke(null, exception ?: IscpException.Unexpected("upstreamOpenResponse not found."))
            return@subscribe
        }
        if (msg.requestId != requestId) { return@subscribe }
        // Receiverを解除
        this.receivers.unregister(receiver)
        IscpLog.d("didReceived upstreamOpenResponse(requestId: ${msg.requestId}, resultCode: ${msg.resultCode.code}, resultString: ${msg.resultString}, resumeToken: ${if (msg.resumeToken.isNotEmpty()) msg.resumeToken.toMaskString() else "null"}) - Connection")
        if (msg.resultCode != ResultCode.SUCCEEDED)
        {
            completion?.invoke(null, IscpException.FailedMessage(msg.resultCode.code, msg.resultString))
            return@subscribe
        }

        // アップストリームのオープンに成功
        var upstream = Upstream(
            sessionId = sessionId,
            ackInterval = ackInterval,
            expiryInterval = expiryInterval,
            dataIds = dataIds ?: listOf(),
            qos = qos,
            persist = persist,
            flushPolicy = flushPolicy,
            openTimeout = openTimeout,
            closeTimeout = closeTimeout,
            connection = this,
            openResponse = msg)
        this.registerUpstream(upstream)
        upstream.isOpen = true
        completion?.invoke(upstream, null)
    }
    // Receiverを登録
    this.receivers.register(receiver)

    // Send UpstreamOpenRequest
    var sendException = this.sendUpstreamOpenRequest(
        requestId = requestId,
        sessionId = sessionId,
        ackInterval = ackInterval.toUShort(),
        expiryInterval = expiryInterval.toUShort(),
        dataIds = dataIds ?: listOf(),
        qos = qos,
        persist = persist)
    if (sendException != null) {
        this.receivers.unregister(receiver)
        completion?.invoke(null, sendException)
        return
    }
}

/**
 * ストリーム設定を引き継いで別ストリームとして再度アップストリームを開きます。
 */
internal fun Connection.invokeReopenUpstreamAsync(upstream: Upstream, handoverDataPoints: Boolean, completion: ((Upstream?, Exception?) -> Unit)?) {
    IscpLog.d("reopenUpstream(upstream: ${upstream.id}) - Connection")
    if (!this.isConnecting) {
        completion?.invoke(null, IscpException.TransportClosed)
        return
    }
    var requestId = this.requestIdGenerator.generate()
    var receiver = Receiver("(requestId: $requestId)", upstream.openTimeout)
    receiver.subscribe<UpstreamOpenResponse> { msg, exception ->
        if (msg == null || exception != null) {
            IscpLog.e("failed to receive requestId($requestId) upstreamOpenResponse. ${exception?.javaClass?.name ?: ""}, requestId: ${msg?.requestId?.toString() ?: "null"}, resultCode: ${msg?.resultCode?.code?.toString() ?: "null"}, resultString: ${msg?.resultString ?: "null"}, resumeToken: ${msg?.resumeToken?.toMaskString() ?: "null"} - Connection")
            // Receiverを解除
            this.receivers.unregister(receiver)
            completion?.invoke(null, exception ?: IscpException.Unexpected("upstreamOpenResponse not found."))
            return@subscribe
        }
        if (msg.requestId != requestId) { return@subscribe }
        // Receiverを解除
        this.receivers.unregister(receiver)
        IscpLog.d("didReceived upstreamOpenResponse(requestId: ${msg.requestId}, resultCode: ${msg.resultCode.code}, resultString: ${msg.resultString}, resumeToken: ${if (msg.resumeToken.isNotEmpty()) msg.resumeToken.toMaskString() else "null"}) - Connection")
        if (msg.resultCode != ResultCode.SUCCEEDED)
        {
            completion?.invoke(null, IscpException.FailedMessage(msg.resultCode.code, msg.resultString))
            return@subscribe
        }

        // アップストリームのオープンに成功
        var reUpstream = Upstream(upstream, this, msg)
        this.registerUpstream(reUpstream)
        reUpstream.isOpen = true

        // データポイントの引き継ぎ
        if (handoverDataPoints) {
            var dataPoints = upstream.getDataPointsBufferForOtherStream()
            if (dataPoints.count() > 0) {
                IscpLog.d("Handover of ${dataPoints.count()} data point groups from Upstream[${upstream.id}] to Upstream[${reUpstream.id}]")
                reUpstream.writeDataPoints(dataPointGroups = dataPoints)
            }
        }

        completion?.invoke(reUpstream, null)
    }
    // Receiverを登録
    this.receivers.register(receiver)

    // Send UpstreamOpenRequest
    var sendException = this.sendUpstreamOpenRequestForReconnect(requestId, upstream)
    if (sendException != null) {
        this.receivers.unregister(receiver)
        completion?.invoke(null, sendException)
        return
    }
}

internal fun Connection.resumeUpstreamAsync(upstream: Upstream, completion: ((Upstream, Exception?) -> Unit)?) {
    IscpLog.d("resumeUpstream(upstream: ${upstream.id}, resumeToken: ${upstream.resumeToken.toMaskString()}) - Connection")
    if (!this.isConnecting) {
        completion?.invoke(upstream, IscpException.TransportClosed)
        return
    }
    var requestId = this.requestIdGenerator.generate()
    var receiver = Receiver("(requestId: $requestId)", upstream.openTimeout)
    receiver.subscribe<UpstreamResumeResponse> { msg, exception ->
        if (msg == null || exception != null) {
            IscpLog.e("failed to receive requestId($requestId) upstreamResumeResponse. ${exception?.javaClass?.name ?: ""}, requestId: ${msg?.requestId?.toString() ?: "null"}, resultCode: ${msg?.resultCode?.code?.toString() ?: "null"}, resultString: ${msg?.resultString ?: "null"}, resumeToken: ${msg?.resumeToken?.toMaskString() ?: "null"} - Connection")
            // Receiverを解除
            this.receivers.unregister(receiver)
            completion?.invoke(upstream, exception ?: IscpException.Unexpected("upstreamResumeResponse not found."))
            return@subscribe
        }
        if (msg.requestId != requestId) { return@subscribe }
        // Receiverを解除
        this.receivers.unregister(receiver)
        IscpLog.d("didReceived upstreamResumeResponse(requestId: ${msg.requestId}, resultCode: ${msg.resultCode.code}, resultString: ${msg.resultString}, resumeToken: ${if (msg.resumeToken.isNotEmpty()) msg.resumeToken.toMaskString() else "null"}) - Connection")
        if (msg.resultCode != ResultCode.SUCCEEDED)
        {
            completion?.invoke(upstream, IscpException.FailedMessage(msg.resultCode.code, msg.resultString))
            return@subscribe
        }

        // アップストリームの再オープンに成功
        upstream.streamIdAlias = msg.assignedStreamIdAlias
        upstream.resumeToken = msg.resumeToken
        upstream.isOpen = true
        completion?.invoke(upstream, null)
    }
    // Receiverを登録
    this.receivers.register(receiver)

    // Send UpstreamResumeRequest
    var sendException = this.sendUpstreamResumeRequest(requestId, upstream)
    if (sendException != null) {
        this.receivers.unregister(receiver)
        completion?.invoke(upstream, sendException)
        return
    }
}

internal fun Connection.closeUpstream(upstream: Upstream, closeSession: Boolean = false, completion: ((Exception?) -> Unit)? = null) {
    if (!this.isConnecting) {
        completion?.invoke(IscpException.TransportClosed)
        return
    }
    upstream.waitToSendAllDataPointsAndReceiveAllAck { err ->
        try {
            if (err != null)
            {
                completion?.invoke(err)
                return@waitToSendAllDataPointsAndReceiveAllAck
            }
            if (this.isConnecting != true)
            {
                completion?.invoke(IscpException.TransportClosed)
                return@waitToSendAllDataPointsAndReceiveAllAck
            }
            var requestId = this.requestIdGenerator.generate()
            var receiver = Receiver("(requestId: $requestId)", upstream.closeTimeout)
            receiver.subscribe<UpstreamCloseResponse> { msg, exception ->
                if (msg == null || exception != null) {
                    IscpLog.e("failed to receive requestId($requestId) upstreamCloseResponse. ${exception?.javaClass?.name ?: ""}, requestId: ${msg?.requestId?.toString() ?: "null"}, resultCode: ${msg?.resultCode?.code?.toString() ?: "null"}, resultString: ${msg?.resultString ?: "null"} - Connection")
                    // Receiverを解除
                    this.receivers.unregister(receiver)
                    completion?.invoke(exception ?: IscpException.Unexpected("upstreamCloseResponse not found."))
                    return@subscribe
                }
                if (msg.requestId != requestId) { return@subscribe }
                // Receiverを解除
                this.receivers.unregister(receiver)
                IscpLog.d("didReceived upstreamCloseResponse(requestId: ${msg.requestId}, resultCode: ${msg.resultCode.code}, resultString: ${msg.resultString}) - Connection")
                if (msg.resultCode != ResultCode.SUCCEEDED)
                {
                    completion?.invoke(IscpException.FailedMessage(msg.resultCode.code, msg.resultString))
                    return@subscribe
                }

                // アップストリームのクローズに成功
                upstream.isOpen = false
                completion?.invoke(null)
            }
            // Receiverを登録
            this.receivers.register(receiver)

            // Send UpstreamCloseRequest
            var isSession = if (upstream.sessionId.isNullOrEmpty()) false else closeSession // セッションIDが未設定の場合はセットしない。
            var sendException = this.sendUpstreamCloseRequest(requestId, upstream, isSession)
            if (sendException != null) {
                this.receivers.unregister(receiver)
                completion?.invoke(sendException)
                return@waitToSendAllDataPointsAndReceiveAllAck
            }
        }
        finally
        {
            upstream.dispose()
            // /アップストリームの登録を解除
            this.unregisterUpstream(upstream)
        }
    }

}
