package com.aptpod.iscp.extensions

internal fun UInt.convertInt(): Int {
    var i = this.toInt()
    return if (i <= Int.MAX_VALUE) i - (Int.MIN_VALUE*-1) else (this - Int.MAX_VALUE.toUInt()).toInt()
}

internal fun Int.convertUInt(): UInt {
    var u = this.toUInt()
    return if (this < 0) (this + (Int.MIN_VALUE*-1)).toUInt() else u + (Int.MIN_VALUE*-1).toUInt()
}

internal fun ULong.addingReportingOverflow(v: ULong) : Pair<ULong, Boolean> {
    var willOverflow: Boolean = false;

    if (v > (ULong.MAX_VALUE - this)) willOverflow = true;

    var res = this;
    if (!willOverflow)
    {
        res += v;
    }
    return Pair(res, willOverflow);
}