package com.aptpod.iscp.message

import com.aptpod.iscp.helpers.UUIDUtils
import java.util.UUID

/**
 * @param requestId リクエストID
 * @param desiredStreamIdAlias 割り当てを希望するストリームIDエイリアス
 * @param downstreamFilters ダウンストリームフィルタのリスト
 * @param expiryInterval 有効期限
 *
 * 単位は秒
 * @param dataIdAliases データIDエイリアス
 * @param qos QoS
 * @param omitEmptyChunk 空のチャンクの送信を省略するかどうか
 * @param extensionFields 拡張フィールド
 */
internal class DownstreamOpenRequest(
    var requestId: UInt = 0u,
    var desiredStreamIdAlias: UInt = 0u,
    var downstreamFilters: List<DownstreamFilter> = listOf(),
    var expiryInterval: UShort = 0u,
    var dataIdAliases: MutableMap<UInt, DataId> = mutableMapOf(),
    var qos: QoS = QoS.UNRELIABLE,
    var omitEmptyChunk: Boolean = false,
    var extensionFields: ExtensionFields = ExtensionFields()
) : IMessage {

    companion object

    class ExtensionFields {

        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            var self = other as? ExtensionFields ?: return false
            return true
        }
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        var self = other as? DownstreamOpenRequest ?: return false
        if (this.requestId != self.requestId) return false
        if (this.desiredStreamIdAlias != self.desiredStreamIdAlias) return false
        if (!this.downstreamFilters.equals(self.downstreamFilters)) return false
        if (this.expiryInterval != self.expiryInterval) return false
        if (!this.dataIdAliases.equals(self.dataIdAliases)) return false
        if (this.qos != self.qos) return false
        if (this.omitEmptyChunk != self.omitEmptyChunk) return false
        if (!this.extensionFields.equals(self.extensionFields)) return false
        return true
    }
}

/**
 * @param requestId リクエストID
 * @param assignedStreamId 割り当てられたストリームID
 * @param serverTime サーバー時刻
 *
 * 単位はナノ秒
 * @param resultCode 結果コード
 * @param resultString 結果文字列
 * @param resumeToken ストリーム再開用トークン
 * @param extensionFields 拡張フィールド
 */
internal class DownstreamOpenResponse(
    var requestId: UInt = 0u,
    var assignedStreamId: UUID = UUIDUtils.empty(),
    var serverTime: Long = 0,
    var resultCode: ResultCode = ResultCode.SUCCEEDED,
    var resultString: String = "",
    var resumeToken: String = "",
    var extensionFields: ExtensionFields = ExtensionFields()
) : IMessage {

    class ExtensionFields {

        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            var self = other as? ExtensionFields ?: return false
            return true
        }
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        var self = other as? DownstreamOpenResponse ?: return false
        if (this.requestId != self.requestId) return false
        if (this.assignedStreamId != self.assignedStreamId) return false
        if (this.serverTime != self.serverTime) return false
        if (this.resultCode != self.resultCode) return false
        if (this.resultString != self.resultString) return false
        if (!this.extensionFields.equals(self.extensionFields)) return false
        return true
    }
}

/**
 * @param requestId リクエストID
 * @param streamId ストリームID
 * @param desiredStreamIdAlias 割り当てを希望するストリームIDエイリアス
 * @param resumeToken ストリーム再開用トークン
 * @param extensionFields 拡張フィールド
 */
internal class DownstreamResumeRequest(
    var requestId: UInt = 0u,
    var streamId: UUID = UUIDUtils.empty(),
    var desiredStreamIdAlias: UInt = 0u,
    var resumeToken: String = "",
    var extensionFields: ExtensionFields = ExtensionFields()
) : IMessage {

    class ExtensionFields {

        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            var self = other as? ExtensionFields ?: return false
            return true
        }
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        var self = other as? DownstreamResumeRequest ?: return false
        if (this.requestId != self.requestId) return false
        if (this.streamId != self.streamId) return false
        if (this.desiredStreamIdAlias != self.desiredStreamIdAlias) return false
        if (!this.extensionFields.equals(self.extensionFields)) return false
        return true
    }
}

/**
 * @param requestId リクエストID
 * @param resultCode 結果コード
 * @param resultString 結果文字列
 * @param resumeToken ストリーム再開用トークン
 * @param extensionFields 拡張フィールド
 */
internal class DownstreamResumeResponse(
    var requestId: UInt = 0u,
    var resultCode: ResultCode = ResultCode.SUCCEEDED,
    var resultString: String = "",
    var resumeToken: String = "",
    var extensionFields: ExtensionFields = ExtensionFields()
) : IMessage {

    class ExtensionFields {

        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            var self = other as? ExtensionFields ?: return false
            return true
        }
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        var self = other as? DownstreamResumeResponse ?: return false
        if (this.requestId != self.requestId) return false
        if (this.resultCode != self.resultCode) return false
        if (this.resultString != self.resultString) return false
        if (!this.extensionFields.equals(self.extensionFields)) return false
        return true
    }
}

/**
 * @param requestId リクエストID
 * @param streamId ストリームID
 * @param extensionFields 拡張フィールド
 */
internal class DownstreamCloseRequest(
    var requestId: UInt = 0u,
    var streamId: UUID = UUIDUtils.empty(),
    var extensionFields: ExtensionFields = ExtensionFields()
) : IMessage {

    class ExtensionFields {

        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            var self = other as? ExtensionFields ?: return false
            return true
        }
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        var self = other as? DownstreamCloseRequest ?: return false
        if (this.requestId != self.requestId) return false
        if (this.streamId != self.streamId) return false
        if (!this.extensionFields.equals(self.extensionFields)) return false
        return true
    }
}

/**
 * @param requestId リクエストID
 * @param resultCode 結果コード
 * @param resultString 結果文字列
 * @param extensionFields 拡張フィールド
 */
internal class DownstreamCloseResponse(
    var requestId: UInt = 0u,
    var resultCode: ResultCode = ResultCode.SUCCEEDED,
    var resultString: String = "",
    var extensionFields: ExtensionFields = ExtensionFields()
) : IMessage {

    class ExtensionFields {

        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            var self = other as? ExtensionFields ?: return false
            return true
        }
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        var self = other as? DownstreamCloseResponse ?: return false
        if (this.requestId != self.requestId) return false
        if (this.resultCode != self.resultCode) return false
        if (this.resultString != self.resultString) return false
        if (!this.extensionFields.equals(self.extensionFields)) return false
        return true
    }
}