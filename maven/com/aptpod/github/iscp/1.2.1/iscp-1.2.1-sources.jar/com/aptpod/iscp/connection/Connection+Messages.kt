package com.aptpod.iscp.connection

import com.aptpod.iscp.extensions.addingReportingOverflow
import com.aptpod.iscp.model.IscpException
import com.aptpod.iscp.model.BaseTime
import com.aptpod.iscp.model.DataId
import com.aptpod.iscp.model.DownstreamFilter
import com.aptpod.iscp.model.QoS
import com.aptpod.iscp.model.UpstreamCall
import com.aptpod.iscp.model.UpstreamChunk
import com.aptpod.iscp.model.UpstreamReplyCall
import com.aptpod.iscp.logger.IscpLog
import com.aptpod.iscp.message.*
import com.aptpod.iscp.stream.Downstream
import com.aptpod.iscp.stream.Upstream
import com.aptpod.iscp.stream.toBaseTimeWire
import com.aptpod.iscp.stream.toDataIdAliasesWire
import com.aptpod.iscp.stream.toDataIdsWire
import com.aptpod.iscp.stream.toDownstreamFiltersWire
import com.aptpod.iscp.stream.toQosWire
import com.aptpod.iscp.stream.toUpstreamCallWire
import com.aptpod.iscp.transport.ITransport
import kotlin.concurrent.withLock

//region for Transport

internal fun Connection.sendConnectRequest(requestId: UInt, accessToken: String): Exception? {
    var transport = this.transport ?: return IscpException.TransportClosed
    var msg = ConnectRequest(
        requestId = requestId,
        protocolVersion = this.protocolVersion,
        nodeId = this.nodeId,
        pingInterval = this.pingInterval.toUInt(),
        pingTimeout = this.pingTimeout.toUInt()
    )
    msg.extensionFields.accessToken = accessToken
    if (this.projectUuid.isNotEmpty()) {
        var intdash = ConnectRequest.IntdashExtensionFields()
        intdash.projectUuid = this.projectUuid
        msg.extensionFields.intdash = intdash
    }
    var (d, err) = this.converter.encodeTo(msg)
    var data: ByteArray = d ?: return err
    // Write
    var e = transport.write(data)
    if (e != null) {
        return e
    }
    IscpLog.d("send connectRequest(requestId: ${msg.requestId}, ${data.size} bytes)")
    return null
}

internal fun Connection.sendDisconnect(): Exception? {
    var transport = this.transport as? ITransport ?: return IscpException.TransportClosed
    var msg = Disconnect(
        resultCode = ResultCode.NORMAL_CLOSURE,
        resultString = "normalClosure"
    )
    var (d, err) = this.converter.encodeTo(msg)
    var data: ByteArray = d ?: return err
    // Write
    var e = transport.write(data)
    if (e != null) {
        return e
    }
    IscpLog.d("send disconnect(${data.size} bytes)")
    return null
}

internal fun Connection.sendPing(requestId: UInt): Exception? {
    var transport = this.transport ?: return IscpException.TransportClosed
    var msg = Ping(
        requestId = requestId
    )
    var (d, err) = this.converter.encodeTo(msg)
    var data: ByteArray = d ?: return err
    // Write
    var e = transport.write(data)
    if (e != null) {
        return e
    }
    IscpLog.d("send ping(${data.size} bytes)")
    return null
}

internal fun Connection.sendPong(requestId: UInt): Exception? {
    var transport = this.transport ?: return IscpException.TransportClosed
    var msg = Pong(
        requestId = requestId
    )
    var (d, err) = this.converter.encodeTo(msg)
    var data: ByteArray = d ?: return err
    // Write
    var e = transport.write(data)
    if (e != null) {
        return e
    }
    IscpLog.d("send pong(${data.size} bytes)")
    return null
}

//endregion

//region Downstream

internal fun Connection.sendDownstreamOpenRequest(
    requestId: UInt, desiredStreamIdAlias: UInt,
    downstreamFilters: List<DownstreamFilter>,
    expiryInterval: UShort,
    dataIdAliases: Map<UInt, DataId>,
    qos: QoS,
    omitEmptyChunk: Boolean) : Exception? {
    var transport: ITransport = this.transport ?: run {
        return IscpException.TransportClosed
    }
    var msg = DownstreamOpenRequest(
        requestId = requestId,
        desiredStreamIdAlias = desiredStreamIdAlias,
        downstreamFilters = toDownstreamFiltersWire(downstreamFilters),
        expiryInterval = expiryInterval,
        dataIdAliases = toDataIdAliasesWire(dataIdAliases),
        qos = toQosWire(qos),
        omitEmptyChunk = omitEmptyChunk
    )
    var (d, err) = this.converter.encodeTo(msg)
    var data: ByteArray = d ?: return err
    // Write
    var e = transport.write(data)
    if (e != null) {
        return e
    }
    IscpLog.d("send downstreamOpenRequest(requestId: ${msg.requestId}, ${data.size} bytes)")
    return null
}

internal fun Connection.sendDownstreamOpenRequestForReconnect(requestId: UInt, desiredStreamIdAlias: UInt, downstream: Downstream) : Exception? {
    var transport: ITransport = this.transport ?: run {
        return IscpException.TransportClosed
    }
    var msg = DownstreamOpenRequest(
        requestId = requestId,
        desiredStreamIdAlias = desiredStreamIdAlias,
        downstreamFilters = toDownstreamFiltersWire(downstream.filters),
        expiryInterval = downstream.expiryInterval.toUShort(),
        dataIdAliases = downstream.dataIdAliasMap,
        qos = toQosWire(downstream.qos),
        omitEmptyChunk = downstream.omitEmptyChunk
    )
    var (d, err) = this.converter.encodeTo(msg)
    var data: ByteArray = d ?: return err
    // Write
    var e = transport.write(data)
    if (e != null) {
        return e
    }
    IscpLog.d("send downstreamOpenRequestForReconnect(downstreamId: ${downstream.id}, requestId: ${msg.requestId}, ${data.size} bytes)")
    return null
}

internal fun Connection.sendDownstreamResumeRequest(requestId: UInt, downstream: Downstream) : Exception? {
    var transport: ITransport = this.transport ?: run {
        return IscpException.TransportClosed
    }
    var msg = DownstreamResumeRequest(
        requestId = requestId,
        streamId = downstream.id,
        desiredStreamIdAlias = downstream.streamIdAlias,
        resumeToken = downstream.resumeToken
    )
    var (d, err) = this.converter.encodeTo(msg)
    var data: ByteArray = d ?: return err
    // Write
    var e = transport.write(data)
    if (e != null) {
        return e
    }
    IscpLog.d("send downstreamResumeRequest(downstreamId: ${downstream.id}, requestId: ${msg.requestId}, ${data.size} bytes)")
    return null
}

internal fun Connection.sendDownstreamCloseRequest(requestId: UInt, downstream: Downstream) : Exception? {
    var transport: ITransport = this.transport ?: run {
        return IscpException.TransportClosed
    }
    var msg = DownstreamCloseRequest(
        requestId = requestId,
        streamId = downstream.id
    )
    var (d, err) = this.converter.encodeTo(msg)
    var data: ByteArray = d ?: return err
    // Write
    var e = transport.write(data)
    if (e != null) {
        return e
    }
    IscpLog.d("send downstreamCloseRequest(downstreamId: ${downstream.id}, requestId: ${msg.requestId}, ${data.size} bytes)")
    return null
}

internal fun Connection.sendDownstreamMetadataAck(requestId: UInt, resultCode: ResultCode, resultString: String) : Exception? {
    var transport: ITransport = this.transport ?: run {
        return IscpException.TransportClosed
    }
    var msg = DownstreamMetadataAck(
        requestId = requestId,
        resultCode = resultCode,
        resultString = resultString
    )
    var (d, err) = this.converter.encodeTo(msg)
    var data: ByteArray = d ?: return err
    // Write
    var e = transport.write(data)
    if (e != null) {
        return e
    }
    IscpLog.d("send downstreamMetadataAck(requestId: ${msg.requestId}, ${data.size} bytes)")
    return null
}

internal fun Connection.sendDownstreamChunkAck(downstream: Downstream) : Exception? {
    var transport: ITransport = this.transport ?: run {
        return IscpException.TransportClosed
    }
    if (!downstream.isOpen) {
        return IscpException.StreamClosed
    }
    downstream.ackBufferLock.withLock {
        var ackBufferLength = downstream.chunksResultsAckBuffer.count() +
                downstream.upstreamInfoMapAckBuffer.count() +
                downstream.dataIdMapAckBuffer.count()
        // AckBufferのトータルサイズが0ならDownstreamChunkAckは送らない
        if (ackBufferLength == 0) {
            return null
        }
        var msg = DownstreamChunkAck(
            streamIdAlias = downstream.streamIdAlias,
            ackId = downstream.ackIdGenerator.getAndAdd(),
            results = downstream.chunksResultsAckBuffer.toList(),
            upstreamAliases = downstream.upstreamInfoMapAckBuffer,
            dataIdAliases = downstream.dataIdMapAckBuffer
        )
        var (d, err) = this.converter.encodeTo(msg)
        var data: ByteArray = d ?: return err
        // AckBufferClear
        downstream.chunksResultsAckBuffer.clear()
        downstream.upstreamInfoMapAckBuffer.clear()
        downstream.dataIdMapAckBuffer.clear()
        // Write
        var e = transport.write(data)
        if (e != null) {
            return e
        }
        IscpLog.d("send downstreamChunkAck(downstreamId: ${downstream.id}, ackId: ${msg.ackId}, ${data.size} bytes)")
        return null
    }
}

//endregion

//region Upstream

internal fun Connection.sendUpstreamOpenRequest(
    requestId: UInt,
    sessionId: String,
    ackInterval: UShort,
    expiryInterval: UShort,
    dataIds: List<DataId>,
    qos: QoS,
    persist: Boolean) : Exception? {
    var transport: ITransport = this.transport ?: run {
        return IscpException.TransportClosed
    }
    var msg = UpstreamOpenRequest(
        requestId = requestId,
        sessionId = sessionId,
        ackInterval = ackInterval,
        expiryInterval = expiryInterval,
        dataIds = toDataIdsWire(dataIds),
        qos = toQosWire(qos)
    )
    msg.extensionFields.persist = persist
    var (d, err) = this.converter.encodeTo(msg)
    var data: ByteArray = d ?: return err
    // Write
    var e = transport.write(data)
    if (e != null) {
        return e
    }
    IscpLog.d("send upstreamOpenRequest(requestId: ${msg.requestId}, ${data.size} bytes)")
    return null
}

internal fun Connection.sendUpstreamOpenRequestForReconnect(requestId: UInt, upstream: Upstream) : Exception? {
    var transport: ITransport = this.transport ?: run {
        return IscpException.TransportClosed
    }
    var msg = UpstreamOpenRequest(
        requestId = requestId,
        sessionId = upstream.sessionId,
        ackInterval = upstream.ackInterval.toUShort(),
        expiryInterval = upstream.expiryInterval.toUShort(),
        dataIds = upstream.dataIds,
        qos = toQosWire(upstream.qos)
    )
    msg.extensionFields.persist = upstream.persist
    var (d, err) = this.converter.encodeTo(msg)
    var data: ByteArray = d ?: return err
    // Write
    var e = transport.write(data)
    if (e != null) {
        return e
    }
    IscpLog.d("send upstreamOpenRequestForReconnect(requestId: ${msg.requestId}, ${data.size} bytes)")
    return null
}

internal fun Connection.sendUpstreamResumeRequest(requestId: UInt, upstream: Upstream) : Exception? {
    var transport: ITransport = this.transport ?: run {
        return IscpException.TransportClosed
    }
    var msg = UpstreamResumeRequest(
        requestId = requestId,
        streamId = upstream.id,
        resumeToken = upstream.resumeToken
    )
    var (d, err) = this.converter.encodeTo(msg)
    var data: ByteArray = d ?: return err
    // Write
    var e = transport.write(data)
    if (e != null) {
        return e
    }
    IscpLog.d("send upstreamResumeRequest(upstreamId: ${upstream.id}, requestId: ${msg.requestId}, ${data.size} bytes)")
    return null
}

internal fun Connection.sendUpstreamChunk(upstream: Upstream) : Exception? {
    // データの送信はトランスポートのオープンをチェックしない
    upstream.streamChunkLock.withLock {
        var sendPayloadSize = upstream.dataPointsPayloadSize
        var dataPointsCnt = upstream.dataPointsCnt
        var (totalDataPoints, overflow) = upstream.totalDataPoints.addingReportingOverflow(dataPointsCnt)
        if (overflow) {
            // データポイントの最大に達したので別ストリームに置き換える必要がある
            var e = IscpException.Unexpected("dataPoints length reached maximum.")
            // 強制クローズ処理
            upstream.isOpen = false
            this.unregisterUpstream(upstream)
            var requestId = this.requestIdGenerator.generate()
            this.sendUpstreamCloseRequest(requestId, upstream, false)
            upstream.callbacks?.onCloseWithError(upstream, e)
            return e
        }
        var sequenceNumber = upstream.sequenceNumberGenerator.next() as? UInt ?: run {
            // シーケンス番号が最大値に達したので別ストリームに置き換える必要がある
            var e = IscpException.Unexpected("sequenceNumber reached maximum.")
            // 強制クローズ処理
            upstream.isOpen = false
            this.unregisterUpstream(upstream)
            var requestId = this.requestIdGenerator.generate()
            this.sendUpstreamCloseRequest(requestId, upstream, false)
            upstream.callbacks?.onCloseWithError(upstream, e)
            return e
        }
        upstream.lastIssuedSequenceNumber = sequenceNumber

        // Callback
        var streamChunkForApp = UpstreamChunk(
            sequenceNumber = sequenceNumber.toInt(),
            dataPointGroups = upstream.dataPointsBufferForApp.toList(),
            dataPointCount = dataPointsCnt.toLong(),
            payloadSize = sendPayloadSize.toLong())
        upstream.callbacks?.onGenerateChunk(upstream, streamChunkForApp)

        var streamChunk = StreamChunk(
            sequenceNumber = sequenceNumber,
            dataPointGroups = upstream.dataPointsBuffer.toList())
        var msg = com.aptpod.iscp.message.UpstreamChunk(
            streamIdAlias = upstream.streamIdAlias,
            dataIds = upstream.dataIdMapAckBuffer.toList(),
            streamChunk = streamChunk)
        var (d, err) = this.converter.encodeTo(msg)
        var data: ByteArray = d ?: return err
        upstream.totalDataPoints = totalDataPoints
        upstream.flushBuffer()
        // Write
        if (upstream.isOpen)
        {
            this.transport?.let { transport ->
                var e = transport.write(data)
                if (e != null) {
                    return e
                }
                IscpLog.d("send upstreamChunk(upstreamId: ${upstream.id}, sequenceNumber: $sequenceNumber, dataPointsCnt: $dataPointsCnt, totalDataPoints: $totalDataPoints, ${data.size} bytes)")
            }
        }
        return null
    }
}

internal fun Connection.sendUpstreamCloseRequest(requestId: UInt, upstream: Upstream, closeSession: Boolean) : Exception?
{
    var transport: ITransport = this.transport ?: run {
        return IscpException.TransportClosed
    }
    var msg = UpstreamCloseRequest(
        requestId = requestId,
        streamId = upstream.id,
        totalDataPoints = upstream.totalDataPoints,
        finalSequenceNumber = upstream.lastIssuedSequenceNumber
    )
    msg.extensionFields.closeSession = closeSession
    var (d, err) = this.converter.encodeTo(msg)
    var data: ByteArray = d ?: return err
    // Write
    var e = transport.write(data)
    if (e != null) {
        return e
    }
    IscpLog.d("send upstreamCloseRequest(upstreamId: ${upstream.id}, requestId: ${msg.requestId}, ${data.size} bytes)")
    return null
}

//endregion

//region for Metadata

internal fun Connection.sendUpstreamMetadataBaseTime(requestId: UInt, baseTime: BaseTime, persist: Boolean) : Exception? {
    var metadata = toBaseTimeWire(baseTime)
    var (data, e) = sendUpstreamMetadata(requestId, UpstreamMetadata.MetadataCase.BASE_TIME, metadata, persist)
    if (data == null) {
        return e
    }
    IscpLog.d("send upstreamMetadataBaseTime(requestId: ${data.count()} bytes)")
    return null
}

internal fun Connection.sendUpstreamMetadata(requestId: UInt, metadataCase: UpstreamMetadata.MetadataCase, metadata: Any, persist: Boolean) : Pair<ByteArray?, Exception?> {
    var transport = this.transport ?: return Pair(null, IscpException.TransportClosed)
    var msg = UpstreamMetadata(
        requestId = requestId,
        metadataCase = metadataCase,
        metadata = metadata
    )
    msg.extensionFields.persist = persist
    var (d, err) = this.converter.encodeTo(msg)
    var data: ByteArray = d ?: return Pair(null, err)
    // Write
    var e = transport.write(data)
    if (e != null) {
        return Pair(null, e)
    }
    return Pair(data, null)
}

//endregion

//region for E2ECall

internal fun Connection.sendUpstreamCall(upstreamReplyCall: UpstreamReplyCall, callId: String) : Exception? {
    var transport: ITransport = this.transport ?: run {
        return IscpException.TransportClosed
    }
    var msg = toUpstreamCallWire(upstreamReplyCall, callId)
    var (d, err) = this.converter.encodeTo(msg)
    var data: ByteArray = d ?: return err
    // Write
    var e = transport.write(data)
    if (e != null) {
        return e
    }
    IscpLog.d("send sendUpstreamCall(callId: ${msg.callId}, requestCallId: ${msg.requestCallId}, destinationNodeId: ${msg.destinationNodeId}, ${data.size} bytes)")
    return null
}

internal fun Connection.sendUpstreamCall(upstreamCall: UpstreamCall, callId: String) : Exception? {
    var transport: ITransport = this.transport ?: run {
        return IscpException.TransportClosed
    }
    var msg = toUpstreamCallWire(upstreamCall, callId)
    var (d, err) = this.converter.encodeTo(msg)
    var data: ByteArray = d ?: return err
    // Write
    var e = transport.write(data)
    if (e != null) {
        return e
    }
    IscpLog.d("send sendUpstreamCall(callId: ${msg.callId}, requestCallId: ${msg.requestCallId}, destinationNodeId: ${msg.destinationNodeId}, ${data.size} bytes)")
    return null
}