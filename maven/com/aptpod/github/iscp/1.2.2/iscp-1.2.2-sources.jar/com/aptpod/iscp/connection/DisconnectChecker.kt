package com.aptpod.iscp.connection

import com.aptpod.iscp.logger.IscpLog
import com.aptpod.iscp.message.Pong
import com.aptpod.iscp.transport.Receiver
import java.util.Timer
import java.util.TimerTask
import java.util.concurrent.locks.ReentrantLock
import kotlin.concurrent.withLock

internal class DisconnectChecker {
    private val lock = ReentrantLock()

    @Volatile internal var connection: Connection? = null
        private set
    private var timeoutHandler: (() -> Unit)? = null
    private var timeoutTimer: Timer? = null
    private var sendPingTimer: Timer? = null
    private var receiver: Receiver? = null
    private var currentRequestId: UInt? = null
    private var registration = Any()

    internal fun register(connection: Connection, timeoutHandler: () -> Unit) = lock.withLock {
        unregister()
        val registration = Any()
        this.registration = registration
        this.connection = connection
        this.timeoutHandler = timeoutHandler
        val receiver = Receiver(0)
        receiver.subscribe<Pong> { msg, exception ->
            if (msg == null || exception != null) {
                IscpLog.e("failed to receive pong. ${exception?.message ?: ""} - DisconnectChecker")
                return@subscribe
            }
            IscpLog.d("onReceived pong(requestId: ${msg.requestId}) - DisconnectChecker")
            lock.withLock {
                if (this.registration === registration && msg.requestId == currentRequestId) {
                    stopTimeoutTimer()
                }
            }
        }
        connection.receivers.register(receiver)
        this.receiver = receiver
    }

    internal fun unregister() = lock.withLock {
        registration = Any()
        timeoutHandler = null
        receiver?.let { connection?.receivers?.unregister(it) }
        receiver = null
        stopTimerAll()
        currentRequestId = null
        connection = null
    }

    fun startSendPingTimer() = lock.withLock {
        val interval = connection?.pingInterval?.toLong()?.times(1000) ?: return
        if (interval <= 0) return
        sendPingTimer?.cancel()
        val timer = Timer()
        sendPingTimer = timer
        timer.schedule(object : TimerTask() {
            override fun run() {
                IscpLog.d("sendPingTimerOnFire - DisconnectChecker")
                sendPingMessage(timer)
            }
        }, interval, interval)
    }

    fun stopTimerAll() = lock.withLock {
        sendPingTimer?.cancel()
        sendPingTimer = null
        stopTimeoutTimer()
    }

    fun startTimeoutTimer() = lock.withLock {
        val timeout = connection?.pingTimeout?.toLong()?.times(1000) ?: return
        if (timeout <= 0) return
        stopTimeoutTimer()
        val timer = Timer()
        timeoutTimer = timer
        timer.schedule(object : TimerTask() {
            override fun run() {
                IscpLog.d("timeoutTimerOnFire - DisconnectChecker")
                val handler = lock.withLock {
                    if (timeoutTimer !== timer || connection == null) return
                    timeoutTimer = null
                    timer.cancel()
                    timeoutHandler
                }
                // Application callbacks and transport I/O must not hold the checker lock.
                handler?.invoke()
            }
        }, timeout)
    }

    fun stopTimeoutTimer() = lock.withLock {
        timeoutTimer?.cancel()
        timeoutTimer = null
    }

    fun sendPingMessage() = sendPingMessage(null)

    private fun sendPingMessage(timer: Timer?) {
        val ping = lock.withLock {
            if (timer != null && sendPingTimer !== timer) return
            val connection = connection ?: return
            val transport = connection.transport ?: return
            val requestId = connection.requestIdGenerator.generate()
            currentRequestId = requestId
            // Reserve the timeout before sending, so an immediate Pong can cancel it.
            startTimeoutTimer()
            Triple(connection, transport, requestId)
        }
        // An in-flight callback can only write to its original transport.
        val exception = ping.first.sendPing(ping.third, ping.second)
        if (exception != null) {
            IscpLog.e("failed to send ping. ${exception.message} - DisconnectChecker")
        }
    }

    fun dispose() = unregister()
}
